<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}
include_once $_SERVER['DOCUMENT_ROOT'] . '/GSO System/php/db_connection.php';

$page_title = ucwords(str_replace('_', ' ', pathinfo(basename($_SERVER['PHP_SELF']), PATHINFO_FILENAME)));

$initials = 'G';
if(isset($_SESSION['first_name'], $_SESSION['last_name'])) {
    $initials = strtoupper(substr($_SESSION['first_name'], 0, 1) . substr($_SESSION['last_name'], 0, 1));
}

$menu_items = [
    ['url' => '/GSO System/php/dashboard.php', 'icon' => 'grid', 'label' => 'Dashboard'],
    ['url' => '/GSO System/php/equipment/equipment.php', 'icon' => 'tool', 'label' => 'Equipment'],
    ['url' => '/GSO System/php/borrowings/borrowings.php', 'icon' => 'book', 'label' => 'Borrowings'],
    ['url' => '/GSO System/php/categories/categories.php', 'icon' => 'list', 'label' => 'Categories', 'admin_only' => true],
    ['url' => '/GSO System/php/users/users.php', 'icon' => 'users', 'label' => 'Users', 'admin_only' => true],
    ['url' => '/GSO System/php/reports.php', 'icon' => 'file-text', 'label' => 'Reports', 'admin_only' => true]
];

// Simple function to get icon HTML
if (!function_exists('getIcon')) {
    function getIcon($name) {
        return '<i data-feather="' . $name . '"></i>';
    }
}
?>


<script src="https://cdn.jsdelivr.net/npm/feather-icons/dist/feather.min.js"></script>

<aside class="sidebar">
    <div class="sidebar-header">
        <div class="logo">
            <a href="../../php/index.php">PLP GSO Management</a>
        </div>
        <button class="sidebar-toggle" id="sidebarToggle">
            <?php echo getIcon('menu'); ?>
        </button>
    </div>
    
    <div class="sidebar-content">
        <nav class="sidebar-menu">
            <?php foreach($menu_items as $item): ?>
                <?php if(!isset($item['admin_only']) || !$item['admin_only'] || isAdmin()): ?>
                    <a href="<?php echo $item['url']; ?>" class="sidebar-link">
                        <?php echo getIcon($item['icon']); ?>
                        <span><?php echo $item['label']; ?></span>
                    </a>
                <?php endif; ?>
            <?php endforeach; ?>
        </nav>
    </div>
    
    <div class="sidebar-footer">
        <div class="user-profile" id="userProfile">
            <div class="user-avatar"><?php echo $initials; ?></div>
            <div class="user-info">
                <span class="user-name">
                    <?php echo isset($_SESSION['first_name'], $_SESSION['last_name']) ? 
                        $_SESSION['first_name'] . ' ' . $_SESSION['last_name'] : 'Guest'; ?>
                </span>
                <?php echo getIcon('chevron-down'); ?>
            </div>
            <div class="user-menu-dropdown" id="userMenuDropdown">
                <?php if (!isAdmin()): ?>   
                    <a href="/GSO System/php/borrowings/my_borrowings.php">My Borrowings</a>
                <?php endif; ?>
                <a href="/GSO System/php/logout.php">Logout</a>
            </div>
        </div>
    </div>
</aside>

<div class="content-wrapper">
    <div class="top-bar">
        <button class="sidebar-toggle" id="mobileToggle">
            <?php echo getIcon('menu'); ?>
        </button>
        <h1 class="page-title"><?php echo $page_title; ?></h1>
    </div>

<!-- Replace the relative path with an absolute path -->
<script src="../assets/js/sidebar.js"></script>