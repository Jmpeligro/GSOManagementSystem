<?php
session_start();
require_once '../php/db_connection.php';
require_once 'fpdf/fpdf.php'; 
require_once 'reports/report_utils.php';

if (!isLoggedIn() || !isAdmin()) {
    header("Location: index.php");
    exit();
}

// Get report parameters
$report_type = $_POST['report_type'] ?? '';

if (empty($report_type)) {
    $_SESSION['error'] = "Report type is required";
    header("Location: ../../php/reports.php");
    exit();
}

// Create PDF report class
class PDF extends FPDF {
    // Page header
    function Header() {
        // Logo
        $this->Image('../assets/images/logo.png', 10, 6, 30);
        // Arial bold 15
        $this->SetFont('Arial', 'B', 15);
        // Move to the right
        $this->Cell(80);
        // Title
        $this->Cell(30, 10, 'PLP GSO Management System Report', 0, 0, 'C');
        // Line break
        $this->Ln(20);
    }

    // Page footer
    function Footer() {
        // Position at 1.5 cm from bottom
        $this->SetY(-15);
        // Arial italic 8
        $this->SetFont('Arial', 'I', 8);
        // Page number
        $this->Cell(0, 10, 'Page ' . $this->PageNo() . '/{nb}', 0, 0, 'C');
        // Date generated
        $this->Cell(-30, 10, 'Generated on: ' . date('Y-m-d H:i:s'), 0, 0, 'R');
    }
    
    // Table header
    function TableHeader($header) {
        $this->SetFont('Arial', 'B', 10);
        $this->SetFillColor(200, 220, 255);
        $width = $this->GetPageWidth() - 20;
        $col_width = $width / count($header);
        
        foreach($header as $col) {
            $this->Cell($col_width, 7, $col, 1, 0, 'C', true);
        }
        $this->Ln();
    }
    
    // Table row
    function TableRow($data, $header_count) {
        $this->SetFont('Arial', '', 9);
        $width = $this->GetPageWidth() - 20;
        $col_width = $width / $header_count;
        
        foreach($data as $col) {
            $this->Cell($col_width, 6, $col, 1);
        }
        $this->Ln();
    }
}

// Initialize PDF
$pdf = new PDF();
$pdf->AliasNbPages();
$pdf->AddPage();
$pdf->SetFont('Arial', '', 12);

// Generate report based on type
switch ($report_type) {
    case 'equipment':
        require_once 'reports/equipment_report.php';
        generateEquipmentReport($pdf, $conn);
        break;
    case 'borrowings':
        require_once 'reports/borrowings_report.php';
        generateBorrowingsReport($pdf, $conn);
        break;
    case 'maintenance':
        require_once 'reports/maintenance_report.php';
        generateMaintenanceReport($pdf, $conn);
        break;
    case 'usage':
        require_once 'reports/usage_report.php';
        generateUsageReport($pdf, $conn);
        break;
    default:
        $_SESSION['error'] = "Invalid report type";
        header("Location: ../php/reports.php");
        exit();
}