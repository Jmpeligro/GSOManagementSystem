<?php
session_start();
require_once '../../php/db_connection.php';
require_once '../fpdf/fpdf.php';
require_once 'report_utils.php';

if (!isLoggedIn() || !isAdmin()) {
    header("Location: ../../php/index.php");
    exit();
}

// PDF class definition
class PDF extends FPDF {
    function Header() {
        $this->Image('../../assets/images/logo.png', 10, 6, 30);
        $this->SetFont('Arial', 'B', 15);
        $this->Cell(80);
        $this->Cell(30, 10, 'PLP GSO Management System Report', 0, 0, 'C');
        $this->Ln(20);
    }
    
    function Footer() {
        $this->SetY(-15);
        $this->SetFont('Arial', 'I', 8);
        $this->Cell(0, 10, 'Page ' . $this->PageNo() . '/{nb}', 0, 0, 'C');
        $this->Cell(-30, 10, 'Generated on: ' . date('Y-m-d H:i:s'), 0, 0, 'R');
    }
    
    function TableHeader($header) {
        $this->SetFont('Arial', 'B', 10);
        $this->SetFillColor(200, 220, 255);
        $width = $this->GetPageWidth() - 20;
        $col_width = $width / count($header);
        
        foreach($header as $col) {
            $this->Cell($col_width, 7, $col, 1, 0, 'C', true);
        }
        $this->Ln();
    }
    
    function TableRow($data, $header_count) {
        $this->SetFont('Arial', '', 9);
        $width = $this->GetPageWidth() - 20;
        $col_width = $width / $header_count;
        
        foreach($data as $col) {
            $this->Cell($col_width, 6, $col, 1);
        }
        $this->Ln();
    }
}

// Initialize PDF and generate report
$pdf = new PDF();
$pdf->AliasNbPages();
$pdf->AddPage();
$pdf->SetFont('Arial', '', 12);

// Generate usage report
generateUsageReport($pdf, $conn);

/**
 * Equipment usage report generator
 */

/**
 * Generate equipment usage report
 * 
 * @param PDF $pdf PDF object
 * @param mysqli $conn Database connection
 */
function generateUsageReport($pdf, $conn) {
    $pdf->SetFont('Arial', 'B', 14);
    $pdf->Cell(0, 10, 'Equipment Usage Report', 0, 1, 'C');
    $pdf->Ln(5);
    
    // Get filters
    $period = $_POST['usage-period'] ?? '';
    $date_from = '';
    $date_to = '';
    
    // Calculate date range based on period
    if ($period == 'custom') {
        $date_from = $_POST['usage-date-from'] ?? '';
        $date_to = $_POST['usage-date-to'] ?? '';
    } else {
        $today = date('Y-m-d');
        
        switch ($period) {
            case 'last-30':
                $date_from = date('Y-m-d', strtotime('-30 days'));
                $date_to = $today;
                break;
            case 'last-90':
                $date_from = date('Y-m-d', strtotime('-90 days'));
                $date_to = $today;
                break;
            case 'this-month':
                $date_from = date('Y-m-01');
                $date_to = date('Y-m-t');
                break;
            case 'last-month':
                $date_from = date('Y-m-01', strtotime('-1 month'));
                $date_to = date('Y-m-t', strtotime('-1 month'));
                break;
            case 'this-year':
                $date_from = date('Y-01-01');
                $date_to = date('Y-12-31');
                break;
            default:
                // All time - no date restriction
                break;
        }
    }
    
    // Equipment usage statistics
    $pdf->SetFont('Arial', 'B', 12);
    $pdf->Cell(0, 10, 'Most Borrowed Equipment', 0, 1, 'L');
    
    $sql_popular = "SELECT e.equipment_id, e.name, COUNT(b.borrowing_id) as borrow_count 
                    FROM equipment e 
                    JOIN borrowings b ON e.equipment_id = b.equipment_id 
                    WHERE 1=1";
    
    if (!empty($date_from)) {
        $sql_popular .= " AND b.borrow_date >= '" . $conn->real_escape_string($date_from) . "'";
    }
    
    if (!empty($date_to)) {
        $sql_popular .= " AND b.borrow_date <= '" . $conn->real_escape_string($date_to) . "'";
    }
    
    $sql_popular .= " GROUP BY e.equipment_id 
                    ORDER BY borrow_count DESC 
                    LIMIT 10";
    
    // Check SQL query execution
    $result_popular = $conn->query($sql_popular);
    if (!$result_popular) {
        error_log("SQL Error in generateUsageReport: " . $conn->error);
        $pdf->Cell(0, 10, 'An error occurred while generating the report. Please try again later.', 0, 1, 'C');
        $pdf->Output('usage_report.pdf', 'D');
        exit();
    }
    
    if ($result_popular->num_rows > 0) {
        // Filter information
        $pdf->SetFont('Arial', 'I', 10);
        $filterText = 'Period: ';
        
        switch ($period) {
            case 'last-30':
                $filterText .= 'Last 30 Days';
                break;
            case 'last-90':
                $filterText .= 'Last 90 Days';
                break;
            case 'this-month':
                $filterText .= 'This Month';
                break;
            case 'last-month':
                $filterText .= 'Last Month';
                break;
            case 'this-year':
                $filterText .= 'This Year';
                break;
            case 'custom':
                $filterText .= 'From ' . formatDate($date_from) . ' To ' . formatDate($date_to);
                break;
            default:
                $filterText .= 'All Time';
                break;
        }
        
        $pdf->Cell(0, 5, $filterText, 0, 1, 'L');
        $pdf->Ln(5);
        
        // Table headers
        $header = array('Equipment ID', 'Equipment Name', 'Times Borrowed');
        $pdf->TableHeader($header);
        
        // Table data
        while ($row = $result_popular->fetch_assoc()) {
            $data = array(
                $row['equipment_id'],
                $row['name'],
                $row['borrow_count']
            );
            $pdf->TableRow($data, count($header));
        }
    } else {
        $pdf->SetFont('Arial', '', 10);
        $pdf->Cell(0, 10, 'No data available for the selected period.', 0, 1, 'C');
    }
    $pdf->Ln(10);

    // Category usage statistics
    $pdf->SetFont('Arial', 'B', 12);
    $pdf->Cell(0, 10, 'Usage by Category', 0, 1, 'L');

    $sql_categories = "SELECT c.name as category_name, COUNT(b.borrowing_id) as borrow_count 
                      FROM categories c 
                      JOIN equipment e ON c.category_id = e.category_id 
                      JOIN borrowings b ON e.equipment_id = b.equipment_id 
                      WHERE 1=1";

    if (!empty($date_from)) {
        $sql_categories .= " AND b.borrow_date >= '" . $conn->real_escape_string($date_from) . "'";
    }
    
    if (!empty($date_to)) {
        $sql_categories .= " AND b.borrow_date <= '" . $conn->real_escape_string($date_to) . "'";
    }
    
    $sql_categories .= " GROUP BY c.category_id 
                        ORDER BY borrow_count DESC";

    $result_categories = $conn->query($sql_categories);
    if (!$result_categories) {
        error_log("SQL Error in generateUsageReport (categories): " . $conn->error);
        $pdf->Cell(0, 10, 'An error occurred while generating category statistics.', 0, 1, 'C');
    } else if ($result_categories->num_rows > 0) {
        // Table headers
        $header = array('Category', 'Times Equipment Borrowed');
        $pdf->TableHeader($header);
        
        // Table data
        while ($row = $result_categories->fetch_assoc()) {
            $data = array(
                $row['category_name'],
                $row['borrow_count']
            );
            $pdf->TableRow($data, count($header));
        }
    } else {
        $pdf->SetFont('Arial', '', 10);
        $pdf->Cell(0, 10, 'No category statistics available for the selected period.', 0, 1, 'C');
    }

    // Add report generation timestamp
    $pdf->Ln(10);
    $pdf->SetFont('Arial', 'I', 8);
    $pdf->Cell(0, 10, 'Report generated on: ' . date('Y-m-d H:i:s'), 0, 1, 'R');
}