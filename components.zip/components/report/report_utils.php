<?php
function formatDate($date) {
    if (empty($date) || $date == '0000-00-00') {
        return 'N/A';
    }
    return date('M d, Y', strtotime($date));
}

function getCategoryName($conn, $category_id) {
    $sql = "SELECT name FROM categories WHERE category_id = " . $conn->real_escape_string($category_id);
    $result = $conn->query($sql);
    if ($result->num_rows > 0) {
        $row = $result->fetch_assoc();
        return $row['name'];
    }
    return 'Unknown';
}

function getUserName($conn, $user_id) {
    $sql = "SELECT CONCAT(first_name, ' ', last_name) as name FROM users WHERE user_id = " . $conn->real_escape_string($user_id);
    $result = $conn->query($sql);
    if ($result->num_rows > 0) {
        $row = $result->fetch_assoc();
        return $row['name'];
    }
    return 'Unknown';
}

function handleSqlError($conn, $context) {
    error_log("SQL Error in $context: " . $conn->error);
    return "An error occurred while generating the report. Please try again later.";
}