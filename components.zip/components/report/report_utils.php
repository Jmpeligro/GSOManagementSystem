<?php
/**
 * Report utility functions used across different report types
 */

/**
 * Format date for display in reports
 * 
 * @param string $date Date string
 * @return string Formatted date
 */
function formatDate($date) {
    if (empty($date) || $date == '0000-00-00') {
        return 'N/A';
    }
    return date('M d, Y', strtotime($date));
}

/**
 * Get category name from ID
 * 
 * @param mysqli $conn Database connection
 * @param int $category_id Category ID
 * @return string Category name
 */
function getCategoryName($conn, $category_id) {
    $sql = "SELECT name FROM categories WHERE category_id = " . $conn->real_escape_string($category_id);
    $result = $conn->query($sql);
    if ($result->num_rows > 0) {
        $row = $result->fetch_assoc();
        return $row['name'];
    }
    return 'Unknown';
}

/**
 * Get user's full name from ID
 * 
 * @param mysqli $conn Database connection
 * @param int $user_id User ID
 * @return string User's full name
 */
function getUserName($conn, $user_id) {
    $sql = "SELECT CONCAT(first_name, ' ', last_name) as name FROM users WHERE user_id = " . $conn->real_escape_string($user_id);
    $result = $conn->query($sql);
    if ($result->num_rows > 0) {
        $row = $result->fetch_assoc();
        return $row['name'];
    }
    return 'Unknown';
}

/**
 * Handle SQL errors consistently
 * 
 * @param mysqli $conn Database connection
 * @param string $context Context where error occurred
 */
function handleSqlError($conn, $context) {
    error_log("SQL Error in $context: " . $conn->error);
    return "An error occurred while generating the report. Please try again later.";
}