<?php
/**
 * Format a date string for display
 * 
 * @param string $date The date string to format
 * @return string Formatted date string or 'N/A'
 */
function formatDate($date) {
    if (empty($date) || $date == '0000-00-00') {
        return 'N/A';
    }
    return date('M d, Y', strtotime($date));
}

/**
 * Get category name from its ID
 * 
 * @param mysqli $conn Database connection
 * @param int $category_id Category ID
 * @return string Category name or 'Unknown'
 */
function getCategoryName($conn, $category_id) {
    $sql = "SELECT name FROM categories WHERE category_id = " . $conn->real_escape_string($category_id);
    $result = $conn->query($sql);
    if ($result && $result->num_rows > 0) {
        $row = $result->fetch_assoc();
        return $row['name'];
    }
    return 'Unknown';
}

/**
 * Get user's full name from their ID
 * 
 * @param mysqli $conn Database connection
 * @param int $user_id User ID
 * @return string User's full name or 'Unknown'
 */
function getUserName($conn, $user_id) {
    $sql = "SELECT CONCAT(first_name, ' ', last_name) as name FROM users WHERE user_id = " . $conn->real_escape_string($user_id);
    $result = $conn->query($sql);
    if ($result && $result->num_rows > 0) {
        $row = $result->fetch_assoc();
        return $row['name'];
    }
    return 'Unknown';
}

/**
 * Handle SQL errors in a standardized way
 * 
 * @param mysqli $conn Database connection
 * @param string $context Context where the error occurred
 * @return string Error message
 */
function handleSqlError($conn, $context) {
    error_log("SQL Error in $context: " . $conn->error);
    return "An error occurred while generating the report. Please try again later.";
}

/**
 * Calculate appropriate column widths based on content and page width
 * 
 * @param array $headers Array of column headers
 * @param array $data Array of data rows
 * @param float $page_width Total available page width
 * @return array Array of column widths
 */
function calculateColumnWidths($headers, $data, $page_width) {
    $total_width = $page_width - 20; // Subtract margins
    $column_count = count($headers);
    $widths = array();
    
    // First pass: calculate minimum required width based on header length
    for ($i = 0; $i < $column_count; $i++) {
        $widths[$i] = strlen($headers[$i]) * 2.5; // Approximate width based on header
    }
    
    // Second pass: adjust based on content
    foreach ($data as $row) {
        for ($i = 0; $i < $column_count; $i++) {
            if (isset($row[$i])) {
                $content_width = strlen($row[$i]) * 1.8; // Approximate width based on content
                if ($content_width > $widths[$i]) {
                    $widths[$i] = min($content_width, $total_width / 3); // Cap at 1/3 of page width
                }
            }
        }
    }
    
    // Ensure we don't exceed page width
    $total_calculated = array_sum($widths);
    if ($total_calculated > $total_width) {
        // Scale all widths proportionally
        $scale_factor = $total_width / $total_calculated;
        for ($i = 0; $i < $column_count; $i++) {
            $widths[$i] *= $scale_factor;
        }
    }
    
    return $widths;
}

/**
 * Truncate text to fit in a cell with ellipsis
 * 
 * @param string $text Text to truncate
 * @param int $max_length Maximum length
 * @return string Truncated text
 */
function truncateText($text, $max_length = 50) {
    if (strlen($text) <= $max_length) {
        return $text;
    }
    return substr($text, 0, $max_length - 3) . '...';
}