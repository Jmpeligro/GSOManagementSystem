<?php
session_start();
require_once '../../php/db_connection.php';
require_once '../fpdf/fpdf.php';
require_once 'report_utils.php';

if (!isLoggedIn() || !isAdmin()) {
    header("Location: ../../php/index.php");
    exit();
}

// PDF class definition
class PDF extends FPDF {
    function Header() {
        $this->Image('../../assets/images/logo.png', 10, 6, 30);
        $this->SetFont('Arial', 'B', 15);
        $this->Cell(80);
        $this->Cell(30, 10, 'PLP GSO Management System Report', 0, 0, 'C');
        $this->Ln(20);
    }
    
    function Footer() {
        $this->SetY(-15);
        $this->SetFont('Arial', 'I', 8);
        $this->Cell(0, 10, 'Page ' . $this->PageNo() . '/{nb}', 0, 0, 'C');
        $this->Cell(-30, 10, 'Generated on: ' . date('Y-m-d H:i:s'), 0, 0, 'R');
    }
    
    function TableHeader($header) {
        $this->SetFont('Arial', 'B', 10);
        $this->SetFillColor(200, 220, 255);
        $width = $this->GetPageWidth() - 20;
        $col_width = $width / count($header);
        
        foreach($header as $col) {
            $this->Cell($col_width, 7, $col, 1, 0, 'C', true);
        }
        $this->Ln();
    }
    
    function TableRow($data, $header_count) {
        $this->SetFont('Arial', '', 9);
        $width = $this->GetPageWidth() - 20;
        $col_width = $width / $header_count;
        
        foreach($data as $col) {
            $this->Cell($col_width, 6, $col, 1);
        }
        $this->Ln();
    }
}

// Initialize PDF and generate report
$pdf = new PDF();
$pdf->AliasNbPages();
$pdf->AddPage();
$pdf->SetFont('Arial', '', 12);

// Generate borrowings report
generateBorrowingsReport($pdf, $conn);

/**
 * Borrowings report generator
 */

/**
 * Generate borrowings report
 * 
 * @param PDF $pdf PDF object
 * @param mysqli $conn Database connection
 */
function generateBorrowingsReport($pdf, $conn) {
    $pdf->SetFont('Arial', 'B', 14);
    $pdf->Cell(0, 10, 'Borrowings Report', 0, 1, 'C');
    $pdf->Ln(5);
    
    // Get filters
    $status = $_POST['status'] ?? '';
    $approval_status = $_POST['approval_status'] ?? '';
    $date_from = $_POST['date_from'] ?? '';
    $date_to = $_POST['date_to'] ?? '';
    $user_id = $_POST['user_id'] ?? '';
    
    // Build SQL query
    $sql = "SELECT b.borrowing_id, e.name as equipment_name, CONCAT(u.first_name, ' ', u.last_name) as borrower, 
            u.department, b.borrow_date, b.due_date, b.return_date, b.status, b.approval_status 
            FROM borrowings b 
            JOIN equipment e ON b.equipment_id = e.equipment_id 
            JOIN users u ON b.user_id = u.user_id 
            WHERE 1=1";
    
    if (!empty($status)) {
        $sql .= " AND b.status = '" . $conn->real_escape_string($status) . "'";
    }
    
    if (!empty($approval_status)) {
        $sql .= " AND b.approval_status = '" . $conn->real_escape_string($approval_status) . "'";
    }
    
    if (!empty($date_from)) {
        $sql .= " AND b.borrow_date >= '" . $conn->real_escape_string($date_from) . "'";
    }
    
    if (!empty($date_to)) {
        $sql .= " AND b.borrow_date <= '" . $conn->real_escape_string($date_to) . "'";
    }
    
    if (!empty($user_id)) {
        $sql .= " AND b.user_id = " . $conn->real_escape_string($user_id);
    }
    
    $sql .= " ORDER BY b.borrowing_id DESC";
    
    // Check SQL query execution
    $result = $conn->query($sql);
    if (!$result) {
        error_log("SQL Error in generateBorrowingsReport: " . $conn->error);
        $pdf->Cell(0, 10, 'An error occurred while generating the report. Please try again later.', 0, 1, 'C');
        $pdf->Output('borrowings_report.pdf', 'D');
        exit();
    }
   
    if ($result->num_rows > 0) {
        // Filter information
        $pdf->SetFont('Arial', 'I', 10);
        $filterText = 'Filters: ';
        $filterText .= !empty($status) ? 'Status: ' . ucfirst($status) : 'All Statuses';
        $filterText .= !empty($approval_status) ? ', Approval: ' . ucfirst($approval_status) : '';
        $filterText .= !empty($date_from) ? ', From: ' . formatDate($date_from) : '';
        $filterText .= !empty($date_to) ? ', To: ' . formatDate($date_to) : '';
        $filterText .= !empty($user_id) ? ', User: ' . getUserName($conn, $user_id) : '';
        
        $pdf->Cell(0, 5, $filterText, 0, 1, 'L');
        $pdf->Ln(5);
        
        // Table headers
        $header = array('ID', 'Equipment', 'Borrower', 'Department', 'Borrow Date', 'Due Date', 'Status');
        $pdf->TableHeader($header);
        
        // Table data
        while ($row = $result->fetch_assoc()) {
            $data = array(
                $row['borrowing_id'],
                $row['equipment_name'],
                $row['borrower'],
                $row['department'],
                formatDate($row['borrow_date']),
                formatDate($row['due_date']),
                ucfirst($row['status'])
            );
            $pdf->TableRow($data, count($header));
        }
        
        // Summary
        $pdf->Ln(10);
        $pdf->SetFont('Arial', 'B', 11);
        $pdf->Cell(0, 10, 'Summary', 0, 1, 'L');
        
        // Borrowing status counts
        $sql_summary = "SELECT status, COUNT(*) as count FROM borrowings";
        $where_clauses = [];
        
        if (!empty($status)) {
            $where_clauses[] = "status = '" . $conn->real_escape_string($status) . "'";
        }
        
        if (!empty($approval_status)) {
            $where_clauses[] = "approval_status = '" . $conn->real_escape_string($approval_status) . "'";
        }
        
        if (!empty($date_from)) {
            $where_clauses[] = "borrow_date >= '" . $conn->real_escape_string($date_from) . "'";
        }
        
        if (!empty($date_to)) {
            $where_clauses[] = "borrow_date <= '" . $conn->real_escape_string($date_to) . "'";
        }
        
        if (!empty($user_id)) {
            $where_clauses[] = "user_id = " . $conn->real_escape_string($user_id);
        }
        
        if (!empty($where_clauses)) {
            $sql_summary .= " WHERE " . implode(" AND ", $where_clauses);
        }
        
        $sql_summary .= " GROUP BY status";
        
        $result_summary = $conn->query($sql_summary);
        
        $pdf->SetFont('Arial', '', 10);
        while ($row = $result_summary->fetch_assoc()) {
            $pdf->Cell(0, 6, ucfirst($row['status']) . ': ' . $row['count'] . ' borrowings', 0, 1, 'L');
        }
        
        // Overdue count
        $sql_overdue = "SELECT COUNT(*) as count FROM borrowings 
                    WHERE due_date < CURDATE() AND status = 'active'";
        
        if (!empty($approval_status)) {
            $sql_overdue .= " AND approval_status = '" . $conn->real_escape_string($approval_status) . "'";
        }
        
        if (!empty($date_from)) {
            $sql_overdue .= " AND borrow_date >= '" . $conn->real_escape_string($date_from) . "'";
        }
        
        if (!empty($date_to)) {
            $sql_overdue .= " AND borrow_date <= '" . $conn->real_escape_string($date_to) . "'";
        }
        
        if (!empty($user_id)) {
            $sql_overdue .= " AND user_id = " . $conn->real_escape_string($user_id);
        }
        
        $result_overdue = $conn->query($sql_overdue);
        $row_overdue = $result_overdue->fetch_assoc();
        
        $pdf->Ln(5);
        $pdf->Cell(0, 6, 'Overdue Items: ' . $row_overdue['count'], 0, 1, 'L');
    } else {
        $pdf->Cell(0, 10, 'No borrowing records found matching the criteria.', 0, 1, 'C');
    }
    
    $pdf->Output('borrowings_report.pdf', 'D');
    exit();
}