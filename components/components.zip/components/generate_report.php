<?php
session_start();
require_once '../php/db_connection.php';
require_once 'fpdf/fpdf.php'; 

if (!isLoggedIn() || !isAdmin()) {
    header("Location: index.php");
    exit();
}

// Get report parameters
$report_type = $_POST['report_type'] ?? '';

if (empty($report_type)) {
    $_SESSION['error'] = "Report type is required";
    header("Location: ../php/reports.php");
    exit();
}

// Start output buffering to prevent premature output
ob_start();

// Create PDF report
class PDF extends FPDF {
    // Page header
    function Header() {
        // Logo
        $this->Image('../assets/images/logo.png', 10, 6, 30);
        // Arial bold 15
        $this->SetFont('Arial', 'B', 15);
        // Move to the right
        $this->Cell(80);
        // Title
        $this->Cell(30, 10, 'PLP GSO Management System Report', 0, 0, 'C');
        // Line break
        $this->Ln(20);
    }

    // Page footer
    function Footer() {
        // Position at 1.5 cm from bottom
        $this->SetY(-15);
        // Arial italic 8
        $this->SetFont('Arial', 'I', 8);
        // Page number
        $this->Cell(0, 10, 'Page ' . $this->PageNo() . '/{nb}', 0, 0, 'C');
        // Date generated
        $this->Cell(-30, 10, 'Generated on: ' . date('Y-m-d H:i:s'), 0, 0, 'R');
    }
    
    // Table header
    function TableHeader($header) {
        $this->SetFont('Arial', 'B', 10);
        $this->SetFillColor(200, 220, 255);
        $width = $this->GetPageWidth() - 20;
        $col_width = $width / count($header);
        
        foreach($header as $col) {
            $this->Cell($col_width, 7, $col, 1, 0, 'C', true);
        }
        $this->Ln();
    }
    
    // Table row
    function TableRow($data, $header_count) {
        $this->SetFont('Arial', '', 9);
        $width = $this->GetPageWidth() - 20;
        $col_width = $width / $header_count;
        
        foreach($data as $col) {
            $this->Cell($col_width, 6, $col, 1);
        }
        $this->Ln();
    }
}

// Initialize PDF
$pdf = new PDF();
$pdf->AliasNbPages();
$pdf->AddPage();
$pdf->SetFont('Arial', '', 12);

// Generate report based on type
switch ($report_type) {
    case 'equipment':
        generateEquipmentReport($pdf, $conn);
        break;
    case 'borrowings':
        generateBorrowingsReport($pdf, $conn);
        break;
    case 'maintenance':
        generateMaintenanceReport($pdf, $conn);
        break;
    case 'usage':
        generateUsageReport($pdf, $conn);
        break;
    default:
        $_SESSION['error'] = "Invalid report type";
        header("Location: ../php/reports.php");
        exit();
}

// Equipment inventory report
function generateEquipmentReport($pdf, $conn) {
    $pdf->SetFont('Arial', 'B', 14);
    $pdf->Cell(0, 10, 'Equipment Inventory Report', 0, 1, 'C');
    $pdf->Ln(5);
    
    // Get filters
    $status = $_POST['status'] ?? '';
    $category = $_POST['category_id'] ?? '';
    
    // Build SQL query
    $sql = "SELECT e.equipment_id, e.name, c.name as category, e.status, e.acquisition_date, e.condition_status 
            FROM equipment e 
            LEFT JOIN categories c ON e.category_id = c.category_id 
            WHERE 1=1";
    
    if (!empty($status)) {
        $sql .= " AND (e.status = 'available' OR e.status = 'borrowed')"; // Include borrowed equipment
    }
    
    if (!empty($category)) {
        $sql .= " AND e.category_id = " . $conn->real_escape_string($category);
    }
    
    $sql .= " ORDER BY e.equipment_id";
    
    // Check SQL query execution
    $result = $conn->query($sql);
    if (!$result) {
        error_log("SQL Error in generateEquipmentReport: " . $conn->error);
        $pdf->Cell(0, 10, 'An error occurred while generating the report. Please try again later.', 0, 1, 'C');
        $pdf->Output('equipment_report.pdf', 'D');
        exit();
    }
    
    // Debug SQL query (optional, for development)
    error_log("SQL Query: " . $sql);
    
    if ($result->num_rows > 0) {
        // Filter information
        $pdf->SetFont('Arial', 'I', 10);
        $pdf->Cell(0, 5, 'Filters: ' . 
            (!empty($status) ? 'Status: ' . ucfirst($status) : 'All Statuses') . ', ' . 
            (!empty($category) ? 'Category: ' . getCategoryName($conn, $category) : 'All Categories'),
            0, 1, 'L');
        $pdf->Ln(5);
        
        // Table headers
        $header = array('ID', 'Name', 'Category', 'Status', 'Acquisition Date', 'Condition');
        $pdf->TableHeader($header);
        
        // Table data
        while ($row = $result->fetch_assoc()) {
            $data = array(
                $row['equipment_id'],
                $row['name'],
                $row['category'],
                ucfirst($row['status']),
                formatDate($row['acquisition_date']),
                ucfirst($row['condition_status'])
            );
            $pdf->TableRow($data, count($header));
        }
        
        // Summary
        $pdf->Ln(10);
        $pdf->SetFont('Arial', 'B', 11);
        $pdf->Cell(0, 10, 'Summary', 0, 1, 'L');
        
        // Equipment status counts
        $sql_summary = "SELECT status, COUNT(*) as count FROM equipment";
        if (!empty($status)) {
            $sql_summary .= " WHERE status = '" . $conn->real_escape_string($status) . "'";
        } elseif (!empty($category)) {
            $sql_summary .= " WHERE category_id = " . $conn->real_escape_string($category);
        }
        $sql_summary .= " GROUP BY status";
        
        $result_summary = $conn->query($sql_summary);
        
        $pdf->SetFont('Arial', '', 10);
        while ($row = $result_summary->fetch_assoc()) {
            $pdf->Cell(0, 6, ucfirst($row['status']) . ': ' . $row['count'] . ' items', 0, 1, 'L');
        }
        
        // Total value
        $sql_value = "SELECT SUM(purchase_cost) as total FROM equipment";
        if (!empty($status)) {
            $sql_value .= " WHERE status = '" . $conn->real_escape_string($status) . "'";
        } elseif (!empty($category)) {
            $sql_value .= " WHERE category_id = " . $conn->real_escape_string($category);
        }
        
        $result_value = $conn->query($sql_value);
        if (!$result_value) {
            error_log("SQL Error in generateEquipmentReport (value query): " . $conn->error);
            $pdf->Ln(5);
            $pdf->Cell(0, 6, 'Error calculating total value', 0, 1, 'L');
        } else {
            $row_value = $result_value->fetch_assoc();
            $pdf->Ln(5);
            $pdf->Cell(0, 6, 'Total Inventory Value: $' . number_format($row_value['total'] ?? 0, 2), 0, 1, 'L');
        }
    } else {
        $pdf->Cell(0, 10, 'No equipment records found matching the criteria.', 0, 1, 'C');
    }
    
    $pdf->Output('equipment_report.pdf', 'D');
    exit();
}

// Borrowings report
function generateBorrowingsReport($pdf, $conn) {
    $pdf->SetFont('Arial', 'B', 14);
    $pdf->Cell(0, 10, 'Borrowings Report', 0, 1, 'C');
    $pdf->Ln(5);
    
    // Get filters
    $status = $_POST['status'] ?? '';
    $approval_status = $_POST['approval_status'] ?? '';
    $date_from = $_POST['date_from'] ?? '';
    $date_to = $_POST['date_to'] ?? '';
    $user_id = $_POST['user_id'] ?? '';
    
    // Build SQL query
    $sql = "SELECT b.borrowing_id, e.name as equipment_name, CONCAT(u.first_name, ' ', u.last_name) as borrower, 
            u.department, b.borrow_date, b.due_date, b.return_date, b.status, b.approval_status 
            FROM borrowings b 
            JOIN equipment e ON b.equipment_id = e.equipment_id 
            JOIN users u ON b.user_id = u.user_id 
            WHERE 1=1";
    
    if (!empty($status)) {
        $sql .= " AND b.status = '" . $conn->real_escape_string($status) . "'";
    }
    
    if (!empty($approval_status)) {
        $sql .= " AND b.approval_status = '" . $conn->real_escape_string($approval_status) . "'";
    }
    
    if (!empty($date_from)) {
        $sql .= " AND b.borrow_date >= '" . $conn->real_escape_string($date_from) . "'";
    }
    
    if (!empty($date_to)) {
        $sql .= " AND b.borrow_date <= '" . $conn->real_escape_string($date_to) . "'";
    }
    
    if (!empty($user_id)) {
        $sql .= " AND b.user_id = " . $conn->real_escape_string($user_id);
    }
    
    $sql .= " ORDER BY b.borrowing_id DESC";
    
    // Check SQL query execution
    $result = $conn->query($sql);
    if (!$result) {
        die("SQL Error: " . $conn->error);
    }
    
    // Debug SQL query (optional, for development)
    error_log("SQL Query: " . $sql);
    
    if ($result->num_rows > 0) {
        // Filter information
        $pdf->SetFont('Arial', 'I', 10);
        $filterText = 'Filters: ';
        $filterText .= !empty($status) ? 'Status: ' . ucfirst($status) : 'All Statuses';
        $filterText .= !empty($approval_status) ? ', Approval: ' . ucfirst($approval_status) : '';
        $filterText .= !empty($date_from) ? ', From: ' . formatDate($date_from) : '';
        $filterText .= !empty($date_to) ? ', To: ' . formatDate($date_to) : '';
        $filterText .= !empty($user_id) ? ', User: ' . getUserName($conn, $user_id) : '';
        
        $pdf->Cell(0, 5, $filterText, 0, 1, 'L');
        $pdf->Ln(5);
        
        // Table headers
        $header = array('ID', 'Equipment', 'Borrower', 'Department', 'Borrow Date', 'Due Date', 'Status');
        $pdf->TableHeader($header);
        
        // Table data
        while ($row = $result->fetch_assoc()) {
            $data = array(
                $row['borrowing_id'],
                $row['equipment_name'],
                $row['borrower'],
                $row['department'],
                formatDate($row['borrow_date']),
                formatDate($row['due_date']),
                ucfirst($row['status'])
            );
            $pdf->TableRow($data, count($header));
        }
        
        // Summary
        $pdf->Ln(10);
        $pdf->SetFont('Arial', 'B', 11);
        $pdf->Cell(0, 10, 'Summary', 0, 1, 'L');
        
        // Borrowing status counts
        $sql_summary = "SELECT status, COUNT(*) as count FROM borrowings";
        $where_clauses = [];
        
        if (!empty($status)) {
            $where_clauses[] = "status = '" . $conn->real_escape_string($status) . "'";
        }
        
        if (!empty($approval_status)) {
            $where_clauses[] = "approval_status = '" . $conn->real_escape_string($approval_status) . "'";
        }
        
        if (!empty($date_from)) {
            $where_clauses[] = "borrow_date >= '" . $conn->real_escape_string($date_from) . "'";
        }
        
        if (!empty($date_to)) {
            $where_clauses[] = "borrow_date <= '" . $conn->real_escape_string($date_to) . "'";
        }
        
        if (!empty($user_id)) {
            $where_clauses[] = "user_id = " . $conn->real_escape_string($user_id);
        }
        
        if (!empty($where_clauses)) {
            $sql_summary .= " WHERE " . implode(" AND ", $where_clauses);
        }
        
        $sql_summary .= " GROUP BY status";
        
        $result_summary = $conn->query($sql_summary);
        
        $pdf->SetFont('Arial', '', 10);
        while ($row = $result_summary->fetch_assoc()) {
            $pdf->Cell(0, 6, ucfirst($row['status']) . ': ' . $row['count'] . ' borrowings', 0, 1, 'L');
        }
        
        // Overdue count
        $sql_overdue = "SELECT COUNT(*) as count FROM borrowings 
                    WHERE due_date < CURDATE() AND status = 'active'";
        
        if (!empty($approval_status)) {
            $sql_overdue .= " AND approval_status = '" . $conn->real_escape_string($approval_status) . "'";
        }
        
        if (!empty($date_from)) {
            $sql_overdue .= " AND borrow_date >= '" . $conn->real_escape_string($date_from) . "'";
        }
        
        if (!empty($date_to)) {
            $sql_overdue .= " AND borrow_date <= '" . $conn->real_escape_string($date_to) . "'";
        }
        
        if (!empty($user_id)) {
            $sql_overdue .= " AND user_id = " . $conn->real_escape_string($user_id);
        }
        
        $result_overdue = $conn->query($sql_overdue);
        $row_overdue = $result_overdue->fetch_assoc();
        
        $pdf->Ln(5);
        $pdf->Cell(0, 6, 'Overdue Items: ' . $row_overdue['count'], 0, 1, 'L');
    } else {
        $pdf->Cell(0, 10, 'No borrowing records found matching the criteria.', 0, 1, 'C');
    }
    
    $pdf->Output('borrowings_report.pdf', 'D');
    exit();
}

// Maintenance report
function generateMaintenanceReport($pdf, $conn) {
    $pdf->SetFont('Arial', 'B', 14);
    $pdf->Cell(0, 10, 'Maintenance Report', 0, 1, 'C');
    $pdf->Ln(5);
    
    // Get filters
    $status = $_POST['status'] ?? '';
    $date_from = $_POST['date_from'] ?? '';
    $date_to = $_POST['date_to'] ?? '';
    $show_cost = isset($_POST['show_cost']) && $_POST['show_cost'] == 'on';
    $sum_cost = isset($_POST['sum_cost']) && $_POST['sum_cost'] == 'on';
    
    // Build SQL query
    $sql = "SELECT m.maintenance_id, e.name as equipment_name, m.maintenance_date, m.resolved_date, m.status, m.cost 
            FROM maintenance m 
            JOIN equipment e ON m.equipment_id = e.equipment_id 
            WHERE 1=1";
    
    if (!empty($status)) {
        $sql .= " AND m.status = '" . $conn->real_escape_string($status) . "'";
    }
    
    if (!empty($date_from)) {
        $sql .= " AND m.maintenance_date >= '" . $conn->real_escape_string($date_from) . "'";
    }
    
    if (!empty($date_to)) {
        $sql .= " AND m.maintenance_date <= '" . $conn->real_escape_string($date_to) . "'";
    }
    
    $sql .= " ORDER BY m.maintenance_id DESC";
    
    // Check SQL query execution
    $result = $conn->query($sql);
    if (!$result) {
        die("SQL Error: " . $conn->error);
    }
    
    // Debug SQL query (optional, for development)
    error_log("SQL Query: " . $sql);
    
    if ($result->num_rows > 0) {
        // Filter information
        $pdf->SetFont('Arial', 'I', 10);
        $filterText = 'Filters: ';
        $filterText .= !empty($status) ? 'Status: ' . ucfirst($status) : 'All Statuses';
        $filterText .= !empty($date_from) ? ', From: ' . formatDate($date_from) : '';
        $filterText .= !empty($date_to) ? ', To: ' . formatDate($date_to) : '';
        
        $pdf->Cell(0, 5, $filterText, 0, 1, 'L');
        $pdf->Ln(5);
        
        // Table headers
        $header = array('ID', 'Equipment', 'Start Date', 'End Date', 'Status');
        if ($show_cost) {
            $header[] = 'Cost';
        }
        $pdf->TableHeader($header);
        
        // Table data
        $total_cost = 0;
        while ($row = $result->fetch_assoc()) {
            $data = array(
                $row['maintenance_id'],
                $row['equipment_name'],
                formatDate($row['maintenance_date']),
                formatDate($row['resolved_date']),
                ucfirst($row['status'])
            );
            
            if ($show_cost) {
                $data[] = '$' . number_format($row['cost'], 2);
                $total_cost += $row['cost'];
            }
            
            $pdf->TableRow($data, count($header));
        }
        
        // Summary
        $pdf->Ln(10);
        $pdf->SetFont('Arial', 'B', 11);
        $pdf->Cell(0, 10, 'Summary', 0, 1, 'L');
        
        // Maintenance status counts
        $sql_summary = "SELECT status, COUNT(*) as count FROM maintenance";
        $where_clauses = [];
        
        if (!empty($status)) {
            $where_clauses[] = "status = '" . $conn->real_escape_string($status) . "'";
        }
        
        if (!empty($date_from)) {
            $where_clauses[] = "maintenance_date >= '" . $conn->real_escape_string($date_from) . "'";
        }
        
        if (!empty($date_to)) {
            $where_clauses[] = "maintenance_date <= '" . $conn->real_escape_string($date_to) . "'";
        }
        
        if (!empty($where_clauses)) {
            $sql_summary .= " WHERE " . implode(" AND ", $where_clauses);
        }
        
        $sql_summary .= " GROUP BY status";
        
        $result_summary = $conn->query($sql_summary);
        
        $pdf->SetFont('Arial', '', 10);
        while ($row = $result_summary->fetch_assoc()) {
            $pdf->Cell(0, 6, ucfirst($row['status']) . ': ' . $row['count'] . ' maintenance records', 0, 1, 'L');
        }
        
        // Total cost if requested
        if ($sum_cost) {
            $pdf->Ln(5);
            $pdf->Cell(0, 6, 'Total Maintenance Cost: $' . number_format($total_cost, 2), 0, 1, 'L');
        }
    } else {
        $pdf->Cell(0, 10, 'No maintenance records found matching the criteria.', 0, 1, 'C');
    }
    
    $pdf->Output('maintenance_report.pdf', 'D');
    exit();
}

// Usage report
function generateUsageReport($pdf, $conn) {
    $pdf->SetFont('Arial', 'B', 14);
    $pdf->Cell(0, 10, 'Equipment Usage Report', 0, 1, 'C');
    $pdf->Ln(5);
    
    // Get filters
    $period = $_POST['usage-period'] ?? '';
    $date_from = '';
    $date_to = '';
    
    // Calculate date range based on period
    if ($period == 'custom') {
        $date_from = $_POST['usage-date-from'] ?? '';
        $date_to = $_POST['usage-date-to'] ?? '';
    } else {
        $today = date('Y-m-d');
        
        switch ($period) {
            case 'last-30':
                $date_from = date('Y-m-d', strtotime('-30 days'));
                $date_to = $today;
                break;
            case 'last-90':
                $date_from = date('Y-m-d', strtotime('-90 days'));
                $date_to = $today;
                break;
            case 'this-month':
                $date_from = date('Y-m-01');
                $date_to = date('Y-m-t');
                break;
            case 'last-month':
                $date_from = date('Y-m-01', strtotime('-1 month'));
                $date_to = date('Y-m-t', strtotime('-1 month'));
                break;
            case 'this-year':
                $date_from = date('Y-01-01');
                $date_to = date('Y-12-31');
                break;
            default:
                // All time - no date restriction
                break;
        }
    }
    
    // Equipment usage statistics
    $pdf->SetFont('Arial', 'B', 12);
    $pdf->Cell(0, 10, 'Most Borrowed Equipment', 0, 1, 'L');
    
    $sql_popular = "SELECT e.equipment_id, e.name, COUNT(b.borrowing_id) as borrow_count 
                    FROM equipment e 
                    JOIN borrowings b ON e.equipment_id = b.equipment_id 
                    WHERE 1=1";
    
    if (!empty($date_from)) {
        $sql_popular .= " AND b.borrow_date >= '" . $conn->real_escape_string($date_from) . "'";
    }
    
    if (!empty($date_to)) {
        $sql_popular .= " AND b.borrow_date <= '" . $conn->real_escape_string($date_to) . "'";
    }
    
    $sql_popular .= " GROUP BY e.equipment_id 
                    ORDER BY borrow_count DESC 
                    LIMIT 10";
    
    // Check SQL query execution
    $result_popular = $conn->query($sql_popular);
    if (!$result_popular) {
        die("SQL Error: " . $conn->error);
    }
    
    // Debug SQL query (optional, for development)
    error_log("SQL Query: " . $sql_popular);
    
    if ($result_popular->num_rows > 0) {
        // Filter information
        $pdf->SetFont('Arial', 'I', 10);
        $filterText = 'Period: ';
        
        switch ($period) {
            case 'last-30':
                $filterText .= 'Last 30 Days';
                break;
            case 'last-90':
                $filterText .= 'Last 90 Days';
                break;
            case 'this-month':
                $filterText .= 'This Month';
                break;
            case 'last-month':
                $filterText .= 'Last Month';
                break;
            case 'this-year':
                $filterText .= 'This Year';
                break;
            case 'custom':
                $filterText .= 'From ' . formatDate($date_from) . ' To ' . formatDate($date_to);
                break;
            default:
                $filterText .= 'All Time';
                break;
        }
        
        $pdf->Cell(0, 5, $filterText, 0, 1, 'L');
        $pdf->Ln(5);
        
        // Table headers
        $header = array('Equipment ID', 'Equipment Name', 'Times Borrowed');
        $pdf->TableHeader($header);
        
        // Table data
        while ($row = $result_popular->fetch_assoc()) {
            $data = array(
                $row['equipment_id'],
                $row['name'],
                $row['borrow_count']
            );
            $pdf->TableRow($data, count($header));
        }
        
        // Department usage statistics
        $pdf->Ln(15);
        $pdf->SetFont('Arial', 'B', 12);
        $pdf->Cell(0, 10, 'Department Usage Statistics', 0, 1, 'L');
        
        $sql_departments = "SELECT u.department, COUNT(b.borrowing_id) as borrow_count 
                            FROM borrowings b 
                            JOIN users u ON b.user_id = u.user_id 
                            WHERE u.department IS NOT NULL AND u.department != ''";
        
        if (!empty($date_from)) {
            $sql_departments .= " AND b.borrow_date >= '" . $conn->real_escape_string($date_from) . "'";
        }
        
        if (!empty($date_to)) {
            $sql_departments .= " AND b.borrow_date <= '" . $conn->real_escape_string($date_to) . "'";
        }
        
        $sql_departments .= " GROUP BY u.department 
                            ORDER BY borrow_count DESC";
        
        // Check SQL query execution
        $result_departments = $conn->query($sql_departments);
        if (!$result_departments) {
            die("SQL Error: " . $conn->error);
        }
        
        // Debug SQL query (optional, for development)
        error_log("SQL Query: " . $sql_departments);
        
        if ($result_departments->num_rows > 0) {
            // Table headers
            $header = array('Department', 'Number of Borrowings');
            $pdf->TableHeader($header);
            
            // Table data
            while ($row = $result_departments->fetch_assoc()) {
                $data = array(
                    $row['department'],
                    $row['borrow_count']
                );
                $pdf->TableRow($data, count($header));
            }
        } else {
            $pdf->Cell(0, 10, 'No department usage data available for the selected period.', 0, 1, 'C');
        }
        
        // Borrowing duration statistics
        $pdf->Ln(15);
        $pdf->SetFont('Arial', 'B', 12);
        $pdf->Cell(0, 10, 'Average Borrowing Duration', 0, 1, 'L');
        
        $sql_duration = "SELECT e.category_id, c.name as category_name, 
                        AVG(DATEDIFF(IFNULL(b.return_date, CURDATE()), b.borrow_date)) as avg_days
                        FROM borrowings b 
                        JOIN equipment e ON b.equipment_id = e.equipment_id
                        JOIN categories c ON e.category_id = c.category_id
                        WHERE b.status = 'returned'";
        
        if (!empty($date_from)) {
            $sql_duration .= " AND b.borrow_date >= '" . $conn->real_escape_string($date_from) . "'";
        }
        
        if (!empty($date_to)) {
            $sql_duration .= " AND b.borrow_date <= '" . $conn->real_escape_string($date_to) . "'";
        }
        
        $sql_duration .= " GROUP BY e.category_id
                        ORDER BY avg_days DESC";
        
        // Check SQL query execution
        $result_duration = $conn->query($sql_duration);
        if (!$result_duration) {
            die("SQL Error: " . $conn->error);
        }
        
        // Debug SQL query (optional, for development)
        error_log("SQL Query: " . $sql_duration);
        
        if ($result_duration->num_rows > 0) {
            // Table headers
            $header = array('Equipment Category', 'Average Days Borrowed');
            $pdf->TableHeader($header);
            
            // Table data
            while ($row = $result_duration->fetch_assoc()) {
                $data = array(
                    $row['category_name'],
                    round($row['avg_days'], 1)
                );
                $pdf->TableRow($data, count($header));
            }
        } else {
            $pdf->Cell(0, 10, 'No borrowing duration data available for the selected period.', 0, 1, 'C');
        }
    } else {
        $pdf->Cell(0, 10, 'No usage data available for the selected period.', 0, 1, 'C');
    }
    
    $pdf->Output('usage_report.pdf', 'D');
    exit();
}

// Helper functions
function formatDate($date) {
    if (empty($date) || $date == '0000-00-00') {
        return 'N/A';
    }
    return date('M d, Y', strtotime($date));
}

function getCategoryName($conn, $category_id) {
    $sql = "SELECT name FROM categories WHERE category_id = " . $conn->real_escape_string($category_id);
    $result = $conn->query($sql);
    if ($result->num_rows > 0) {
        $row = $result->fetch_assoc();
        return $row['name'];
    }
    return 'Unknown';
}

function getUserName($conn, $user_id) {
    $sql = "SELECT CONCAT(first_name, ' ', last_name) as name FROM users WHERE user_id = " . $conn->real_escape_string($user_id);
    $result = $conn->query($sql);
    if ($result->num_rows > 0) {
        $row = $result->fetch_assoc();
        return $row['name'];
    }
    return 'Unknown';
}