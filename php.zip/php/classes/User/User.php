<?php
require_once 'UserBase.php';
require_once 'UserManager.php';
require_once 'UserAuth.php';
require_once 'UserStatus.php';
require_once 'UserValidator.php';

class User extends UserBase {
    private $userAuth;
    private $userStatus;

    public function __construct($conn) {
        parent::__construct($conn);
        $this->userAuth = null;
        $this->userStatus = null;
    }
    
    public function load($user_id) {
        $result = parent::load($user_id);
        
        if ($result) {
            $this->initializeComponents();
        }
        
        return $result;
    }

    public function setData($data) {
        parent::setData($data);
        $this->initializeComponents();
    }

    private function initializeComponents() {
        $this->userAuth = new UserAuth($this->conn, $this->password, $this->role);
        $this->userStatus = new UserStatus($this->conn, $this->user_id, $this->status, $this->status_changed_at);
    }

    public function create($data) {
        $errors = UserValidator::validateData($data);
        if (!empty($errors)) {
            return ['success' => false, 'message' => implode("<br>", $errors)];
        }

        if ($this->emailExists($data['email'])) {
            return ['success' => false, 'message' => 'Email address already in use'];
        }

        $hashed_password = password_hash($data['password'], PASSWORD_DEFAULT);

        $phone = $data['phone'] ?? '';
        $program_year_section = ($data['role'] === 'student') ? ($data['program_year_section'] ?? '') : '';
        
        $sql = "INSERT INTO users (
            university_id,
            first_name, 
            last_name, 
            email, 
            password, 
            role, 
            department,
            phone,
            program_year_section,
            created_at,
            updated_at
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, NOW(), NOW())";
        
        $stmt = $this->conn->prepare($sql);
        
        if ($stmt === false) {
            return ['success' => false, 'message' => 'Error preparing statement: ' . $this->conn->error];
        }

        $stmt->bind_param("sssssssss", 
            $data['university_id'],
            $data['first_name'], 
            $data['last_name'], 
            $data['email'], 
            $hashed_password, 
            $data['role'], 
            $data['department'],
            $phone,
            $program_year_section
        );
        
        if ($stmt->execute()) {
            $this->user_id = $stmt->insert_id;
            $this->setData($data);
            return ['success' => true, 'message' => 'User added successfully.'];
        } else {
            return ['success' => false, 'message' => 'Error adding user: ' . $stmt->error];
        }
    }

    public function update($data) {
        $errors = UserValidator::validateData($data, false);
        if (!empty($errors)) {
            return ['success' => false, 'message' => implode("<br>", $errors)];
        }

        if ($this->emailExists($data['email'], $this->user_id)) {
            return ['success' => false, 'message' => 'Email address already in use'];
        }

        $password_update = !empty($data['password']);
        if ($password_update) {
            if (strlen($data['password']) < 8) {
                return ['success' => false, 'message' => 'Password must be at least 8 characters long'];
            }
            
            if ($data['password'] !== $data['confirm_password']) {
                return ['success' => false, 'message' => 'Passwords do not match'];
            }
        }

        $phone = $data['phone'] ?? '';
        $program_year_section = ($data['role'] === 'student') ? ($data['program_year_section'] ?? '') : '';
        
        if ($password_update) {
            $hashed_password = password_hash($data['password'], PASSWORD_DEFAULT);
            $sql = "UPDATE users 
                    SET university_id = ?,
                        first_name = ?, 
                        last_name = ?, 
                        email = ?, 
                        password = ?,
                        role = ?, 
                        department = ?,
                        phone = ?,
                        program_year_section = ?,
                        updated_at = NOW() 
                    WHERE user_id = ?";
            
            $stmt = $this->conn->prepare($sql);
            
            if ($stmt === false) {
                return ['success' => false, 'message' => 'Error preparing statement: ' . $this->conn->error];
            }
            
            $stmt->bind_param("sssssssssi", 
                $data['university_id'],
                $data['first_name'], 
                $data['last_name'], 
                $data['email'], 
                $hashed_password,
                $data['role'], 
                $data['department'],
                $phone,
                $program_year_section,
                $this->user_id
            );
        } else {
            $sql = "UPDATE users 
                    SET university_id = ?,
                        first_name = ?, 
                        last_name = ?, 
                        email = ?, 
                        role = ?, 
                        department = ?,
                        phone = ?,
                        program_year_section = ?,
                        updated_at = NOW() 
                    WHERE user_id = ?";
            
            $stmt = $this->conn->prepare($sql);
            
            if ($stmt === false) {
                return ['success' => false, 'message' => 'Error preparing statement: ' . $this->conn->error];
            }
            
            $stmt->bind_param("ssssssssi", 
                $data['university_id'],
                $data['first_name'], 
                $data['last_name'], 
                $data['email'], 
                $data['role'], 
                $data['department'],
                $phone,
                $program_year_section,
                $this->user_id
            );
        }
        
        if ($stmt->execute()) {
            $this->setData($data);
            return ['success' => true, 'message' => 'User updated successfully.'];
        } else {
            return ['success' => false, 'message' => 'Error updating user: ' . $stmt->error];
        }
    }

    public function emailExists($email, $current_user_id = null) {
        if (!$this->userAuth) {
            $this->userAuth = new UserAuth($this->conn, $this->password, $this->role);
        }
        return $this->userAuth->emailExists($email, $current_user_id);
    }

    public function setStatus($status) {
        if (!$this->userStatus) {
            $this->userStatus = new UserStatus($this->conn, $this->user_id, $this->status, $this->status_changed_at);
        }
        
        $result = $this->userStatus->setStatus($status);
        if ($result['success']) {
            $this->status = $status;
            $this->status_changed_at = date('Y-m-d H:i:s');
        }
        
        return $result;
    }
    
    public function activate() {
        if (!$this->userStatus) {
            $this->userStatus = new UserStatus($this->conn, $this->user_id, $this->status, $this->status_changed_at);
        }
        
        $result = $this->userStatus->activate();
        if ($result['success']) {
            $this->status = 'active';
            $this->status_changed_at = date('Y-m-d H:i:s');
        }
        
        return $result;
    }
 
    public function deactivate() {
        if (!$this->userStatus) {
            $this->userStatus = new UserStatus($this->conn, $this->user_id, $this->status, $this->status_changed_at);
        }
        
        $result = $this->userStatus->deactivate();
        if ($result['success']) {
            $this->status = 'inactive';
            $this->status_changed_at = date('Y-m-d H:i:s');
        }
        
        return $result;
    }

    public function archive() {
        if (!$this->userStatus) {
            $this->userStatus = new UserStatus($this->conn, $this->user_id, $this->status, $this->status_changed_at);
        }
        
        $result = $this->userStatus->archive();
        if ($result['success']) {
            $this->status = 'archived';
            $this->status_changed_at = date('Y-m-d H:i:s');
        }
        
        return $result;
    }

    public function delete() {
        if (!$this->userStatus) {
            $this->userStatus = new UserStatus($this->conn, $this->user_id, $this->status, $this->status_changed_at);
        }
        
        return $this->userStatus->delete();
    }

    public function verifyPassword($password) {
        if (!$this->userAuth) {
            $this->userAuth = new UserAuth($this->conn, $this->password, $this->role);
        }
        
        return $this->userAuth->verifyPassword($password);
    }

    public function isAdmin() {
        if (!$this->userAuth) {
            $this->userAuth = new UserAuth($this->conn, $this->password, $this->role);
        }
        
        return $this->userAuth->isAdmin();
    }

    public function isFaculty() {
        if (!$this->userAuth) {
            $this->userAuth = new UserAuth($this->conn, $this->password, $this->role);
        }
        
        return $this->userAuth->isFaculty();
    }

    public function isStudent() {
        if (!$this->userAuth) {
            $this->userAuth = new UserAuth($this->conn, $this->password, $this->role);
        }
        
        return $this->userAuth->isStudent();
    }
 
    public function isStaff() {
        if (!$this->userAuth) {
            $this->userAuth = new UserAuth($this->conn, $this->password, $this->role);
        }
        
        return $this->userAuth->isStaff();
    }
    
    public function isActive() {
        if (!$this->userStatus) {
            $this->userStatus = new UserStatus($this->conn, $this->user_id, $this->status, $this->status_changed_at);
        }
        
        return $this->userStatus->isActive();
    }
  
    public function isInactive() {
        if (!$this->userStatus) {
            $this->userStatus = new UserStatus($this->conn, $this->user_id, $this->status, $this->status_changed_at);
        }
        
        return $this->userStatus->isInactive();
    }

    public function isArchived() {
        if (!$this->userStatus) {
            $this->userStatus = new UserStatus($this->conn, $this->user_id, $this->status, $this->status_changed_at);
        }
        
        return $this->userStatus->isArchived();
    }
    
    public static function getAll($conn, $filters = []) {
        return UserManager::getAll($conn, $filters);
    }
    
    public static function updateOverdueStatus($conn) {
        return UserManager::updateOverdueStatus($conn);
    }
}
?>