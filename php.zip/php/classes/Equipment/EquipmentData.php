<?php
namespace Equipment;

class EquipmentData {
    protected $conn;
    protected $base;
    
    public function __construct($conn, $base) {
        $this->conn = $conn;
        $this->base = $base;
    }
    
    public function create($data) {
        if (empty($data['name'])) {
            return ['success' => false, 'message' => 'Equipment name is required.'];
        }

        if (empty($data['equipment_code'])) {
            return ['success' => false, 'message' => 'Equipment code is required.'];
        }

        if ($this->codeExists($data['equipment_code'])) {
            return ['success' => false, 'message' => 'A equipment with this code already exists.'];
        }

        $description = $data['description'] ?? '';
        $notes = $data['notes'] ?? '';
        $quantity = isset($data['quantity']) && is_numeric($data['quantity']) && $data['quantity'] > 0 ? $data['quantity'] : 1;
        
        $sql = "INSERT INTO equipment (
            name, 
            description, 
            equipment_code, 
            category_id, 
            condition_status, 
            status, 
            acquisition_date,
            quantity,
            available_quantity,
            notes,
            created_at,
            updated_at
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, NOW(), NOW())";
        
        $stmt = $this->conn->prepare($sql);
        
        if ($stmt === false) {
            return ['success' => false, 'message' => 'Error preparing statement: ' . $this->conn->error];
        }

        $stmt->bind_param("ssssssiiss", 
            $data['name'], 
            $description, 
            $data['equipment_code'], 
            $data['category_id'], 
            $data['condition_status'], 
            $data['status'], 
            $data['acquisition_date'],
            $quantity,
            $quantity,
            $notes
        );
        
        if ($stmt->execute()) {
            $equipment_id = $stmt->insert_id;
            $this->base->load($equipment_id);
            return ['success' => true, 'message' => 'Equipment added successfully.'];
        } else {
            return ['success' => false, 'message' => 'Error adding equipment: ' . $stmt->error];
        }
    }


    public function update($data) {
        if (empty($data['name'])) {
            return ['success' => false, 'message' => 'Equipment name is required.'];
        }
  
        if (empty($data['equipment_code'])) {
            return ['success' => false, 'message' => 'Equipment code is required.'];
        }

        $equipment_id = $this->base->getId();
        if ($this->codeExists($data['equipment_code'], $equipment_id)) {
            return ['success' => false, 'message' => 'Another equipment with this code already exists.'];
        }
        
        $borrowStatusChecker = new EquipmentBorrowing($this->conn, $this->base);
        if (isset($data['status']) && $data['status'] != 'borrowed' && $borrowStatusChecker->isBorrowed()) {
            return ['success' => false, 'message' => 'Cannot change status of equipment that is currently borrowed.'];
        }

        $description = $data['description'] ?? '';
        $notes = $data['notes'] ?? '';
        $quantity = isset($data['quantity']) && is_numeric($data['quantity']) && $data['quantity'] > 0 ? $data['quantity'] : 1;
        
        $borrowed_count = $borrowStatusChecker->getBorrowedCount();
        if ($quantity < $borrowed_count) {
            return ['success' => false, 'message' => "Cannot reduce quantity below currently borrowed amount ($borrowed_count)."];
        }
        
        $available_quantity = $quantity - $borrowed_count;
        
        $sql = "UPDATE equipment 
                SET name = ?, 
                    description = ?, 
                    equipment_code = ?, 
                    category_id = ?, 
                    condition_status = ?, 
                    status = ?, 
                    acquisition_date = ?,
                    quantity = ?,
                    available_quantity = ?,
                    notes = ?,
                    updated_at = NOW() 
                WHERE equipment_id = ?";
        
        $stmt = $this->conn->prepare($sql);
        
        if ($stmt === false) {
            return ['success' => false, 'message' => 'Error preparing statement: ' . $this->conn->error];
        }
        
        $stmt->bind_param("ssssssiissi", 
            $data['name'], 
            $description, 
            $data['equipment_code'], 
            $data['category_id'], 
            $data['condition_status'], 
            $data['status'], 
            $data['acquisition_date'],
            $quantity,
            $available_quantity,
            $notes,
            $equipment_id
        );
        
        if ($stmt->execute()) {
            $this->base->setData($data);
            return ['success' => true, 'message' => 'Equipment updated successfully.'];
        } else {
            return ['success' => false, 'message' => 'Error updating equipment: ' . $stmt->error];
        }
    }
    
 
    public function delete() {
        $borrowStatusChecker = new EquipmentBorrowing($this->conn, $this->base);
        if ($borrowStatusChecker->isBorrowed()) {
            return ['success' => false, 'message' => 'Cannot delete equipment that is currently borrowed.'];
        }
        
        $sql = "DELETE FROM equipment WHERE equipment_id = ?";
        $stmt = $this->conn->prepare($sql);
        if ($stmt === false) {
            return ['success' => false, 'message' => 'Error preparing statement: ' . $this->conn->error];
        }
        
        $stmt->bind_param("i", $this->base->getId());
        
        if ($stmt->execute()) {
            return ['success' => true, 'message' => 'Equipment deleted successfully.'];
        } else {
            return ['success' => false, 'message' => 'Error deleting equipment: ' . $stmt->error];
        }
    }
    
    public function codeExists($code, $exclude_id = null) {
        $sql = "SELECT COUNT(*) as count FROM equipment WHERE equipment_code = ?";
        $params = [$code];
        $types = "s";
        
        if ($exclude_id !== null) {
            $sql .= " AND equipment_id != ?";
            $params[] = $exclude_id;
            $types .= "i";
        }
        
        $stmt = $this->conn->prepare($sql);
        if ($stmt === false) {
            error_log('Error preparing statement in codeExists: ' . $this->conn->error);
            return true;
        }
        
        $stmt->bind_param($types, ...$params);
        $stmt->execute();
        $result = $stmt->get_result();
        return $result->fetch_assoc()['count'] > 0;
    }
}