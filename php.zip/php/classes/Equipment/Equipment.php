<?php
require_once 'EquipmentBase.php';
require_once 'EquipmentData.php';
require_once 'EquipmentStatus.php';
require_once 'EquipmentBorrowing.php';

use Equipment\EquipmentBase;
use Equipment\EquipmentData;
use Equipment\EquipmentStatus;
use Equipment\EquipmentBorrowing;

class Equipment {
    private $base;
    private $data;
    private $status;    
    private $borrowing;
    
    public function __construct($conn) {
        $this->base = new EquipmentBase($conn);
        $this->data = new EquipmentData($conn, $this->base);
        $this->status = new EquipmentStatus($conn, $this->base);
        $this->borrowing = new EquipmentBorrowing($conn, $this->base);
    }

    public function load($equipment_id) {
        return $this->base->load($equipment_id);
    }

    public function setData($data) {
        $this->base->setData($data);
    }

    public function create($data) {
        return $this->data->create($data);
    }

    public function update($data) {
        return $this->data->update($data);
    }
    
    public function delete() {
        return $this->data->delete();
    }
    
    public function updateStatus($new_status) {
        return $this->status->updateStatus($new_status);
    }
    
    public function updateQuantity($new_quantity) {
        return $this->status->updateQuantity($new_quantity);
    }

    public function isBorrowed() {
        return $this->borrowing->isBorrowed();
    }
    
    public function getBorrowedCount() {
        return $this->borrowing->getBorrowedCount();
    }
    
    public function getBorrowingHistory($limit = 10) {
        return $this->borrowing->getBorrowingHistory($limit);
    }
    
    public function getCurrentBorrower() {
        return $this->borrowing->getCurrentBorrower();
    }

    public static function getAll($conn, $filters = []) {
        return EquipmentStatus::getAll($conn, $filters);
    }
    
    public function getId() {
        return $this->base->getId();
    }
    
    public function getName() {
        return $this->base->getName();
    }
    
    public function getDescription() {
        return $this->base->getDescription();
    }
    
    public function getEquipmentCode() {
        return $this->base->getEquipmentCode();
    }
    
    public function getCategoryId() {
        return $this->base->getCategoryId();
    }
    
    public function getConditionStatus() {
        return $this->base->getConditionStatus();
    }
    
    public function getStatus() {
        return $this->base->getStatus();
    }
    
    public function getAcquisitionDate() {
        return $this->base->getAcquisitionDate();
    }
    
    public function getNotes() {
        return $this->base->getNotes();
    }
    
    public function getQuantity() {
        return $this->base->getQuantity();
    }
    
    public function getAvailableQuantity() {
        return $this->base->getAvailableQuantity();
    }
    
    public function getCreatedAt() {
        return $this->base->getCreatedAt();
    }
    
    public function getUpdatedAt() {
        return $this->base->getUpdatedAt();
    }
}