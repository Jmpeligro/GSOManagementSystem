<?php
namespace Equipment;

class EquipmentBorrowing {
    protected $conn;
    protected $base;
    
    public function __construct($conn, $base) {
        $this->conn = $conn;
        $this->base = $base;
    }
    
    public function isBorrowed() {
        $sql = "SELECT COUNT(*) as count FROM borrowings 
                WHERE equipment_id = ? AND status = 'active'";
                
        $stmt = $this->conn->prepare($sql);
        if ($stmt === false) {
            error_log('Error preparing statement in isBorrowed: ' . $this->conn->error);
            return false;
        }
        
        $equipment_id = $this->base->getId();
        $stmt->bind_param("i", $equipment_id);
        $stmt->execute();
        $result = $stmt->get_result();
        
        return $result->fetch_assoc()['count'] > 0;
    }
    
    public function getBorrowedCount() {
        $sql = "SELECT COUNT(*) as count FROM borrowings 
                WHERE equipment_id = ? AND status = 'active'";
                
        $stmt = $this->conn->prepare($sql);
        if ($stmt === false) {
            error_log('Error preparing statement in getBorrowedCount: ' . $this->conn->error);
            return 0;
        }
        
        $equipment_id = $this->base->getId();
        $stmt->bind_param("i", $equipment_id);
        $stmt->execute();
        $result = $stmt->get_result();
        
        return (int)$result->fetch_assoc()['count'];
    }
    
    public function getBorrowingHistory($limit = 10) {
        $sql = "SELECT b.*, u.full_name as borrower_name 
                FROM borrowings b
                JOIN users u ON b.user_id = u.user_id
                WHERE b.equipment_id = ?
                ORDER BY b.created_at DESC
                LIMIT ?";
                
        $stmt = $this->conn->prepare($sql);
        if ($stmt === false) {
            error_log('Error preparing statement in getBorrowingHistory: ' . $this->conn->error);
            return [];
        }
        
        $equipment_id = $this->base->getId();
        $stmt->bind_param("ii", $equipment_id, $limit);
        $stmt->execute();
        $result = $stmt->get_result();
        
        $history = [];
        while ($row = $result->fetch_assoc()) {
            $history[] = $row;
        }
        
        return $history;
    }
    
    public function getCurrentBorrower() {
        $sql = "SELECT b.*, u.full_name as borrower_name, u.email, u.user_id
                FROM borrowings b
                JOIN users u ON b.user_id = u.user_id
                WHERE b.equipment_id = ? AND b.status = 'active'
                ORDER BY b.created_at DESC
                LIMIT 1";
                
        $stmt = $this->conn->prepare($sql);
        if ($stmt === false) {
            error_log('Error preparing statement in getCurrentBorrower: ' . $this->conn->error);
            return null;
        }
        
        $equipment_id = $this->base->getId();
        $stmt->bind_param("i", $equipment_id);
        $stmt->execute();
        $result = $stmt->get_result();
        
        if ($result->num_rows === 0) {
            return null;
        }
        
        return $result->fetch_assoc();
    }
}