<?php
require_once __DIR__ . '/classes/Database.php';
require_once __DIR__ . '/classes/Auth.php';
require_once __DIR__ . '/helpers.php';

$db = Database::getInstance();
$conn = $db->getConnection();


?>