<?php
/**
 * This script checks equipment inventory levels and sends notifications for critical items
 * It is designed to be run as a cron job
 */

// Turn off output buffering
ob_implicit_flush(true);
ob_end_flush();

// Set unlimited execution time for large inventories
set_time_limit(0);

// Log function
function logMessage($message) {
    $date = date('Y-m-d H:i:s');
    echo "[$date] $message" . PHP_EOL;
    
    // Optionally log to file
    $logFile = __DIR__ . '/logs/equipment_levels_' . date('Y-m-d') . '.log';
    $dir = dirname($logFile);
    if (!is_dir($dir)) {
        mkdir($dir, 0755, true);
    }
    
    file_put_contents($logFile, "[$date] $message" . PHP_EOL, FILE_APPEND);
}

// Check if script is running via command line
if (php_sapi_name() !== 'cli') {
    // Allow limited web access with a security token
    $validToken = 'your-secure-token-here'; // Change this to a secure random string
    
    if (!isset($_GET['token']) || $_GET['token'] !== $validToken) {
        header('HTTP/1.0 403 Forbidden');
        echo "Access denied";
        exit;
    }
    
    // Set headers for plain text output
    header('Content-Type: text/plain');
}

// Start logging
logMessage("Starting equipment levels check");

try {
    // Load necessary files
    $baseDir = __DIR__;
    require_once $baseDir . '/db_connection.php';
    require_once $baseDir . '/borrowings/EquipmentThreshold.php';
    
    // Run the equipment check
    logMessage("Running equipment quantity check");
    $criticalItems = checkEquipmentQuantityLevels($conn);
    
    // Log results
    $itemCount = count($criticalItems);
    logMessage("Check completed. Found $itemCount items with critical levels");
    
    if ($itemCount > 0) {
        logMessage("Critical items:");
        foreach ($criticalItems as $item) {
            logMessage("  - {$item['name']} (ID: {$item['id']}): {$item['available_quantity']}/{$item['quantity']}");
        }
    }
    
    // Close connection
    $conn->close();
    
    logMessage("Equipment level check completed successfully");
} catch (Exception $e) {
    logMessage("ERROR: " . $e->getMessage());
    logMessage("Stack trace: " . $e->getTraceAsString());
    exit(1);
}

exit(0);