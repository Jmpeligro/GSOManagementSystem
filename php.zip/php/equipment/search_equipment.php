<?php
/**
 * Equipment Search API Endpoint
 * 
 * This file handles AJAX requests for equipment search autocomplete.
 */

session_start();
require_once '../db_connection.php';
require_once '../classes/Equipment/Equipment.php';

// Ensure user is logged in
if (!isLoggedIn()) {
    header('Content-Type: application/json');
    echo json_encode(['error' => 'Unauthorized']);
    exit();
}

// Get search query
$query = isset($_GET['q']) ? sanitize($_GET['q']) : '';

// Return empty results if query is too short
if (strlen($query) < 2) {
    header('Content-Type: application/json');
    echo json_encode([]);
    exit();
}

// Set up filters
$filters = [
    'search' => $query,
    'limit' => 5  // Limit results to 5 items
];

// Get equipment matching the search query
try {
    $equipment = Equipment::getAll($conn, $filters);
    
    // Add display status for UI purposes
    foreach ($equipment as &$item) {
        // This will be used for CSS classes and displaying status
        if (!isset($item['display_status'])) {
            $item['display_status'] = $item['status'];
        }
    }
    
    header('Content-Type: application/json');
    echo json_encode($equipment);
} catch (Exception $e) {
    header('Content-Type: application/json');
    echo json_encode(['error' => 'An error occurred while searching']);
}
?>