<?php
session_start();
require_once '../db_connection.php';
require_once '../classes/Equipment/Equipment.php';

if (!isLoggedIn() || !isAdmin()) {
    header("Location: ../login.php");
    exit();
}

$errors = [];
$success_message = '';

$equipment_data = [
    'name' => '',
    'description' => '',
    'equipment_code' => '',
    'category_id' => 0,
    'condition_status' => 'good', 
    'status' => 'available', 
    'acquisition_date' => date('Y-m-d'),
    'quantity' => 1,
    'notes' => ''
];

$sql_categories = "SELECT * FROM categories ORDER BY name ASC";
$categories_result = $conn->query($sql_categories);

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $equipment_data = [
        'name' => sanitize($_POST['name']),
        'description' => sanitize($_POST['description']),
        'equipment_code' => sanitize($_POST['equipment_code']),
        'category_id' => (int)$_POST['category_id'],
        'condition_status' => sanitize($_POST['condition_status']),
        'status' => sanitize($_POST['status']),
        'acquisition_date' => sanitize($_POST['acquisition_date']),
        'quantity' => (int)$_POST['quantity'],
        'notes' => sanitize($_POST['notes'] ?? '')
    ];

    if (!empty($equipment_data['acquisition_date'])) {
        $date_parts = explode('-', $equipment_data['acquisition_date']);
        if (count($date_parts) !== 3 || !checkdate((int)$date_parts[1], (int)$date_parts[2], (int)$date_parts[0])) {
            $errors[] = "Invalid date format. Please use YYYY-MM-DD format.";
        }
    }
    
    if (empty($errors)) {
        $equipment = new Equipment($conn);
        $result = $equipment->create($equipment_data);
        
        if ($result['success']) {
            $success_message = $result['message'];
            $equipment_data = [
                'name' => '',
                'description' => '',
                'equipment_code' => '',
                'category_id' => 0,
                'condition_status' => 'good',
                'status' => 'available',
                'acquisition_date' => date('Y-m-d'),
                'quantity' => 1,
                'notes' => ''
            ];
        } else {
            $errors[] = $result['message'];
        }
    }
}

extract($equipment_data);

include '../../pages/equipment/equipment_management.html';
?>