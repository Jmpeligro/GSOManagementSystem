<?php
session_start();

require_once '../db_connection.php';
require_once '../classes/Category/CategoryActions.php';

if (!isLoggedIn() || !isAdmin()) {
    header("Location: ../login.php");
    exit();
}

if (!isset($_GET['id']) || empty($_GET['id'])) {
    $_SESSION['error'] = "Category ID is required.";
    header("Location: categories.php");
    exit();
}

$category_id = (int)$_GET['id'];
$category = new CategoryActions($conn);

// Load the category by ID and check if it exists.
if (!$category->load($category_id)) {
    $_SESSION['error'] = "Category not found.";
    header("Location: categories.php");
    exit();
}

// Handle category update request via POST method.
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $name = sanitize($_POST['name']); 
    $description = sanitize($_POST['description']);
    
    $result = $category->update($name, $description);
    
    if ($result['success']) {
        $_SESSION['success'] = $result['message'];
        header("Location: categories.php");
        exit();
    } else {
        $_SESSION['error'] = $result['message'];
    }
}

// Fetch the equipment associated with the category.
$equipment = $category->getEquipment();

/**
 * Class to simulate a result set for equipment data.
 */
class EquipmentResultSet {
    public $num_rows; // Number of rows in the result set.
    private $equipment; // Array of equipment data.
    private $position = 0; // Current position in the result set.
    
    public function __construct($equipment) {
        $this->equipment = $equipment;
        $this->num_rows = count($equipment);
    }
    
    // Fetch the next row in the result set as an associative array.
    public function fetch_assoc() {
        if ($this->position >= count($this->equipment)) {
            return null;
        }
        
        $row = $this->equipment[$this->position];
        $this->position++;
        return $row;
    }
    
    // Reset the position to the beginning of the result set.
    public function reset() {
        $this->position = 0;
    }
}

// Create an instance of EquipmentResultSet for the equipment data.
$equipment_result = new EquipmentResultSet($equipment);

// Prepare category data for display.
$category = [
    'category_id' => $category->getId(),
    'name' => $category->getName(),
    'description' => $category->getDescription()
];

include '../../pages/categories/edit_categories.html';
?>