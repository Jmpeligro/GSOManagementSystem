<?php
session_start();

require_once '../db_connection.php';
require_once '../classes/Category/CategoryActions.php';

if (!isLoggedIn()) {
    header("Location: ../login.php");
    exit();
}

// Retrieve the search query from the GET request, if available.
$search_query = isset($_GET['search']) ? sanitize($_GET['search']) : '';

// Handle category deletion request if the user is an admin.
if (isset($_GET['delete']) && isAdmin()) {
    $delete_id = (int)$_GET['delete'];

    $category = new CategoryActions($conn);
    if ($category->load($delete_id)) {
        $result = $category->delete();

        if ($result['success']) {
            $_SESSION['success'] = $result['message'];
        } else {
            $_SESSION['error'] = $result['message'];
        }
    } else {
        $_SESSION['error'] = "Category not found.";
    }

    header("Location: categories.php");
    exit();
}

// Handle category addition request via POST method.
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['add_category'])) {
    $name = sanitize($_POST['name']); 
    $description = sanitize($_POST['description']);

    $category = new CategoryActions($conn);
    $result = $category->create($name, $description);

    // Set success or error message based on the result.
    if ($result['success']) {
        $_SESSION['success'] = $result['message'];
        header("Location: categories.php");
        exit();
    } else {
        $_SESSION['error'] = $result['message'];
    }
}

// Fetch all categories based on the search query.
$categories = CategoryActions::getAll($conn, $search_query);

include '../../pages/categories/categories.html';
?>