<?php
require_once 'BorrowingBase.php';
require_once 'BorrowingActions.php';
require_once 'BorrowingData.php';


class Borrowing extends BorrowingActions {

    //retrieves all borrowing records from the database with optional filters
    public static function getAllBorrowings($conn, $filters = []) {
        return BorrowingData::getAll($conn, $filters);
    }

    //retrieves all pending borrowing requests
    public static function getPendingRequests($conn) {
        return BorrowingData::getPendingRequests($conn);
    }

    //retrieves all borrowings for a specific user
    public static function getUserBorrowings($conn, $user_id) {
        return BorrowingData::getUserBorrowings($conn, $user_id);
    }
    
    //retrieves all overdue borrowings from the database
    public static function getOverdueBorrowings($conn) {
        return BorrowingData::getOverdueBorrowings($conn);
    }

    //retrieves the borrowing history for a specific equipment
    public static function getEquipmentBorrowingHistory($conn, $equipment_id, $limit = 10) {
        return BorrowingData::getEquipmentBorrowingHistory($conn, $equipment_id, $limit);
    }
}
?>