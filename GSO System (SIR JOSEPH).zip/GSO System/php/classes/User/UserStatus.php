<?php
// This file defines the `UserStatus` class, which manages the status of users in the system.
// It provides methods to activate, deactivate, archive, restore, and delete users, as well as check their current status.

class UserStatus {
    protected $conn;
    protected $user_id;
    protected $status;
    protected $status_changed_at;

    public function __construct($conn, $user_id, $status, $status_changed_at) {
        $this->conn = $conn;
        $this->user_id = $user_id;
        $this->status = $status;
        $this->status_changed_at = $status_changed_at;
    }


    public function setStatus($status) {
        if (!in_array($status, ['active', 'inactive', 'archived'])) {
            return ['success' => false, 'message' => 'Invalid status value'];
        }
        
        $sql = "UPDATE users SET status = ?, status_changed_at = NOW() WHERE user_id = ?";
        $stmt = $this->conn->prepare($sql);
        $stmt->bind_param("si", $status, $this->user_id);
        
        if ($stmt->execute()) {
            $this->status = $status;
            $this->status_changed_at = date('Y-m-d H:i:s');
            
            $status_message = ucfirst($status);
            return ['success' => true, 'message' => "User marked as {$status_message} successfully."];
        } else {
            return ['success' => false, 'message' => 'Error updating user status: ' . $stmt->error];
        }
    }

    public function activate() {
        return $this->setStatus('active');
    }

    public function deactivate() {
        return $this->setStatus('inactive');
    }
    
    public function archive() {
        return $this->setStatus('archived');
    }
    
    public function restore() {
        $sql = "UPDATE users SET archived = 0, archived_at = NULL WHERE user_id = ?";
        $stmt = $this->conn->prepare($sql);
        $stmt->bind_param("i", $this->user_id);
        
        if ($stmt->execute()) {
            $this->status = 'active';
            return ['success' => true, 'message' => 'User restored successfully.'];
        } else {
            return ['success' => false, 'message' => 'Error restoring user: ' . $stmt->error];
        }
    }

    public function delete() {
        $sql = "DELETE FROM users WHERE user_id = ?";
        $stmt = $this->conn->prepare($sql);
        $stmt->bind_param("i", $this->user_id);
        
        if ($stmt->execute()) {
            return ['success' => true, 'message' => 'User deleted successfully.'];
        } else {
            return ['success' => false, 'message' => 'Error deleting user: ' . $stmt->error];
        }
    }

    public function isActive() {
        return $this->status === 'active';
    }
    

    public function isInactive() {
        return $this->status === 'inactive';
    }

    public function isArchived() {
        return $this->status === 'archived';
    }
}
?>