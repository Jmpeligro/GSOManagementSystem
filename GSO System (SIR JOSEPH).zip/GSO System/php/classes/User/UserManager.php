<?php

class UserManager {
    // Retrieves all users from the database, applying optional filters for role, status, and search terms
    public static function getAll($conn, $filters = []) {
        $where_clauses = [];
        $params = [];
        $types = "";

        if (!empty($filters['role'])) {
            $where_clauses[] = "role = ?";
            $params[] = $filters['role'];
            $types .= "s";
        }

        if (!empty($filters['status'])) {
            if (is_array($filters['status'])) {
                $placeholders = array_fill(0, count($filters['status']), '?');
                $where_clauses[] = "status IN (" . implode(',', $placeholders) . ")";
                foreach ($filters['status'] as $status) {
                    $params[] = $status;
                    $types .= "s";
                }
            } else {
                $where_clauses[] = "status = ?";
                $params[] = $filters['status'];
                $types .= "s";
            }
        }
        
        if (!empty($filters['search'])) {
            $search_term = "%" . $filters['search'] . "%";
            $where_clauses[] = "(first_name LIKE ? OR last_name LIKE ? OR email LIKE ? OR university_id LIKE ?)";
            $params[] = $search_term;
            $params[] = $search_term;
            $params[] = $search_term;
            $params[] = $search_term;
            $types .= "ssss";
        }
        
        $sql = "SELECT * FROM users";
        
        if (!empty($where_clauses)) {
            $sql .= " WHERE " . implode(" AND ", $where_clauses);
        }
        
        $sql .= " ORDER BY last_name, first_name";
        
        $stmt = $conn->prepare($sql);
        
        if (!empty($params)) {
            $stmt->bind_param($types, ...$params);
        }
        
        $stmt->execute();
        $result = $stmt->get_result();
        
        $users = [];
        while ($row = $result->fetch_assoc()) {
            $users[] = $row;
        }
        
        return $users;
    }

    // Updates the status of borrowings to 'overdue' if their due date has passed
    public static function updateOverdueStatus($conn) {
        $sql = "UPDATE borrowings 
                SET status = 'overdue', updated_at = NOW() 
                WHERE status = 'active' 
                AND approval_status = 'approved'
                AND due_date < NOW()";
                
        if ($conn->query($sql)) {
            return [
                'success' => true, 
                'message' => 'Overdue status updated successfully.',
                'count' => $conn->affected_rows
            ];
        } else {
            return [
                'success' => false, 
                'message' => 'Error updating overdue status: ' . $conn->error
            ];
        }
    }
}
?>