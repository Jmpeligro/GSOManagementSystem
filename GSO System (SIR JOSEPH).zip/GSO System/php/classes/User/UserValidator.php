<?php
// This file defines the `UserValidator` class, which provides validation logic for user data.
// It ensures that required fields are present, email formats are valid, and passwords meet security requirements.

class UserValidator {
    public static function validateData($data, $check_password = true) {
        $errors = [];
        
        if (empty($data['university_id'])) {
            $errors[] = "University ID is required";
        }
        
        if (empty($data['first_name'])) {
            $errors[] = "First name is required";
        }
        
        if (empty($data['last_name'])) {
            $errors[] = "Last name is required";
        }
        
        if (empty($data['email'])) {
            $errors[] = "Email is required";
        } elseif (!filter_var($data['email'], FILTER_VALIDATE_EMAIL)) {
            $errors[] = "Invalid email format";
        } elseif (!preg_match('/@plpasig\.edu\.ph$/i', $data['email'])) {
            $errors[] = "Email must be from the plpasig.edu.ph domain";
        }
        
        if (empty($data['role'])) {
            $errors[] = "Role is required";
        } elseif (!in_array($data['role'], ['student', 'faculty', 'staff', 'admin'])) {
            $errors[] = "Invalid role selected";
        }
        
        if (empty($data['department'])) {
            $errors[] = "Department/Course is required";
        }
        
        if ($data['role'] === 'student' && empty($data['program_year_section'])) {
            $errors[] = "Program/Year/Section is required for students";
        }
        
        if ($check_password) {
            if (empty($data['password'])) {
                $errors[] = "Password is required";
            } elseif (strlen($data['password']) < 8) {
                $errors[] = "Password must be at least 8 characters long";
            }
            
            if (empty($data['confirm_password'])) {
                $errors[] = "Confirm password is required";
            } elseif ($data['password'] !== $data['confirm_password']) {
                $errors[] = "Passwords do not match";
            }
        }
        
        return $errors;
    }
}
?>