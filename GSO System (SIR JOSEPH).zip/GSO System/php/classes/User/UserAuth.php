<?php
// This file defines the `UserAuth` class, which handles user authentication and role-based access control.
// It provides methods to verify passwords, check user roles, and validate email uniqueness.

class UserAuth {
    protected $conn;
    protected $password;
    protected $role;
    public function __construct($conn, $password, $role) {
        $this->conn = $conn;
        $this->password = $password;
        $this->role = $role;
    }

    public function verifyPassword($password) {
        return password_verify($password, $this->password);
    } 
    public function isAdmin() {
        return $this->role === 'admin';
    }
    public function isFaculty() {
        return $this->role === 'faculty';
    }

    public function isStudent() {
        return $this->role === 'student';
    }


    public function isStaff() {
        return $this->role === 'staff';
    }

    public function emailExists($email, $current_user_id = null) {
        $sql = "SELECT user_id FROM users WHERE email = ?";
        $params = [$email];
        $types = "s";
        
        if ($current_user_id) {
            $sql .= " AND user_id != ?";
            $params[] = $current_user_id;
            $types .= "i";
        }
        
        $stmt = $this->conn->prepare($sql);
        $stmt->bind_param($types, ...$params);
        $stmt->execute();
        $result = $stmt->get_result();
        
        return $result->num_rows > 0;
    }
}
?>