<?php
// This file serves as the entry point of the application.
// It checks the user's session to determine their role and redirects them to the appropriate dashboard or login page.

session_start();

if (isset($_SESSION['user_id'])) {
    $user_name = $_SESSION['first_name'] . ' ' . $_SESSION['last_name'];
    echo "<p>Welcome, $user_name!</p>";    if (isset($_SESSION['role']) && $_SESSION['role'] === 'admin') {
        header("Location: dashboard.php");
    } else {
        header("Location: equipment/equipment.php");
    }
    exit();
} else {
    header("Location: login.php");
    exit();
}
?>