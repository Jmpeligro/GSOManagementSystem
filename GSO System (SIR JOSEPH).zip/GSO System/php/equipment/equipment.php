<?php
session_start();
require_once '../db_connection.php';
require_once '../helpers.php';
require_once 'equipment_status.php';
require_once '../classes/Equipment/Equipment.php';


if (!isLoggedIn()) {
    header("Location: ../login.php");
    exit();
}

$response = [
    'success' => false,
    'message' => '',
    'redirect' => ''
];

// Handle form submissions for equipment actions (delete, update status, update quantity, borrow).
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!isAdmin()) {
        $_SESSION['error'] = "You do not have permission to perform this action.";
        header("Location: equipment.php");
        exit();
    }
    
    $equipment = new Equipment($conn);
    $equipment_id = isset($_POST['equipment_id']) ? (int)$_POST['equipment_id'] : 0;

    // Load the equipment details for the given equipment ID.
    if ($equipment_id > 0) {
        if (!$equipment->load($equipment_id)) {
            $_SESSION['error'] = "Equipment not found.";
            header("Location: equipment.php");
            exit();
        }
    }

    $action = $_POST['action'] ?? '';
    
    switch ($action) {
        // Handle equipment deletion.
        case 'delete':
            // Prevent deletion of equipment that is currently under maintenance.
            if ($equipment->getStatus() === 'maintenance') {
                $_SESSION['error'] = "Equipment under maintenance cannot be deleted.";
                header("Location: equipment.php");
                exit();
            }

            $result = $equipment->delete();
            $response = $result;
            $response['redirect'] = 'equipment.php';
            break;
            
        // Handle status updates for equipment.
        case 'update_status':
            $new_status = sanitize($_POST['new_status']);
            $result = $equipment->updateStatus($new_status);
            $response = $result;
            $response['redirect'] = $_SERVER['HTTP_REFERER'];
            break;
            
        // Handle quantity updates for equipment.
        case 'update_quantity':
            $new_quantity = (int)$_POST['new_quantity'];
            $result = $equipment->updateQuantity($new_quantity);
            $response = $result;
            $response['redirect'] = $_SERVER['HTTP_REFERER'];
            break;
            
        // Handle equipment borrowing.
        case 'borrow':
            // Prevent borrowing of equipment that is currently under maintenance.
            if ($equipment->getStatus() === 'maintenance') {
                $_SESSION['error'] = "Equipment under maintenance cannot be borrowed.";
                header("Location: equipment.php");
                exit();
            }

            $user_id = $_SESSION['user_id']; 
            $borrow_sql = "INSERT INTO borrowings (equipment_id, user_id, status, created_at, updated_at) VALUES (?, ?, 'active', NOW(), NOW())";
            $borrow_stmt = $conn->prepare($borrow_sql);
            $borrow_stmt->bind_param("ii", $equipment_id, $user_id);

            // Execute the borrowing transaction.
            if ($borrow_stmt->execute()) {
                $borrowed_count = $equipment->getBorrowedCount();
                $available_quantity = $equipment->getQuantity() - $borrowed_count;

                // Check if the available quantity is zero to determine the new status of the equipment.
                if ($available_quantity == 0) {
                    $new_status = 'borrowed'; // All equipment is borrowed.
                } else {
                    $new_status = 'partially_borrowed'; // Some equipment is still available.
                }

                // Update the equipment's status and quantity in the database.
                $equipment->updateStatus($new_status);
                $equipment->updateQuantity($available_quantity);

                // Set the response for a successful borrowing operation.
                $response['success'] = true;
                $response['message'] = "Equipment borrowed successfully.";
            } else {
                // Handle errors during the borrowing process.
                $response['success'] = false;
                $response['message'] = "Error borrowing equipment: " . $borrow_stmt->error;
            }

            // Redirect the user back to the equipment page after the operation.
            $response['redirect'] = 'equipment.php';
            break;
    } 
    // Set session messages based on the success or failure of the operation.
    if ($response['success']) {
        $_SESSION['success'] = $response['message'];
    } else {
        $_SESSION['error'] = $response['message'];
    }

    // Redirect the user to the specified page if a redirect URL is provided.
    if (!empty($response['redirect'])) {
        header("Location: {$response['redirect']}");
        exit();
    }
}

// Define filters for equipment search and filtering.
$filters = [
    'status' => '', // Default status filter.
    'category' => isset($_GET['category']) ? (int)$_GET['category'] : 0, 
    'search' => isset($_GET['search']) ? sanitize($_GET['search']) : '' 
];

// Check if a status filter is provided in the GET request.
if (isset($_GET['status']) && !empty($_GET['status'])) {
    $status_input = sanitize($_GET['status']);
    
    // Map the status input to the appropriate filter.
    if (strtolower($status_input) === 'borrowed') {
        $filters['borrowed_filter'] = true; // Filter for borrowed equipment.
    } else if (strtolower($status_input) === 'available') {
        $filters['status'] = 'available'; // Filter for available equipment.
    } else if (strtolower($status_input) === 'retired') {
        $filters['status'] = 'retired'; // Filter for retired equipment.
    } else {
        $filters['status'] = $status_input; // Use the provided status as is.
    }
} elseif (isset($_GET['filter']) && $_GET['filter'] === 'critical') {
    $filters['status'] = 'critical'; // Filter for critical equipment.
} elseif (isset($_GET['filter']) && $_GET['filter'] === 'maintenance') {
    // Filter for equipment under maintenance or partially under maintenance.
    $filters['status'] = ['partially_maintenance', 'partially_both', 'maintenance', 'maintenance_critical', 'partially_maintenance_critical', 'partially_both_critical'];
}

// Extract filter values for search, status, and category.
$search_query = $filters['search'];
$status_filter = $filters['status'];
$category_filter = $filters['category'];

// Fetch all equipment based on the applied filters.
$result = Equipment::getAll($conn, $filters);

// Fetch all categories for the dropdown menu.
$sql_categories = "SELECT * FROM categories ORDER BY name ASC";
$categories_result = $conn->query($sql_categories);

include '../../pages/equipment/equipment.html';
?>