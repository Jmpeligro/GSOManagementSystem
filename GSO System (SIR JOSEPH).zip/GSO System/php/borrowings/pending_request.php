<?php
session_start();

require_once '../db_connection.php';
require_once '../helpers.php'; 
require_once '../classes/borrowing/Borrowing.php';
require_once 'notifications.php';
require_once '../classes/User/UserBase.php';
require_once 'EquipmentThreshold.php';

if (!isLoggedIn() || !isAdmin()) {
    header("Location: php/login.php");
    exit();
}

// This handles approval of borrowing requests.
if (isset($_POST['approve_request'])) {
    $borrowing_id = (int)$_POST['borrowing_id'];
    $borrowing = new Borrowing($conn);

    if ($borrowing->load($borrowing_id)) {
        $borrowerInfo = new UserBase($conn);
        $borrowerInfo->load($borrowing->getUserId());
        $recipientEmail = $borrowerInfo->getEmail();
        $name = $borrowerInfo->getFullName();

        // Fetch the equipment details associated with the borrowing.
        $sql = "SELECT e.name FROM equipment e 
                INNER JOIN borrowings b ON e.equipment_id = b.equipment_id 
                WHERE b.borrowing_id = ?";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("i", $borrowing_id);
        $stmt->execute();
        $equipment_result = $stmt->get_result();
        $row = $equipment_result->fetch_assoc();
        $equipment_list = $row ? htmlspecialchars($row['name']) : 'Unknown Equipment';

        // Approve the borrowing request.
        $result = $borrowing->approve($_SESSION['user_id'], 'Approved by administrator');
        if ($result['success']) {
            $_SESSION['success'] = "Borrowing request approved successfully.";

            // Prepare email content for approval notification.
            $emailBody = "
            <div style='font-family: Arial, sans-serif; max-width: 600px; margin: auto;'>
                <div style='background: #27ae60; color: #fff; padding: 16px 24px; border-radius: 8px 8px 0 0; text-align: center;'>
                    <strong>THIS IS AN AUTOMATICALLY GENERATED EMAIL | DO NOT REPLY</strong>
                </div>
                <div style='background: #fff; border: 1px solid #eee; border-top: none; padding: 24px; border-radius: 0 0 8px 8px;'>
                    <h2 style='color: #27ae60; margin-top: 0;'>Borrowing Request Approved</h2>
                    <p>Good news! Your request to borrow the following equipment has been approved:</p>
                    <div style='background: #f8f9fa; padding: 16px; border-radius: 4px; margin: 16px 0;'>
                        <strong style='color: #2c3e50;'>" . htmlspecialchars($equipment_list) . "</strong>
                    </div>
                    <table style='width: 100%; margin: 20px 0; border-collapse: collapse;'>
                        <tr>
                            <td style='padding: 8px; border-bottom: 1px solid #eee; color: #666;'>Borrow Date:</td>
                            <td style='padding: 8px; border-bottom: 1px solid #eee;'><strong>" . date('F d, Y h:i A', strtotime($borrowing->getBorrowDate())) . "</strong></td>
                        </tr>
                        <tr>
                            <td style='padding: 8px; border-bottom: 1px solid #eee; color: #666;'>Due Date:</td>
                            <td style='padding: 8px; border-bottom: 1px solid #eee;'><strong>" . date('F d, Y h:i A', strtotime($borrowing->getDueDate())) . "</strong></td>
                        </tr>
                    </table>
                    <p style='background: #e8f5e9; padding: 12px; border-radius: 4px; color: #2e7d32;'><strong>Next Steps:</strong> Please visit the General Service Office at your soonest convenience to collect/claim your requested equipment.</p>
                </div>
            </div>";

            $emailBodyAlt = "THIS IS AN AUTOMATICALLY GENERATED EMAIL | DO NOT REPLY\n\n" .
                "Your request to borrow the following equipment has been approved:\n" .
                $equipment_list . "\n\n" .
                "Borrow Date: " . date('F d, Y h:i A', strtotime($borrowing->getBorrowDate())) . "\n" .
                "Due Date: " . date('F d, Y h:i A', strtotime($borrowing->getDueDate())) . "\n\n" .
                "Next Steps: Please visit the General Service Office at your soonest convenience to collect/claim your requested equipment.";
            
            // Send email notification and log the action.
            pushNotif("Email Sent", "An Email has been sent to notify " . $name . " of their request status at " . $recipientEmail);
            sendEmail($recipientEmail, $name, "Borrow Request: Approved", $emailBody, $emailBodyAlt);
        } else {
            $_SESSION['error'] = "Error approving request: " . $result['message'];
        }
    } else {
        $_SESSION['error'] = "Borrowing record not found.";
    }

    header("Location: pending_request.php");
    exit();
}

// Handle denial of borrowing requests.
if (isset($_POST['deny_request'])) {
    $borrowing_id = (int)$_POST['borrowing_id'];
    $denial_reason = sanitize($_POST['denial_reason']);
    $borrowing = new Borrowing($conn);

    // Load the borrowing record by ID.
    if ($borrowing->load($borrowing_id)) {
        $borrowerInfo = new UserBase($conn);
        $borrowerInfo->load($borrowing->getUserId());
        $recipientEmail = $borrowerInfo->getEmail();
        $name = $borrowerInfo->getFullName();

        // Deny the borrowing request.
        $result = $borrowing->deny($_SESSION['user_id'], $denial_reason);
        if ($result['success']) {
            $_SESSION['success'] = "Borrowing request denied.";

            // Prepare email content for denial notification.
            $emailBody = "
            <div style='font-family: Arial, sans-serif; max-width: 600px; margin: auto;'>
                <div style='background: #e74c3c; color: #fff; padding: 16px 24px; border-radius: 8px 8px 0 0; text-align: center;'>
                    <strong>THIS IS AN AUTOMATICALLY GENERATED EMAIL | DO NOT REPLY</strong>
                </div>
                <div style='background: #fff; border: 1px solid #eee; border-top: none; padding: 24px; border-radius: 0 0 8px 8px;'>
                    <h2 style='color: #e74c3c; margin-top: 0;'>Borrowing Request Denied</h2>
                    <p>Your request to borrow the following equipment has been denied:</p>
                    <div style='background: #f8f9fa; padding: 16px; border-radius: 4px; margin: 16px 0;'>
                        <strong style='color: #2c3e50;'>" . htmlspecialchars($equipment_list) . "</strong>
                    </div>
                    <div style='background: #fde8e7; padding: 16px; border-radius: 4px; margin: 16px 0;'>
                        <strong style='color: #c0392b;'>Reason for Denial:</strong><br>
                        " . htmlspecialchars($denial_reason) . "
                    </div>
                    <p>If you have any questions, please contact the General Service Office for clarification.</p>
                </div>
            </div>
            ";
            $emailBodyAlt = "THIS IS AN AUTOMATICALLY GENERATED EMAIL | DO NOT REPLY\n\n" .
                "The equipment you requested to borrow has been denied.\n" .
                "Reason: " . $denial_reason;
            
            // Send email notification and log the action.
            pushNotif("Email Sent", "An Email has been sent to notify " . $name . " of their request status at " . $recipientEmail);
            sendEmail($recipientEmail, $name, "Borrow Request: Denied", $emailBody, $emailBodyAlt);
        } else {
            $_SESSION['error'] = "Error denying request: " . $result['message'];
        }
    } else {
        $_SESSION['error'] = "Borrowing record not found.";
    }

    // Redirect back to the pending requests page.
    header("Location: pending_request.php");
    exit();
}

// Fetch all pending borrowing requests.
$pending_requests = Borrowing::getPendingRequests($conn);

include '../../pages/borrowings/pending_request.html';
?>