<?php
session_start();
require_once '../db_connection.php';
require_once '../classes/User/User.php';

if (!isLoggedIn() || !isAdmin()) {
    header("Location: php/login.php");
    exit();
}

// Determine the user ID from the GET request, defaulting to 0 if not provided
$user_id = isset($_GET['id']) ? (int)$_GET['id'] : 0;
// Set the mode to 'edit' if a valid user ID is provided, otherwise default to 'add'
$mode = $user_id > 0 ? 'edit' : 'add';
// Set the page title based on the mode
$title = $mode === 'edit' ? 'Edit User' : 'Add New User';
// Create a new User object for interacting with user data
$user = new User($conn);
// Initialize variables for storing user details and error messages
$university_id = '';
$first_name = '';
$last_name = '';
$email = '';
$department = '';
$phone = '';
$role = '';
$program_year_section = '';
$errors = [];

// Handle the edit mode by loading user details if a valid user ID is provided
if ($mode === 'edit') {
    if (!$user->load($user_id)) {
        $_SESSION['error'] = "User not found.";
        header("Location: users.php");
        exit();
    }
    
    // Populate variables with user details for editing
    $university_id = $user->getUniversityId();
    $first_name = $user->getFirstName();
    $last_name = $user->getLastName();
    $email = $user->getEmail();
    $department = $user->getDepartment();
    $phone = $user->getPhone();
    $role = $user->getRole();
    $program_year_section = $user->getProgramYearSection();
}

// Handle form submission for adding or editing a user
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $data = [
        'university_id' => sanitize($_POST['university_id']),
        'first_name' => sanitize($_POST['first_name']),
        'last_name' => sanitize($_POST['last_name']),
        'email' => sanitize($_POST['email']),
        'department' => sanitize($_POST['department']),
        'phone' => sanitize($_POST['phone'] ?? ''),
        'role' => sanitize($_POST['role'])
    ];
    
    // Add program year and section if the role is 'student'
    if ($data['role'] === 'student') {
        $data['program_year_section'] = sanitize($_POST['program_year_section'] ?? '');
    } else {
        $data['program_year_section'] = '';
    }
    
    // Include password fields if adding a new user or updating the password
    if ($mode === 'add' || !empty($_POST['password'])) {
        $data['password'] = $_POST['password'];
        $data['confirm_password'] = $_POST['confirm_password'];
    }
    
    // Perform the appropriate action based on the mode (add or edit)
    if ($mode === 'edit') {
        $result = $user->update($data);
    } else {
        $result = $user->create($data);
    }
    
    // Handle the result of the operation
    if ($result['success']) {
        $_SESSION['success'] = $result['message'];
        header("Location: users.php");
        exit();
    } else {
        $_SESSION['error'] = $result['message'];
        $university_id = $data['university_id'];
        $first_name = $data['first_name'];
        $last_name = $data['last_name'];
        $email = $data['email'];
        $department = $data['department'];
        $phone = $data['phone'];
        $role = $data['role'];
        $program_year_section = $data['program_year_section'];
    }
}

include '../../pages/users/user_management.html';
?>