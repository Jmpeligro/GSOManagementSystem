<?php
session_start();

require_once '../db_connection.php';
require_once '../borrowings/EquipmentInventoryHook.php';

if (!isLoggedIn() || !isAdmin()) {
    header("Location: ../login.php");
    exit();
}

// Handle quick add functionality for maintenance.
if (isset($_GET['quick_add']) && is_numeric($_GET['quick_add'])) {
    $equipment_id = (int)$_GET['quick_add'];

    // Check if the equipment exists and fetch its details.
    $check_sql = "SELECT name, status FROM equipment WHERE equipment_id = ?";
    $check_stmt = $conn->prepare($check_sql);
    $check_stmt->bind_param("i", $equipment_id);
    $check_stmt->execute();
    $check_result = $check_stmt->get_result();
    
    if ($check_result->num_rows > 0) {
        $equipment = $check_result->fetch_assoc();
        
        // Validate the equipment's current status before adding to maintenance.
        if ($equipment['status'] === 'maintenance') {
            $_SESSION['error'] = "This equipment is already under maintenance!";
        } elseif ($equipment['status'] === 'borrowed') {
            $_SESSION['error'] = "Cannot send borrowed equipment to maintenance!";
        } elseif ($equipment['status'] === 'retired') {
            $_SESSION['error'] = "Cannot send retired equipment to maintenance!";
        } else {
            $quick_add = true;
            $quick_add_equipment_id = $equipment_id;
            $quick_add_equipment_name = $equipment['name'];
        }
    } else {
        $_SESSION['error'] = "Equipment not found!";
    }
}

// Query to fetch all maintenance records and their associated equipment details.
$sql = "SELECT 
    m.maintenance_id,
    m.equipment_id,
    e.name as equipment_name,
    e.equipment_code,
    m.issue_description,
    m.maintenance_date,
    m.resolved_date,
    m.cost,
    m.resolved_by,
    m.status,
    m.notes,
    m.units,
    m.created_at,
    m.updated_at
    FROM maintenance m
    JOIN equipment e ON m.equipment_id = e.equipment_id
    ORDER BY 
        CASE 
            WHEN m.status = 'pending' THEN 1
            WHEN m.status = 'in_progress' THEN 2
            WHEN m.status = 'completed' THEN 3
        END, 
        m.maintenance_date DESC";

$result = $conn->query($sql);

// Handle POST requests for maintenance operations.
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Update an existing maintenance record.
    if (isset($_POST['update_maintenance'])) {
        $maintenance_id = (int)$_POST['maintenance_id'];
        $equipment_id = (int)$_POST['equipment_id'];
        $status = sanitize($_POST['status']);
        $notes = sanitize($_POST['notes']);
        $resolved_date = null;
        $resolved_by = null;
        $cost = null;
        
        // If the status is completed, set additional fields.
        if ($status === 'completed') {
            $resolved_date = date('Y-m-d');
            $resolved_by = $_SESSION['first_name'] . ' ' . $_SESSION['last_name'];
            $cost = !empty($_POST['cost']) ? (float)$_POST['cost'] : 0;
        }
        
        // Update the maintenance record in the database.
        $update_sql = "UPDATE maintenance 
                    SET status = ?, 
                        notes = ?,
                        resolved_date = ?,
                        resolved_by = ?,
                        cost = ?,
                        updated_at = NOW()
                    WHERE maintenance_id = ?"; 
        $update_stmt = $conn->prepare($update_sql);
        $update_stmt->bind_param("ssssdi", $status, $notes, $resolved_date, $resolved_by, $cost, $maintenance_id);
        
        if ($update_stmt->execute()) {            
            if ($status === 'completed') {
                // Fetch the number of units under maintenance.
                $details_sql = "SELECT units FROM maintenance WHERE maintenance_id = ?";
                $details_stmt = $conn->prepare($details_sql);
                $details_stmt->bind_param("i", $maintenance_id);
                $details_stmt->execute();
                $details = $details_stmt->get_result()->fetch_assoc();
                $maintenance_units = $details['units'];

                // Update the equipment's available quantity.
                $equipment_update = "UPDATE equipment 
                                    SET available_quantity = available_quantity + ?, 
                                        updated_at = NOW() 
                                    WHERE equipment_id = ?";                
                $equipment_stmt = $conn->prepare($equipment_update);
                $equipment_stmt->bind_param("ii", $maintenance_units, $equipment_id);
                $equipment_stmt->execute();
            }
            require_once '../borrowings/EquipmentThreshold.php';
            checkSingleEquipmentStatus($conn, $equipment_id);
            
            $_SESSION['success'] = "Maintenance record updated successfully!";
        } else {
            $_SESSION['error'] = "Error updating maintenance record: " . $update_stmt->error;
        }
            
        header("Location: maintenance.php");
        exit();
    }
    
    if (isset($_POST['add_maintenance'])) {
        $equipment_id = (int)$_POST['equipment_id'];
        $issue_description = sanitize($_POST['issue_description']);
        $maintenance_date = date('Y-m-d');
        $notes = sanitize($_POST['notes']);
        $status = 'pending';

        $check_sql = "SELECT status, quantity, available_quantity FROM equipment WHERE equipment_id = ?";
        $check_stmt = $conn->prepare($check_sql);
        $check_stmt->bind_param("i", $equipment_id);
        $check_stmt->execute();
        $check_result = $check_stmt->get_result();
        
        if ($check_result->num_rows == 0) {
            $_SESSION['error'] = "Equipment not found!";
            header("Location: maintenance.php");
            exit();
        }
        
        $equipment_data = $check_result->fetch_assoc();
        $equipment_status = $equipment_data['status'];
        $total_quantity = $equipment_data['quantity'];
        $available_quantity = $equipment_data['available_quantity'];

        if (strpos($equipment_status, 'maintenance') !== false && $available_quantity == 0) {
            $_SESSION['error'] = "This equipment is already fully under maintenance!";
            header("Location: maintenance.php");
            exit();
        }
        
        if ($equipment_status === 'retired') {
            $_SESSION['error'] = "Cannot send retired equipment to maintenance!";
            header("Location: maintenance.php");
            exit();
        }

        $maintenance_count_sql = "SELECT COALESCE(SUM(units), 0) as total_in_maintenance 
                                FROM maintenance 
                                WHERE equipment_id = ? 
                                AND status != 'completed' 
                                AND status != 'cancelled'";
        $maintenance_count_stmt = $conn->prepare($maintenance_count_sql);
        $maintenance_count_stmt->bind_param("i", $equipment_id);
        $maintenance_count_stmt->execute();
        $maintenance_count = (int)$maintenance_count_stmt->get_result()->fetch_assoc()['total_in_maintenance'];

        $units_to_maintenance = isset($_POST['quantity']) ? (int)$_POST['quantity'] : 1;
        
        if ($units_to_maintenance > $available_quantity) {
            $_SESSION['error'] = "Cannot send more units to maintenance than available. Available: {$available_quantity}";
            header("Location: maintenance.php");
            exit();
        }

        if (($maintenance_count + $units_to_maintenance) > $total_quantity) {
            $_SESSION['error'] = "Cannot send more units to maintenance than total equipment quantity.";
            header("Location: maintenance.php");
            exit();
        }

        $insert_sql = "INSERT INTO maintenance 
                      (equipment_id, issue_description, maintenance_date, notes, status, units, created_at, updated_at) 
                      VALUES (?, ?, ?, ?, ?, ?, NOW(), NOW())";
        $insert_stmt = $conn->prepare($insert_sql);
        $insert_stmt->bind_param("issssi", $equipment_id, $issue_description, $maintenance_date, $notes, $status, $units_to_maintenance);         
           
        if ($insert_stmt->execute()) {
            $new_available = $available_quantity - $units_to_maintenance;
            $equipment_update = "UPDATE equipment 
                                SET available_quantity = ?, 
                                    updated_at = NOW() 
                                WHERE equipment_id = ?";
            $equipment_stmt = $conn->prepare($equipment_update);
            $equipment_stmt->bind_param("ii", $new_available, $equipment_id);

            if (!$equipment_stmt->execute()) {
                $_SESSION['error'] = "Error updating equipment available quantity: " . $equipment_stmt->error;
                header("Location: maintenance.php");
                exit();
            }

            require_once '../borrowings/EquipmentThreshold.php';
            checkSingleEquipmentStatus($conn, $equipment_id);
            
            $_SESSION['success'] = "Maintenance record created successfully!";
        } else {
            $_SESSION['error'] = "Error creating maintenance record: " . $insert_stmt->error;
        }
        
        header("Location: maintenance.php");
        exit();
    }
    
    if (isset($_POST['delete_maintenance'])) {
        $maintenance_id = (int)$_POST['maintenance_id'];
        $equipment_id = (int)$_POST['equipment_id'];
        
        $status_sql = "SELECT m.status, m.units
                      FROM maintenance m 
                      WHERE m.maintenance_id = ?";
        $status_stmt = $conn->prepare($status_sql);
        $status_stmt->bind_param("i", $maintenance_id);
        $status_stmt->execute();
        $status_result = $status_stmt->get_result();
        $maintenance_data = $status_result->fetch_assoc();
        
        if ($maintenance_data['status'] !== 'completed') {
            $units_to_restore = $maintenance_data['units'];
            
            // Only update available_quantity, let threshold logic handle status
            $update_sql = "UPDATE equipment 
                          SET available_quantity = available_quantity + ?, 
                              updated_at = NOW() 
                          WHERE equipment_id = ?";
            $update_stmt = $conn->prepare($update_sql);
            $update_stmt->bind_param("ii", $units_to_restore, $equipment_id);
            
            if (!$update_stmt->execute()) {
                $_SESSION['error'] = "Error updating equipment available quantity: " . $update_stmt->error;
                header("Location: maintenance.php");
                exit();
            }
        }
        
        $delete_sql = "DELETE FROM maintenance WHERE maintenance_id = ?";
        $delete_stmt = $conn->prepare($delete_sql);
        $delete_stmt->bind_param("i", $maintenance_id);
        
        if ($delete_stmt->execute()) {
            // Use single equipment status check instead of checking all equipment
            require_once '../borrowings/EquipmentThreshold.php';
            checkSingleEquipmentStatus($conn, $equipment_id);
            
            $_SESSION['success'] = "Maintenance record deleted successfully!";
        } else {
            $_SESSION['error'] = "Error deleting maintenance record: " . $delete_stmt->error;
        }
        
        header("Location: maintenance.php");
        exit();
    }
}

// Query to fetch equipment that is not under maintenance or retired.
$equipment_sql = "SELECT equipment_id, name, equipment_code, available_quantity FROM equipment WHERE status != 'maintenance' AND status != 'retired' ORDER BY name";
$equipment_result = $conn->query($equipment_sql);


include '../../pages/equipment/maintenance.html';
?>