<?php

session_start();
require_once '../db_connection.php';
require_once '../classes/Equipment/Equipment.php';

if (!isLoggedIn()) {
    header('Content-Type: application/json');
    echo json_encode(['error' => 'Unauthorized']);
    exit();
}

$query = isset($_GET['q']) ? sanitize($_GET['q']) : '';

if (strlen($query) < 2) {
    header('Content-Type: application/json');
    echo json_encode([]);
    exit();
}

$filters = [
    'search' => $query,
    'limit' => 5  
];

$isAdminUser = isAdmin();

try {
    $equipment = Equipment::getAll($conn, $filters);
    
    foreach ($equipment as &$item) {
        if (!isset($item['display_status'])) {
            $item['display_status'] = $item['status'];
        }
        
        $item['is_admin'] = $isAdminUser;
    }
    
    header('Content-Type: application/json');
    echo json_encode($equipment);
} catch (Exception $e) {
    header('Content-Type: application/json');
    echo json_encode(['error' => 'An error occurred while searching']);
}
?>