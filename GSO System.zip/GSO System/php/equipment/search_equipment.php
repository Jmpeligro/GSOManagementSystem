<?php

session_start();
require_once '../db_connection.php';
require_once '../classes/Equipment/Equipment.php';

if (!isLoggedIn()) {
    header('Content-Type: application/json');
    echo json_encode(['error' => 'Unauthorized']);
    exit();
}

$query = isset($_GET['q']) ? sanitize($_GET['q']) : '';

if (strlen($query) < 2) {
    header('Content-Type: application/json');
    echo json_encode([]);
    exit();
}

$filters = [
    'search' => $query,
    'limit' => 5  
];

// Handle different user roles
$isAdminUser = isAdmin();

try {
    $equipment = Equipment::getAll($conn, $filters);
    
    // Process equipment data
    foreach ($equipment as &$item) {
        if (!isset($item['display_status'])) {
            $item['display_status'] = $item['status'];
        }
        
        // Add user role flag to indicate if this is an admin or borrower
        $item['is_admin'] = $isAdminUser;
    }
    
    header('Content-Type: application/json');
    echo json_encode($equipment);
} catch (Exception $e) {
    header('Content-Type: application/json');
    echo json_encode(['error' => 'An error occurred while searching']);
}
?>