<?php
session_start();

require_once '../db_connection.php';
require_once '../classes/Equipment/Equipment.php';

if (!isLoggedIn()) {
    header("Location: ../login.php");
    exit();
}

if (!isset($_GET['id']) || empty($_GET['id'])) {
    $_SESSION['error'] = "No equipment specified.";
    header("Location: equipment.php");
    exit();
}

// Initialize the Equipment object and load the equipment details
$equipment_id = (int)$_GET['id'];
$equipment = new Equipment($conn);

// Check if the equipment exists, redirect if not found
if (!$equipment->load($equipment_id)) {
    $_SESSION['error'] = "Equipment not found.";
    header("Location: equipment.php");
    exit();
}

// Retrieve the category ID and name for the equipment
$category_id = $equipment->getCategoryId();
$category_name = '';

// If a category ID exists, fetch the category name from the database
if ($category_id) {
    // Query the database to get the category name
    $category_sql = "SELECT name FROM categories WHERE category_id = ?";
    $stmt = $conn->prepare($category_sql);
    
    if ($stmt) {
        $stmt->bind_param("i", $category_id);
        $stmt->execute();
        $category_result = $stmt->get_result();
        
        if ($category_result && $category_result->num_rows > 0) {
            $category_row = $category_result->fetch_assoc();
            $category_name = $category_row['name'];
        }
    }
}

// Check if the equipment is currently borrowed and get its status
$is_borrowed = $equipment->isBorrowed();
$status = $equipment->getStatus();
$status_display = $is_borrowed ? 'borrowed' : $status;

// Retrieve the borrowing history of the equipment, limited to 10 entries
$history_limit = 10;
$borrowing_history = $equipment->getBorrowingHistory($history_limit);

// Get the current borrower if the equipment is borrowed
$current_borrower = $is_borrowed ? $equipment->getCurrentBorrower() : null;

// Collect all equipment data into an array for rendering in the view
$equipment_data = [
    'equipment_id' => $equipment->getId(),
    'name' => $equipment->getName(),
    'description' => $equipment->getDescription(),
    'equipment_code' => $equipment->getEquipmentCode(),
    'category_id' => $equipment->getCategoryId(),
    'category_name' => $category_name,
    'condition_status' => $equipment->getConditionStatus(),
    'status' => $status,
    'status_display' => $status_display,
    'acquisition_date' => $equipment->getAcquisitionDate(),
    'notes' => $equipment->getNotes(),
    'quantity' => $equipment->getQuantity(),
    'available_quantity' => $equipment->getAvailableQuantity(),
    'created_at' => $equipment->getCreatedAt(),
    'updated_at' => $equipment->getUpdatedAt(),
    'is_borrowed' => $is_borrowed,
    'quantity_display' => $equipment->getQuantityDisplay(),
    'current_borrower' => $current_borrower
];


include '../../pages/equipment/view_equipment.html';
?>