<?php

function getEquipmentStatusDisplay($display_status, $available_quantity, $total_quantity) {
    $total_quantity = (int)$total_quantity;
    $available_quantity = (int)$available_quantity;
    
    $is_fully_borrowed = $available_quantity === 0;
    $is_partially_borrowed = $available_quantity > 0 && $available_quantity < $total_quantity;
    $is_at_critical_level = $available_quantity <= ($total_quantity / 2);
    
    $status_class = strtolower($display_status);
    $status_text = ucfirst($display_status);

    if ($display_status === 'maintenance') {
        if (isset($_SESSION['role']) && $_SESSION['role'] === 'admin') {
            $status_class = $is_at_critical_level ? 'critical' : 'maintenance';
            $status_text = $is_at_critical_level ? 'Under Maintenance/Critical' : 'Under Maintenance';
        } else {
            $status_class = 'maintenance';
            $status_text = 'Under Maintenance';
        }
        return [
            'class' => $status_class,
            'text' => $status_text
        ];
    }

    if ($display_status === 'partially_both') {
        if (isset($_SESSION['role']) && $_SESSION['role'] === 'admin') {
            $status_class = $is_at_critical_level ? 'critical' : 'partially-both';
            $status_text = $is_at_critical_level ? 'Partially Both/Critical' : 'Partially Both';
        } else {
            $status_class = 'partially-both';
            $status_text = 'Partially Both';
        }
        return [
            'class' => $status_class,
            'text' => $status_text
        ];
    }

    if ($display_status === 'partially_maintenance') {
        if (isset($_SESSION['role']) && $_SESSION['role'] === 'admin') {
            $status_class = $is_at_critical_level ? 'critical' : 'partially-maintenance';
            $status_text = $is_at_critical_level ? 'Partially Maintenance/Critical' : 'Partially Maintenance';
        } else {
            $status_class = 'partially-maintenance';
            $status_text = 'Partially Maintenance';
        }
        return [
            'class' => $status_class,
            'text' => $status_text
        ];
    }
    
    if ($display_status !== 'maintenance' && $display_status !== 'partially_maintenance' && $display_status !== 'partially_both') {
        if (isset($_SESSION['role']) && $_SESSION['role'] === 'admin') {
            if ($is_fully_borrowed) {
                $status_class = 'critical';
                $status_text = 'Borrowed/Critical';
            } elseif ($is_partially_borrowed && $is_at_critical_level) {
                $status_class = 'critical';  
                $status_text = 'Partially Borrowed/Critical';
            } elseif ($is_partially_borrowed) {
                $status_class = 'partially-borrowed';
                $status_text = 'Partially Borrowed';
            } elseif ($display_status === 'available' && $is_at_critical_level) {
                $status_class = 'critical';
                $status_text = 'Critical Stock';
            }
        } else {
            if ($is_fully_borrowed) {
                $status_class = 'borrowed';
                $status_text = 'Borrowed';
            } elseif ($is_partially_borrowed) {
                $status_class = 'partially-borrowed';
                $status_text = 'Partially Borrowed';
            }
        }
    }
    
    return [
        'class' => $status_class,
        'text' => $status_text
    ];
} 

function renderEquipmentStatus($display_status, $available_quantity, $total_quantity) {
    $status_info = getEquipmentStatusDisplay($display_status, $available_quantity, $total_quantity);
    return '<span class="status-badge status-' . htmlspecialchars($status_info['class']) . '">' . 
    htmlspecialchars($status_info['text']) . '</span>';
}
?>