<?php
function getEquipmentStatusDisplay($display_status, $available_quantity, $total_quantity) {
    $status_class = $display_status;
    $status_text = ucfirst($display_status);

    if (isset($_SESSION['role']) && $_SESSION['role'] === 'admin') {
        $total_quantity = (int)$total_quantity;
        $available_quantity = (int)$available_quantity;
        $is_critical = ($available_quantity <= ($total_quantity / 2));
        
        if ($display_status == 'partially_borrowed') {
            $status_text = $is_critical ? 'Partially Borrowed/Critical Level' : 'Partially Borrowed';
            if ($is_critical) {
                $status_class = 'critical';
            }
        } elseif ($display_status == 'borrowed') {
            $status_text = $is_critical ? 'Borrowed/Critical Level' : 'Borrowed';
            if ($is_critical) {
                $status_class = 'critical';
            }
        }
    } else {
        if ($display_status == 'partially_borrowed') {
            $status_text = 'Partially Borrowed';
        } elseif ($display_status == 'borrowed') {
            $status_text = 'Borrowed';
        }
    }
    
    return [
        'class' => $status_class,
        'text' => $status_text
    ];
}

function renderEquipmentStatus($display_status, $available_quantity, $total_quantity) {
    $status_info = getEquipmentStatusDisplay($display_status, $available_quantity, $total_quantity);
    return '<span class="status-badge status-' . htmlspecialchars($status_info['class']) . '">' . 
           htmlspecialchars($status_info['text']) . '</span>';
}
?>
