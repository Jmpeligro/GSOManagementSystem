<?php

function getEquipmentStatusDisplay($display_status, $available_quantity, $total_quantity) {
    $display_status = strtolower($display_status);
    
    $criticalMappings = [
        'maintenance_critical' => ['class' => 'critical', 'text' => 'Under Maintenance/Critical'],
        'partially_maintenance_critical' => ['class' => 'critical', 'text' => 'Partially Maintenance/Critical'],
        'partially_both_critical' => ['class' => 'critical', 'text' => 'Partially Both/Critical'],
        'borrowed_critical' => ['class' => 'critical', 'text' => 'Borrowed/Critical'],
        'partially_borrowed_critical' => ['class' => 'critical', 'text' => 'Partially Borrowed/Critical'],
        'available_critical' => ['class' => 'critical', 'text' => 'Critical Stock']
    ];
    
    if (isset($criticalMappings[$display_status])) {
        return $criticalMappings[$display_status];
    }

    $total_quantity = (int)$total_quantity;
    $available_quantity = (int)$available_quantity;
    
    $is_at_critical_level = ($total_quantity === 1) ? 
        ($available_quantity === 0) : 
        ($available_quantity <= ($total_quantity / 2));    $statusMappings = [
        'maintenance' => [
            'normal' => ['class' => 'maintenance', 'text' => 'Under Maintenance'],
            'critical' => ['class' => 'critical', 'text' => 'Under Maintenance/Critical']
        ],
        'partially_maintenance' => [
            'normal' => ['class' => 'maintenance', 'text' => 'Partially Maintenance'],
            'critical' => ['class' => 'critical', 'text' => 'Partially Maintenance/Critical']
        ],
        'borrowed' => [
            'normal' => ['class' => 'borrowed', 'text' => 'Borrowed'],
            'critical' => ['class' => 'critical', 'text' => 'Borrowed/Critical']
        ],
        'partially_borrowed' => [
            'normal' => ['class' => 'borrowed', 'text' => 'Partially Borrowed'],
            'critical' => ['class' => 'critical', 'text' => 'Partially Borrowed/Critical']
        ],
        'partially_both' => [
            'normal' => ['class' => 'warning', 'text' => 'Partially Both'],
            'critical' => ['class' => 'critical', 'text' => 'Partially Both/Critical']
        ],
        'available' => [
            'normal' => ['class' => 'available', 'text' => 'Available'],
            'critical' => ['class' => 'critical', 'text' => 'Critical Stock']
        ]
    ];
    if (isset($statusMappings[$display_status])) {
        if (str_contains($display_status, '_critical')) {
            return $statusMappings[$display_status]['critical'];
        }
        $statusLevel = $is_at_critical_level ? 'critical' : 'normal';
        return $statusMappings[$display_status][$statusLevel];
    }
    
    $status_class = strtolower($display_status);
    $status_text = ucfirst(str_replace('_', ' ', $display_status));
    
    if ($is_at_critical_level && !str_contains($display_status, 'critical')) {
        $status_class = 'critical';
        $status_text .= '/Critical';
    }
    
    return ['class' => $status_class, 'text' => $status_text];
} 

function renderEquipmentStatus($display_status, $available_quantity, $total_quantity) {
    $status_info = getEquipmentStatusDisplay($display_status, $available_quantity, $total_quantity);
    return '<span class="status-badge status-' . htmlspecialchars($status_info['class']) . '">' . 
        htmlspecialchars($status_info['text']) . '</span>';
}


function getStatusDebugInfo($display_status, $available_quantity, $total_quantity) {
    $total_quantity = (int)$total_quantity;
    $available_quantity = (int)$available_quantity;
    
    $is_at_critical_level = ($total_quantity === 1) ? 
        ($available_quantity === 0) : 
        ($available_quantity <= ($total_quantity / 2));
    
    return [
        'display_status' => $display_status,
        'total_quantity' => $total_quantity,
        'available_quantity' => $available_quantity,
        'is_critical' => $is_at_critical_level,
        'critical_threshold' => ($total_quantity === 1) ? 0 : floor($total_quantity / 2),
        'status_info' => getEquipmentStatusDisplay($display_status, $available_quantity, $total_quantity)
    ];
}

function validateEquipmentStatus($equipment_id, $conn) {
    $sql = "SELECT e.equipment_id, e.name, e.quantity, e.status,
                COUNT(CASE WHEN b.status = 'active' THEN 1 END) as borrowed_count,
                COALESCE(SUM(CASE WHEN m.status IN ('pending', 'in_progress') THEN m.units ELSE 0 END), 0) as maintenance_count
            FROM equipment e
            LEFT JOIN borrowings b ON e.equipment_id = b.equipment_id
            LEFT JOIN maintenance m ON e.equipment_id = m.equipment_id
            WHERE e.equipment_id = ?
            GROUP BY e.equipment_id, e.name, e.quantity, e.status";
    
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("i", $equipment_id);
    $stmt->execute();
    $result = $stmt->get_result();
    
    if ($result->num_rows === 0) {
        return null;
    }
    
    $row = $result->fetch_assoc();
    $total_quantity = (int)$row['quantity'];
    $borrowed_count = (int)$row['borrowed_count'];
    $maintenance_count = (int)$row['maintenance_count'];
    $available_quantity = $total_quantity - $borrowed_count - $maintenance_count;
    if ($available_quantity < 0) $available_quantity = 0;
    
    $should_be_status = determineCorrectStatus($total_quantity, $borrowed_count, $maintenance_count, $available_quantity);
    
    return [
        'equipment_id' => $equipment_id,
        'name' => $row['name'],
        'current_status' => $row['status'],
        'should_be_status' => $should_be_status,
        'total_quantity' => $total_quantity,
        'borrowed_count' => $borrowed_count,
        'maintenance_count' => $maintenance_count,
        'available_quantity' => $available_quantity,
        'is_correct' => ($row['status'] === $should_be_status)
    ];
}


function determineCorrectStatus($total_quantity, $borrowed_count, $maintenance_count, $available_quantity) {
    if ($maintenance_count >= $total_quantity) {
        $baseStatus = 'maintenance';
    } else if ($borrowed_count >= $total_quantity) {
        $baseStatus = 'borrowed';
    } else if ($maintenance_count > 0 && $borrowed_count > 0) {
        $baseStatus = 'partially_both';
    } else if ($maintenance_count > 0 && $borrowed_count == 0 && $available_quantity > 0) {
        $baseStatus = 'partially_maintenance';
    } else if ($borrowed_count > 0 && $maintenance_count == 0 && $available_quantity > 0) {
        $baseStatus = 'partially_borrowed';
    } else {
        $baseStatus = 'available';
    }
    
    $isCritical = ($total_quantity === 1) ? 
        ($available_quantity === 0) : 
        ($available_quantity <= ($total_quantity / 2));
    
    return $isCritical ? $baseStatus . '_critical' : $baseStatus;
}

?>