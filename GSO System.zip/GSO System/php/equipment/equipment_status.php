<?php
function getEquipmentStatusDisplay($display_status, $available_quantity, $total_quantity) {
    $total_quantity = (int)$total_quantity;
    $available_quantity = (int)$available_quantity;
    
    $is_fully_borrowed = $available_quantity === 0;
    $is_partially_borrowed = $available_quantity > 0 && $available_quantity < $total_quantity;
    $is_at_critical_level = $available_quantity <= ($total_quantity / 2);
    
    $status_class = strtolower($display_status);
    $status_text = ucfirst($display_status);
    
    if (isset($_SESSION['role']) && $_SESSION['role'] === 'admin') {
        if ($is_fully_borrowed) {
            $status_class = 'critical';
            $status_text = 'Borrowed/Critical';
        } elseif ($is_partially_borrowed && $is_at_critical_level) {
            $status_class = 'critical';
            $status_text = 'Partially Borrowed/Critical';
        } elseif ($is_partially_borrowed) {
            $status_class = 'partially-borrowed';
            $status_text = 'Partially Borrowed';
        } elseif ($display_status === 'available' && $is_at_critical_level) {
            $status_class = 'critical';
            $status_text = 'Critical Stock';
        } elseif ($display_status === 'maintenance') {
            $status_text = 'Under Maintenance';
        }
    } else {
        if ($is_fully_borrowed) {
            $status_class = 'borrowed';
            $status_text = 'Borrowed';
        } elseif ($is_partially_borrowed) {
            $status_class = 'partially-borrowed';
            $status_text = 'Partially Borrowed';
        } elseif ($display_status === 'maintenance') {
            $status_text = 'Under Maintenance';
        }
    }
    
    return [
        'class' => $status_class,
        'text' => $status_text
    ];
}

function renderEquipmentStatus($display_status, $available_quantity, $total_quantity) {
    $status_info = getEquipmentStatusDisplay($display_status, $available_quantity, $total_quantity);
    return '<span class="status-badge status-' . htmlspecialchars($status_info['class']) . '">' . 
           htmlspecialchars($status_info['text']) . '</span>';
}
?>