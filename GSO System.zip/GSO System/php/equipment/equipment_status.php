<?php

/**
 * Determines the display class and text for equipment status based on its current state.
 * 
 * @param string $display_status The current status of the equipment.
 * @param int $available_quantity The number of available units.
 * @param int $total_quantity The total number of units.
 * @return array An associative array containing the class and text for the status.
 */
function getEquipmentStatusDisplay($display_status, $available_quantity, $total_quantity) {
    $display_status = strtolower($display_status);
    
    // Predefined mappings for critical statuses.
    $criticalMappings = [
        'maintenance_critical' => ['class' => 'critical', 'text' => 'Under Maintenance/Critical'],
        'partially_maintenance_critical' => ['class' => 'critical', 'text' => 'Partially Maintenance/Critical'],
        'partially_both_critical' => ['class' => 'critical', 'text' => 'Partially Both/Critical'],
        'borrowed_critical' => ['class' => 'critical', 'text' => 'Borrowed/Critical'],
        'partially_borrowed_critical' => ['class' => 'critical', 'text' => 'Partially Borrowed/Critical'],
        'available_critical' => ['class' => 'critical', 'text' => 'Critical Stock']
    ];
    
    if (isset($criticalMappings[$display_status])) {
        return $criticalMappings[$display_status];
    }

    // Convert quantities to integers for calculations.
    $total_quantity = (int)$total_quantity;
    $available_quantity = (int)$available_quantity;
    
    // Determine if the equipment is at a critical level.
    $is_at_critical_level = ($total_quantity === 1) ? 
        ($available_quantity === 0) : 
        ($available_quantity <= ($total_quantity / 2));

    // Mappings for normal and critical statuses.
    $statusMappings = [
        'maintenance' => [
            'normal' => ['class' => 'maintenance', 'text' => 'Under Maintenance'],
            'critical' => ['class' => 'critical', 'text' => 'Under Maintenance/Critical']
        ],
        'partially_maintenance' => [
            'normal' => ['class' => 'maintenance', 'text' => 'Partially Maintenance'],
            'critical' => ['class' => 'critical', 'text' => 'Partially Maintenance/Critical']
        ],
        'borrowed' => [
            'normal' => ['class' => 'borrowed', 'text' => 'Borrowed'],
            'critical' => ['class' => 'critical', 'text' => 'Borrowed/Critical']
        ],
        'partially_borrowed' => [
            'normal' => ['class' => 'borrowed', 'text' => 'Partially Borrowed'],
            'critical' => ['class' => 'critical', 'text' => 'Partially Borrowed/Critical']
        ],
        'partially_both' => [
            'normal' => ['class' => 'warning', 'text' => 'Partially Both'],
            'critical' => ['class' => 'critical', 'text' => 'Partially Both/Critical']
        ],
        'available' => [
            'normal' => ['class' => 'available', 'text' => 'Available'],
            'critical' => ['class' => 'critical', 'text' => 'Critical Stock']
        ]
    ];

    if (isset($statusMappings[$display_status])) {
        $statusLevel = $is_at_critical_level ? 'critical' : 'normal';
        return $statusMappings[$display_status][$statusLevel];
    }
    
    // Default status if no specific mapping is found.
    $status_class = strtolower($display_status);
    $status_text = ucfirst(str_replace('_', ' ', $display_status));
    
    if ($is_at_critical_level && !str_contains($display_status, 'critical')) {
        $status_class = 'critical';
        $status_text .= '/Critical';
    }
    
    return ['class' => $status_class, 'text' => $status_text];
} 

/**
 * Renders the HTML for the equipment status badge.
 * 
 * @param string $display_status The current status of the equipment.
 * @param int $available_quantity The number of available units.
 * @param int $total_quantity The total number of units.
 * @return string The HTML for the status badge.
 */
function renderEquipmentStatus($display_status, $available_quantity, $total_quantity) {
    $status_info = getEquipmentStatusDisplay($display_status, $available_quantity, $total_quantity);
    return '<span class="status-badge status-' . htmlspecialchars($status_info['class']) . '">' . 
        htmlspecialchars($status_info['text']) . '</span>';
}

/**
 * Provides debug information for the equipment status.
 * 
 * @param string $display_status The current status of the equipment.
 * @param int $available_quantity The number of available units.
 * @param int $total_quantity The total number of units.
 * @return array An associative array containing debug information.
 */
function getStatusDebugInfo($display_status, $available_quantity, $total_quantity) {
    $total_quantity = (int)$total_quantity;
    $available_quantity = (int)$available_quantity;
    
    $is_at_critical_level = ($total_quantity === 1) ? 
        ($available_quantity === 0) : 
        ($available_quantity <= ($total_quantity / 2));
    
    return [
        'display_status' => $display_status,
        'total_quantity' => $total_quantity,
        'available_quantity' => $available_quantity,
        'is_critical' => $is_at_critical_level,
        'critical_threshold' => ($total_quantity === 1) ? 0 : floor($total_quantity / 2),
        'status_info' => getEquipmentStatusDisplay($display_status, $available_quantity, $total_quantity)
    ];
}

/**
 * Validates the equipment status and determines if it matches the expected status.
 * 
 * @param int $equipment_id The ID of the equipment.
 * @param mysqli $conn The database connection object.
 * @return array|null An associative array with validation details or null if the equipment is not found.
 */
function validateEquipmentStatus($equipment_id, $conn) {
    $sql = "SELECT e.equipment_id, e.name, e.quantity, e.status,
                COUNT(CASE WHEN b.status = 'active' THEN 1 END) as borrowed_count,
                COALESCE(SUM(CASE WHEN m.status IN ('pending', 'in_progress') THEN m.units ELSE 0 END), 0) as maintenance_count
            FROM equipment e
            LEFT JOIN borrowings b ON e.equipment_id = b.equipment_id
            LEFT JOIN maintenance m ON e.equipment_id = m.equipment_id
            WHERE e.equipment_id = ?
            GROUP BY e.equipment_id, e.name, e.quantity, e.status";
    
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("i", $equipment_id);
    $stmt->execute();
    $result = $stmt->get_result();
    
    if ($result->num_rows === 0) {
        return null;
    }
    
    $row = $result->fetch_assoc();
    $total_quantity = (int)$row['quantity'];
    $borrowed_count = (int)$row['borrowed_count'];
    $maintenance_count = (int)$row['maintenance_count'];
    $available_quantity = $total_quantity - $borrowed_count - $maintenance_count;
    if ($available_quantity < 0) $available_quantity = 0;
    
    $should_be_status = determineCorrectStatus($total_quantity, $borrowed_count, $maintenance_count, $available_quantity);
    
    return [
        'equipment_id' => $equipment_id,
        'name' => $row['name'],
        'current_status' => $row['status'],
        'should_be_status' => $should_be_status,
        'total_quantity' => $total_quantity,
        'borrowed_count' => $borrowed_count,
        'maintenance_count' => $maintenance_count,
        'available_quantity' => $available_quantity,
        'is_correct' => ($row['status'] === $should_be_status)
    ];
}

/**
 * Determines the correct status for equipment based on its quantities.
 * 
 * @param int $total_quantity The total number of units.
 * @param int $borrowed_count The number of borrowed units.
 * @param int $maintenance_count The number of units under maintenance.
 * @param int $available_quantity The number of available units.
 * @return string The correct status for the equipment.
 */
function determineCorrectStatus($total_quantity, $borrowed_count, $maintenance_count, $available_quantity) {
    if ($maintenance_count >= $total_quantity) {
        $baseStatus = 'maintenance';
    } else if ($borrowed_count >= $total_quantity) {
        $baseStatus = 'borrowed';
    } else if ($maintenance_count > 0 && $borrowed_count > 0) {
        $baseStatus = 'partially_both';
    } else if ($maintenance_count > 0 && $borrowed_count == 0 && $available_quantity > 0) {
        $baseStatus = 'partially_maintenance';
    } else if ($borrowed_count > 0 && $maintenance_count == 0 && $available_quantity > 0) {
        $baseStatus = 'partially_borrowed';
    } else {
        $baseStatus = 'available';
    }
    
    $isCritical = ($total_quantity === 1) ? 
        ($available_quantity === 0) : 
        ($available_quantity <= ($total_quantity / 2));
    
    return $isCritical ? $baseStatus . '_critical' : $baseStatus;
}

?>