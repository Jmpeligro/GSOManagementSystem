<?php
session_start();
require_once '../db_connection.php';
require_once '../helpers.php';
require_once 'equipment_status.php';
require_once '../classes/Equipment/Equipment.php';

if (!isLoggedIn()) {
    header("Location: ../login.php");
    exit();
}

$response = [
    'success' => false,
    'message' => '',
    'redirect' => ''
];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!isAdmin()) {
        $_SESSION['error'] = "You do not have permission to perform this action.";
        header("Location: equipment.php");
        exit();
    }
    
    $equipment = new Equipment($conn);
    $equipment_id = isset($_POST['equipment_id']) ? (int)$_POST['equipment_id'] : 0;

    if ($equipment_id > 0) {
        if (!$equipment->load($equipment_id)) {
            $_SESSION['error'] = "Equipment not found.";
            header("Location: equipment.php");
            exit();
        }
    }

    $action = $_POST['action'] ?? '';
    
    switch ($action) {
        case 'delete':
            if ($equipment->getStatus() === 'maintenance') {
                $_SESSION['error'] = "Equipment under maintenance cannot be deleted.";
                header("Location: equipment.php");
                exit();
            }

            $result = $equipment->delete();
            $response = $result;
            $response['redirect'] = 'equipment.php';
            break;
            
        case 'update_status':
            $new_status = sanitize($_POST['new_status']);
            $result = $equipment->updateStatus($new_status);
            $response = $result;
            $response['redirect'] = $_SERVER['HTTP_REFERER'];
            break;
            
        case 'update_quantity':
            $new_quantity = (int)$_POST['new_quantity'];
            $result = $equipment->updateQuantity($new_quantity);
            $response = $result;
            $response['redirect'] = $_SERVER['HTTP_REFERER'];
            break;
            
        case 'borrow':
            if ($equipment->getStatus() === 'maintenance') {
                $_SESSION['error'] = "Equipment under maintenance cannot be borrowed.";
                header("Location: equipment.php");
                exit();
            }

            $user_id = $_SESSION['user_id']; 
            $borrow_sql = "INSERT INTO borrowings (equipment_id, user_id, status, created_at, updated_at) VALUES (?, ?, 'active', NOW(), NOW())";
            $borrow_stmt = $conn->prepare($borrow_sql);
            $borrow_stmt->bind_param("ii", $equipment_id, $user_id);

            if ($borrow_stmt->execute()) {
                $borrowed_count = $equipment->getBorrowedCount();
                $available_quantity = $equipment->getQuantity() - $borrowed_count;

                if ($available_quantity == 0) {
                    $new_status = 'borrowed';
                } else {
                    $new_status = 'partially_borrowed';
                }

                $equipment->updateStatus($new_status);
                $equipment->updateQuantity($available_quantity);

                $response['success'] = true;
                $response['message'] = "Equipment borrowed successfully.";
            } else {
                $response['success'] = false;
                $response['message'] = "Error borrowing equipment: " . $borrow_stmt->error;
            }

            $response['redirect'] = 'equipment.php';
            break;
    }
  
    if ($response['success']) {
        $_SESSION['success'] = $response['message'];
    } else {
        $_SESSION['error'] = $response['message'];
    }
   
    if (!empty($response['redirect'])) {
        header("Location: {$response['redirect']}");
        exit();
    }
}

// Initialize filters
$filters = [
    'status' => '',
    'category' => isset($_GET['category']) ? (int)$_GET['category'] : 0,
    'search' => isset($_GET['search']) ? sanitize($_GET['search']) : ''
];

// Handle status filter properly
if (isset($_GET['status']) && !empty($_GET['status'])) {
    $status_input = sanitize($_GET['status']);
    
    // Handle borrowed status filter specifically
    if (strtolower($status_input) === 'borrowed') {
        // Set filter to handle all borrowed-related statuses
        $filters['status'] = 'borrowed';
    } else {
        $filters['status'] = $status_input;
    }
} elseif (isset($_GET['filter']) && $_GET['filter'] === 'critical') {
    $filters['status'] = 'critical';
} elseif (isset($_GET['filter']) && $_GET['filter'] === 'maintenance') {
    $filters['status'] = ['partially_maintenance', 'partially_both', 'maintenance'];
}

$search_query = $filters['search'];
$status_filter = $filters['status'];
$category_filter = $filters['category'];

// Get equipment data
$result = Equipment::getAll($conn, $filters);

// Get categories for filter dropdown
$sql_categories = "SELECT * FROM categories ORDER BY name ASC";
$categories_result = $conn->query($sql_categories);

include '../../pages/equipment/equipment.html';
?>