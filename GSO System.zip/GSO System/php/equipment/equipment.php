<?php
session_start();
require_once '../db_connection.php';
require_once '../classes/Equipment/Equipment.php';

if (!isLoggedIn()) {
    header("Location: ../login.php");
    exit();
}

$response = [
    'success' => false,
    'message' => '',
    'redirect' => ''
];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!isAdmin()) {
        $_SESSION['error'] = "You do not have permission to perform this action.";
        header("Location: equipment.php");
        exit();
    }
    
    $equipment = new Equipment($conn);
    $equipment_id = isset($_POST['equipment_id']) ? (int)$_POST['equipment_id'] : 0;

    if ($equipment_id > 0) {
        if (!$equipment->load($equipment_id)) {
            $_SESSION['error'] = "Equipment not found.";
            header("Location: equipment.php");
            exit();
        }
    }

    $action = $_POST['action'] ?? '';
    
    switch ($action) {
        case 'delete':
            $result = $equipment->delete();
            $response = $result;
            $response['redirect'] = 'equipment.php';
            break;
            
        case 'update_status':
            $new_status = sanitize($_POST['new_status']);
            $result = $equipment->updateStatus($new_status);
            $response = $result;
            $response['redirect'] = $_SERVER['HTTP_REFERER'];
            break;
            
        case 'update_quantity':
            $new_quantity = (int)$_POST['new_quantity'];
            $result = $equipment->updateQuantity($new_quantity);
            $response = $result;
            $response['redirect'] = $_SERVER['HTTP_REFERER'];
            break;
    }
  
    if ($response['success']) {
        $_SESSION['success'] = $response['message'];
    } else {
        $_SESSION['error'] = $response['message'];
    }
   
    if (!empty($response['redirect'])) {
        header("Location: {$response['redirect']}");
        exit();
    }
}

$filters = [
    'status' => isset($_GET['status']) ? sanitize($_GET['status']) : '',
    'category' => isset($_GET['category']) ? (int)$_GET['category'] : 0,
    'search' => isset($_GET['search']) ? sanitize($_GET['search']) : ''
];

$search_query = $filters['search'];

$status_filter = $filters['status'];
$category_filter = $filters['category'];

$result = Equipment::getAll($conn, $filters);

$sql_categories = "SELECT * FROM categories ORDER BY name ASC";
$categories_result = $conn->query($sql_categories);

include '../../pages/equipment/equipment.html';
?>