<?php

function sanitize($input) {
    return htmlspecialchars(trim($input), ENT_QUOTES, 'UTF-8');
}

function isLoggedIn() {
    return isset($_SESSION['user_id']) && !empty($_SESSION['user_id']);
}

function isAdmin() {
    return isset($_SESSION['role']) && $_SESSION['role'] === 'admin';
}

function redirectWithMessage($url, $message) {
    $_SESSION['error'] = $message;
    header("Location: $url");
    exit();
}

function getEquipmentStatusDisplay($status, $available_quantity, $total_quantity) {
    $total_quantity = (int)$total_quantity;
    $available_quantity = (int)$available_quantity;
    
    $is_fully_borrowed = $available_quantity === 0;
    $is_partially_borrowed = $available_quantity > 0 && $available_quantity < $total_quantity;
    $is_at_critical_level = $available_quantity <= ($total_quantity / 2);
    
    $statusInfo = [
        'class' => strtolower($status),
        'text' => ucfirst($status)
    ];
    
    if (isset($_SESSION['role']) && $_SESSION['role'] === 'admin') {
        // Admin view - show critical levels
        if ($is_fully_borrowed) {
            $statusInfo['class'] = 'critical';
            $statusInfo['text'] = 'Borrowed/Critical';
        } elseif ($is_partially_borrowed && $is_at_critical_level) {
            $statusInfo['class'] = 'critical';
            $statusInfo['text'] = 'Partially Borrowed/Critical';
        } elseif ($is_partially_borrowed) {
            $statusInfo['class'] = 'partially-borrowed';
            $statusInfo['text'] = 'Partially Borrowed';
        } elseif ($status === 'available' && $is_at_critical_level) {
            $statusInfo['class'] = 'critical';
            $statusInfo['text'] = 'Critical Stock';
        } elseif ($status === 'maintenance') {
            $statusInfo['text'] = 'Under Maintenance';
        }
    } else {
        if ($is_fully_borrowed) {
            $statusInfo['class'] = 'borrowed';
            $statusInfo['text'] = 'Borrowed';
        } elseif ($is_partially_borrowed) {
            $statusInfo['class'] = 'partially-borrowed';
            $statusInfo['text'] = 'Partially Borrowed';
        } elseif ($status === 'maintenance') {
            $statusInfo['text'] = 'Under Maintenance';
        }
    }

    return $statusInfo;
}
?>