<?php
session_start();

require_once '../db_connection.php';
require_once '../classes/User/User.php';

if (!isLoggedIn() || !isAdmin()) {
    $_SESSION['error'] = "You do not have permission to access this page.";
    header("Location: ../login.php");
    exit();
}

// Set the page title and mode for adding a new user
$title = "Add New User";
$mode = 'add';
$user_id = 0;

// Initialize variables for user input fields
$university_id = '';
$first_name = '';
$last_name = '';
$email = '';
$role = '';
$department = '';
$phone = '';
$program_year_section = '';

// Handle form submission for adding a new user
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    //collect form data
    $data = [
        'university_id' => sanitize($_POST['university_id']),
        'first_name' => sanitize($_POST['first_name']),
        'last_name' => sanitize($_POST['last_name']),
        'email' => sanitize($_POST['email']),
        'password' => $_POST['password'],
        'confirm_password' => $_POST['confirm_password'],
        'role' => sanitize($_POST['role']),
        'department' => sanitize($_POST['department']),
        'phone' => isset($_POST['phone']) ? sanitize($_POST['phone']) : ''
    ];
    
    // Add program year and section if the role is 'student'
    if ($data['role'] === 'student') {
        $data['program_year_section'] = sanitize($_POST['program_year_section'] ?? '');
    } else {
        $data['program_year_section'] = '';
    }
    
    // Create a new User object and attempt to add the user
    $user = new User($conn);
    $result = $user->create($data);
    
    // Handle the result of the user creation process
    if ($result['success']) {
        // Set a success message and redirect to the users page
        $_SESSION['success'] = $result['message'];
        header("Location: users.php");
        exit();
    } else {
        // Set an error message and retain form data for re-population
        $_SESSION['error'] = $result['message'];

        $university_id = $data['university_id'];
        $first_name = $data['first_name'];
        $last_name = $data['last_name'];
        $email = $data['email'];
        $role = $data['role'];
        $department = $data['department'];
        $phone = $data['phone'];
        $program_year_section = $data['program_year_section'];
    }
}

include '../../pages/users/user_management.html';
?>