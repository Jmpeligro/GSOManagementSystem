<?php
session_start();
require_once 'db_connection.php';
require_once 'helpers.php';
require_once 'classes/borrowing/Borrowing.php';

if (!isLoggedIn()) {
    header("Location: login.php");
    exit();
}

if (isAdmin()) {
    header("Location: dashboard.php");
    exit();
}

$user_id = $_SESSION['user_id'];

$sql_available = "SELECT COUNT(*) as count FROM equipment WHERE status = 'available'";
$sql_borrowed = "SELECT COUNT(*) as count FROM borrowings 
                WHERE user_id = ? AND (status = 'active' OR status = 'overdue')";
$sql_maintenance = "SELECT COUNT(*) as count FROM equipment WHERE status = 'maintenance'";
$sql_categories = "SELECT COUNT(*) as count FROM categories";

$result_available = $conn->query($sql_available);
$available_count = $result_available->fetch_assoc()['count'];

$result_maintenance = $conn->query($sql_maintenance);
$maintenance_count = $result_maintenance->fetch_assoc()['count'];

$result_categories = $conn->query($sql_categories);
$categories_count = $result_categories->fetch_assoc()['count'];

$stmt_borrowed = $conn->prepare($sql_borrowed);
$stmt_borrowed->bind_param("i", $user_id);
$stmt_borrowed->execute();
$result_borrowed = $stmt_borrowed->get_result();
$borrowed_count = $result_borrowed->fetch_assoc()['count'];

$sql_recent = "SELECT b.borrowing_id, e.name as equipment_name, 
            b.borrow_date, b.due_date, b.status
            FROM borrowings b
            JOIN equipment e ON b.equipment_id = e.equipment_id
            WHERE b.user_id = ?
            ORDER BY b.created_at DESC
            LIMIT 5";

$stmt = $conn->prepare($sql_recent);
$stmt->bind_param("i", $user_id);
$stmt->execute();
$result_recent = $stmt->get_result();

$overdue_items = [];
$sql_overdue = "SELECT b.borrowing_id, e.name as equipment_name, b.due_date
                FROM borrowings b 
                JOIN equipment e ON b.equipment_id = e.equipment_id
                WHERE b.user_id = ? AND b.status = 'active' 
                AND b.due_date < CURDATE()";

$stmt_overdue = $conn->prepare($sql_overdue);
$stmt_overdue->bind_param("i", $user_id);
$stmt_overdue->execute();
$result_overdue = $stmt_overdue->get_result();

while ($row = $result_overdue->fetch_assoc()) {
    $overdue_items[] = $row;
}

$chart_data = [
    'available' => $available_count,
    'borrowed' => $borrowed_count,
    'maintenance' => $maintenance_count
];

$stmt_borrowed->close();
$stmt->close();
$stmt_overdue->close();

include '../pages/dashboard_borrower.html';
?>
