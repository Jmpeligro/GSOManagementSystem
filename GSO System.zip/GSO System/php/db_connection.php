<?php
// Include the Database and Auth classes
require_once __DIR__ . '/classes/Database.php';
require_once __DIR__ . '/classes/Auth.php';

// Get database connection
$db = Database::getInstance();
$conn = $db->getConnection();

// Maintain backwards compatibility with existing code
if (!function_exists('sanitize')) {
    function sanitize($data) {
        global $db;
        return $db->sanitize($data);
    }
}

if (!function_exists('isLoggedIn')) {
    function isLoggedIn() {
        return Auth::isLoggedIn();
    }
}

if (!function_exists('isAdmin')) {
    function isAdmin() {
        return Auth::isAdmin();
    }
}
?>