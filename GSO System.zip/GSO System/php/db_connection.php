<?php
// This file establishes a database connection using the Database class and provides access to authentication utilities via the Auth class.
// It acts as a central point for including essential dependencies like Database.php and Auth.php, ensuring consistent access across the application.

require_once __DIR__ . '/classes/Database.php';
require_once __DIR__ . '/classes/Auth.php';
require_once __DIR__ . '/helpers.php';

$db = Database::getInstance();
$conn = $db->getConnection();

?>