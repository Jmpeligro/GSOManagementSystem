<?php
session_start();
require_once 'db_connection.php';
require_once 'borrowings/notifications.php';

$error = '';
$success = '';
$step = 1; 
$email = '';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    
    if (isset($_POST['send_code'])) {
        $email = sanitize($_POST['email']);

        if (empty($email)) {
            $error = "Please enter your email address.";
        } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
            $error = "Please enter a valid email address.";
        } elseif (!preg_match('/@plpasig\.edu\.ph$/', $email)) {
            $error = "Please use your PLP institutional email (@plpasig.edu.ph)";
        } else {
            $query = "SELECT user_id, first_name, last_name FROM users WHERE email = ?";
            $stmt = $conn->prepare($query);
            $stmt->bind_param("s", $email);
            $stmt->execute();
            $result = $stmt->get_result();
            
            if ($result->num_rows == 1) {
                $verification_code = sprintf("%06d", rand(0, 999999));
                $user = $result->fetch_assoc();

                $_SESSION['reset_email'] = $email;
                $_SESSION['reset_code'] = $verification_code;
                $_SESSION['reset_code_time'] = time(); 
                $_SESSION['reset_user_id'] = $user['user_id'];
                
                $recipientName = $user['first_name'] . ' ' . $user['last_name'];
                $subject = "Password Reset Verification Code";
                $body = "
                    <html>
                    <head>
                        <style>
                            body { font-family: Arial, sans-serif; line-height: 1.6; }
                            .container { max-width: 600px; margin: 0 auto; padding: 20px; }
                            .header { text-align: center; padding: 20px 0; }
                            .code { font-size: 24px; font-weight: bold; text-align: center; 
                                  padding: 15px; background-color: #f5f5f5; margin: 20px 0; }
                            .footer { font-size: 12px; color: #777; text-align: center; margin-top: 30px; }
                        </style>
                    </head>
                    <body>
                        <div class='container'>
                            <div class='header'>
                                <h2>Password Reset Request</h2>
                            </div>
                            <p>Hello $recipientName,</p>
                            <p>We received a request to reset your password for your PLP General Service Office account.</p>
                            <p>Your verification code is:</p>
                            <div class='code'>$verification_code</div>
                            <p>This code will expire in 15 minutes. If you did not request this password reset, please ignore this email or contact support.</p>
                            <div class='footer'>
                                <p>This is an automated message, please do not reply.</p>
                                <p>PLP General Service Office</p>
                            </div>
                        </div>
                    </body>
                    </html>
                ";
                $altbody = "Your password reset verification code is: $verification_code. This code will expire in 15 minutes.";
                
                sendEmail($email, $recipientName, $subject, $body, $altbody);
                
                $success = "Verification code sent to your email. Please check your inbox.";
                $step = 2; 
            } else {
                $error = "Email address not found in our records.";
            }
        }
    }
  
    elseif (isset($_POST['verify_code'])) {
        $email = $_SESSION['reset_email'] ?? '';
        $verification_code = sanitize($_POST['verification_code']);
        $stored_code = $_SESSION['reset_code'] ?? '';
        $code_time = $_SESSION['reset_code_time'] ?? 0;
        
        if (time() - $code_time > 900) {
            $error = "Verification code has expired. Please request a new one.";
            $step = 1; 
            unset($_SESSION['reset_code']);
            unset($_SESSION['reset_code_time']);
        }
        elseif (empty($verification_code)) {
            $error = "Please enter the verification code.";
            $step = 2;
        }
        elseif ($verification_code !== $stored_code) {
            $error = "Invalid verification code. Please try again.";
            $step = 2; 
        }
        else {
            $success = "Code verified successfully! Please set your new password.";
            $step = 3; 
        }
    }
    
    elseif (isset($_POST['reset_password'])) {
        $email = $_SESSION['reset_email'] ?? '';
        $user_id = $_SESSION['reset_user_id'] ?? 0;
        $new_password = $_POST['new_password'];
        $confirm_password = $_POST['confirm_password'];
        
        if (empty($new_password) || empty($confirm_password)) {
            $error = "Please enter and confirm your new password.";
            $step = 3; 
        }
        elseif (strlen($new_password) < 8) {
            $error = "Password must be at least 8 characters long.";
            $step = 3; 
        }
        elseif ($new_password !== $confirm_password) {
            $error = "Passwords do not match.";
            $step = 3;
        }
        else {
            $hashed_password = password_hash($new_password, PASSWORD_DEFAULT);
            $update_query = "UPDATE users SET password = ?, updated_at = NOW() WHERE user_id = ?";
            $update_stmt = $conn->prepare($update_query);
            $update_stmt->bind_param("si", $hashed_password, $user_id);
              if ($update_stmt->execute()) {
                unset($_SESSION['reset_email']);
                unset($_SESSION['reset_code']);
                unset($_SESSION['reset_code_time']);
                unset($_SESSION['reset_user_id']);
                
                $success = "Password reset successfully! Redirecting to login page...";
                $_SESSION['login_message'] = "Password has been reset successfully. Please login with your new password.";
                header("Location: login.php");
                exit();
            } else {
                $error = "Error updating password. Please try again.";
                $step = 3; 
            }
        }
    }
}

include '../pages/forgot_password.html';
?>