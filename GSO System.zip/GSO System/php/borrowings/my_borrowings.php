<?php
session_start();

require_once '../db_connection.php';
require_once '../helpers.php'; 
require_once '../classes/borrowing/Borrowing.php';

if (!isLoggedIn()) {
    header("Location: ../login.php");
    exit();
}

// Get the logged-in user's ID from the session.
$user_id = $_SESSION['user_id'];

// Fetch all borrowings associated with the logged-in user.
$borrowings = Borrowing::getUserBorrowings($conn, $user_id);

// Handle equipment return request.
if (isset($_GET['return']) && !empty($_GET['return'])) {
    $borrowing_id = (int)$_GET['return'];
    
    $borrowing = new Borrowing($conn);
    // Load the borrowing record by ID.
    if ($borrowing->load($borrowing_id)) {
        // Ensure the borrowing belongs to the logged-in user.
        if ($borrowing->getUserId() == $user_id) {
            // Attempt to return the equipment.
            $result = $borrowing->returnEquipment($user_id, 'good', 'Returned via my borrowings page');
            
            // Set success or error message based on the result.
            if ($result['success']) {
                $_SESSION['success'] = $result['message'];
            } else {
                $_SESSION['error'] = $result['message'];
            }
        } else {
            $_SESSION['error'] = "You can only return equipment that you borrowed.";
        }
    } else {
        $_SESSION['error'] = "Borrowing record not found.";
    }

    header("Location: my_borrowings.php");
    exit();
}

// Handle borrowing cancellation request.
if (isset($_GET['cancel']) && !empty($_GET['cancel'])) {
    $borrowing_id = (int)$_GET['cancel'];
    
    $borrowing = new Borrowing($conn);
    // Load the borrowing record by ID.
    if ($borrowing->load($borrowing_id)) {
        // Ensure the borrowing belongs to the logged-in user and is in a cancellable state.
        if ($borrowing->getUserId() == $user_id && 
            $borrowing->getApprovalStatus() == 'pending' && 
            $borrowing->getStatus() != 'active') {
            
            // Attempt to cancel the borrowing.
            $result = $borrowing->cancel();
            
            // Set success or error message based on the result.
            if ($result['success']) {
                $_SESSION['success'] = $result['message'];
            } else {
                $_SESSION['error'] = $result['message'];
            }
        } else {
            $_SESSION['error'] = "Invalid request or request already processed.";
        }
    } else {
        $_SESSION['error'] = "Borrowing record not found.";
    }
    
    // Redirect back to the my borrowings page.
    header("Location: my_borrowings.php");
    exit();
}

// Identify overdue items from the user's borrowings.
$overdue_items = [];
foreach ($borrowings as $borrowing) {
    $borrow = new Borrowing($conn);
    $borrow->load($borrowing['borrowing_id']);
    
    // Check if the borrowing is overdue and add it to the overdue items list.
    if ($borrow->isOverdue()) {
        $overdue_items[] = $borrowing;
    }
}

include '../../pages/borrowings/my_borrowings.html';
?>