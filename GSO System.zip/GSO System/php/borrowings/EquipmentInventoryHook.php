<?php

require_once __DIR__ . '/EquipmentThreshold.php';

function checkEquipmentLevelsAfterChange($conn, $equipment_id = null) {
    if ($equipment_id) {
        $sql = "SELECT equipment_id FROM equipment WHERE equipment_id = ?";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("i", $equipment_id);
        $stmt->execute();
        $result = $stmt->get_result();
        $stmt->close();
        
        $criticalEquipment = [];
        
        if ($result->num_rows > 0) {
            $row = $result->fetch_assoc();
            $equipment = new Equipment($conn);
            $equipment->load($row['equipment_id']);
            
            $id = $equipment->getId();
            $name = $equipment->getName();
            $quant = $equipment->getQuantity();            $avbl_quant = $equipment->getAvailableQuantity();              
            $isCritical = $quant === 1 ? $avbl_quant === 0 : $avbl_quant <= ($quant / 2);
            if ($isCritical) {
                $criticalEquipment[] = [
                    'id' => $id,
                    'name' => $name,
                    'quantity' => $quant,
                    'available_quantity' => $avbl_quant
                ];
            }
        }
        
        if (!empty($criticalEquipment)) {
            sendCriticalQuantityNotification($criticalEquipment, [], $conn);
            return $criticalEquipment;
        }
        
        return null;
    } else {
        return checkEquipmentQuantityLevels($conn);
    }
}

function checkEquipmentAfterUpdate($conn, $equipment) {
    return checkEquipmentLevelsAfterChange($conn, $equipment->getId());
}