<?php

require_once __DIR__ . '/EquipmentThreshold.php';

function checkEquipmentLevelsAfterChange($conn, $equipment_id = null) {
    return checkEquipmentQuantityLevels($conn);
}

function checkEquipmentAfterUpdate($conn, $equipment) {
    return checkEquipmentLevelsAfterChange($conn, $equipment->getId());
}