<?php

// This file defines hooks for checking and updating equipment inventory levels after changes.
// It integrates with the `EquipmentThreshold` module to ensure inventory thresholds are maintained.

require_once __DIR__ . '/EquipmentThreshold.php';

function checkEquipmentLevelsAfterChange($conn, $equipment_id = null) {
    return checkEquipmentQuantityLevels($conn);
}

function checkEquipmentAfterUpdate($conn, $equipment) {
    return checkEquipmentLevelsAfterChange($conn, $equipment->getId());
}