<?php

require_once __DIR__ . '/../db_connection.php'; 
require_once __DIR__ . '/notifications.php';

function checkSingleEquipmentStatus($conn, $equipment_id) {
    if (!$conn) {
        error_log("Database connection is null in checkSingleEquipmentStatus");
        return false;
    }
    
    $sql = "SELECT equipment_id, name, quantity FROM equipment WHERE equipment_id = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("i", $equipment_id);
    $stmt->execute();
    $result = $stmt->get_result();
    
    if ($result->num_rows === 0) {
        error_log("Equipment ID {$equipment_id} not found");
        return false;
    }
    
    $row = $result->fetch_assoc();
    $id = $row['equipment_id'];
    $name = $row['name'];
    $total_quantity = (int)$row['quantity'];

    $borrowed_sql = "SELECT COUNT(*) as count FROM borrowings WHERE equipment_id = ? AND status = 'active'";
    $borrowed_stmt = $conn->prepare($borrowed_sql);
    $borrowed_stmt->bind_param("i", $id);
    $borrowed_stmt->execute();
    $borrowed_count = (int)$borrowed_stmt->get_result()->fetch_assoc()['count'];
    $borrowed_stmt->close();

    $maintenance_sql = "SELECT COALESCE(SUM(units), 0) as count FROM maintenance WHERE equipment_id = ? AND status IN ('pending', 'in_progress')";
    $maintenance_stmt = $conn->prepare($maintenance_sql);
    $maintenance_stmt->bind_param("i", $id);
    $maintenance_stmt->execute();
    $maintenance_count = (int)$maintenance_stmt->get_result()->fetch_assoc()['count'];
    $maintenance_stmt->close();

    $available_quantity = $total_quantity - $borrowed_count - $maintenance_count;
    if ($available_quantity < 0) $available_quantity = 0;

    error_log("[DEBUG] Equipment: $name | Total: $total_quantity | Borrowed: $borrowed_count | Maintenance: $maintenance_count | Available: $available_quantity");

    $baseStatus = determineBaseStatus($total_quantity, $borrowed_count, $maintenance_count, $available_quantity);
    
    error_log("[DEBUG] Determined baseStatus: $baseStatus");
    $isCritical = isCriticalLevel($total_quantity, $available_quantity);
    $status_fetch_sql = "SELECT status FROM equipment WHERE equipment_id = ?";
    $status_fetch_stmt = $conn->prepare($status_fetch_sql);
    $status_fetch_stmt->bind_param("i", $id);
    $status_fetch_stmt->execute();
    $current_status = $status_fetch_stmt->get_result()->fetch_assoc()['status'];
    $status_fetch_stmt->close();

    $new_status = $isCritical ? $baseStatus . '_critical' : $baseStatus;

    if ($current_status !== $new_status) {
        $status_sql = "UPDATE equipment SET status = ? WHERE equipment_id = ?";
        $status_stmt = $conn->prepare($status_sql);
        $status_stmt->bind_param("si", $new_status, $id);
        if ($status_stmt->execute()) {
            error_log("Updated equipment {$name} (ID: {$id}) status from '{$current_status}' to '{$new_status}'");
        } else {
            error_log("Failed to update equipment {$name} (ID: {$id}) status: " . $status_stmt->error);
            return false;
        }
    } else {
        error_log("Equipment {$name} (ID: {$id}) status '{$current_status}' unchanged - already correct");
    }

    if ($isCritical) {
        $criticalReason = generateCriticalReason($baseStatus, $available_quantity, $total_quantity, $borrowed_count, $maintenance_count);

        $equipmentDetails = [
            'id' => $id,
            'name' => $name,
            'quantity' => $total_quantity,
            'available_quantity' => $available_quantity,
            'status' => $new_status,
            'critical_reason' => $criticalReason
        ];
        
        error_log("[{$name}] Critical: Available={$available_quantity}, Total={$total_quantity}, Status={$new_status}, Reason={$criticalReason}");
        
        sendCriticalQuantityNotification([$equipmentDetails], [], $conn);
        
        return $equipmentDetails;
    }
    
    return true;
}

function determineBaseStatus($total_quantity, $borrowed_count, $maintenance_count, $available_quantity) {
    if ($maintenance_count >= $total_quantity) {
        return 'maintenance';
    }
    
    if ($borrowed_count >= $total_quantity) {
        return 'borrowed';
    }
    
    if ($available_quantity === 0) {
        if ($borrowed_count > 0 && $maintenance_count > 0) {
            return 'partially_both';
        } else if ($maintenance_count > 0) {
            return 'maintenance';
        } else if ($borrowed_count > 0) {
            return 'borrowed';
        }
    }

    if ($borrowed_count > 0 && $maintenance_count > 0) {
        return 'partially_both';
    } else if ($maintenance_count > 0) {
        return 'partially_maintenance';
    } else if ($borrowed_count > 0) {
        return 'partially_borrowed';
    }
    
    return 'available';
}

function isCriticalLevel($total_quantity, $available_quantity) {
    if ($total_quantity == 1) {
        return $available_quantity === 0;
    } else {

        return $available_quantity <= ($total_quantity / 2);
    }
}

function generateCriticalReason($baseStatus, $available_quantity, $total_quantity, $borrowed_count, $maintenance_count) {
    $reasons = [];
    
    if ($available_quantity === 0) {
        switch ($baseStatus) {
            case 'maintenance':
                $reasons[] = "All units under maintenance";
                break;
            case 'borrowed':
                $reasons[] = "All units borrowed";
                break;
            case 'partially_both':
                $reasons[] = "All units split between borrowing and maintenance";
                break;
            default:
                $reasons[] = "No units available";
        }
    } else {
        if ($baseStatus === 'partially_maintenance') {
            $reasons[] = "Some units under maintenance";
        }
        if ($baseStatus === 'partially_borrowed') {
            $reasons[] = "Some units borrowed";
        }
        if ($baseStatus === 'partially_both') {
            $reasons[] = "Units split between borrowing and maintenance";
        }
        
        if ($available_quantity <= ($total_quantity / 2)) {
            $reasons[] = "Low stock level ({$available_quantity}/{$total_quantity} available)";
        }
    }
    
    return implode(", ", $reasons);
}

function checkEquipmentQuantityLevels($conn) {
    if (!$conn) {
        error_log("Database connection is null in checkEquipmentQuantityLevels");
        return [];
    }
    
    usleep(100000);
    $lastNotificationFile = __DIR__ . '/../logs/equipment_notification_timestamp.txt';
    $notificationLockFile = __DIR__ . '/../logs/notification.lock';

    if (file_exists($notificationLockFile)) {
        $lockTime = (int)file_get_contents($notificationLockFile);
        if (time() - $lockTime < 30) {
            return [];
        }
    }
    
    file_put_contents($notificationLockFile, time());
    
    if (file_exists($lastNotificationFile)) {
        $lastNotification = (int)file_get_contents($lastNotificationFile);
        if (time() - $lastNotification < 300) { 
            unlink($notificationLockFile); 
            return [];
        }
    }

    $sql = "SELECT equipment_id, name, quantity FROM equipment";
    $result = $conn->query($sql);
    $criticalEquipment = [];
    
    if ($result->num_rows > 0) {
        while ($row = $result->fetch_assoc()) {
            $id = $row['equipment_id'];
            $name = $row['name'];
            $total_quantity = (int)$row['quantity'];

            $borrowed_sql = "SELECT COUNT(*) as count FROM borrowings WHERE equipment_id = ? AND status = 'active'";
            $borrowed_stmt = $conn->prepare($borrowed_sql);
            $borrowed_stmt->bind_param("i", $id);
            $borrowed_stmt->execute();
            $borrowed_count = (int)$borrowed_stmt->get_result()->fetch_assoc()['count'];
            $borrowed_stmt->close();

            $maintenance_sql = "SELECT COALESCE(SUM(units), 0) as count FROM maintenance WHERE equipment_id = ? AND status IN ('pending', 'in_progress')";
            $maintenance_stmt = $conn->prepare($maintenance_sql);
            $maintenance_stmt->bind_param("i", $id);
            $maintenance_stmt->execute();
            $maintenance_count = (int)$maintenance_stmt->get_result()->fetch_assoc()['count'];
            $maintenance_stmt->close();

            $available_quantity = $total_quantity - $borrowed_count - $maintenance_count;
            if ($available_quantity < 0) $available_quantity = 0;

            error_log("[DEBUG] Equipment: $name | Total: $total_quantity | Borrowed: $borrowed_count | Maintenance: $maintenance_count | Available: $available_quantity");

            $baseStatus = determineBaseStatus($total_quantity, $borrowed_count, $maintenance_count, $available_quantity);
            
            error_log("[DEBUG] Determined baseStatus: $baseStatus");

            $isCritical = isCriticalLevel($total_quantity, $available_quantity);

            $status_fetch_sql = "SELECT status FROM equipment WHERE equipment_id = ?";
            $status_fetch_stmt = $conn->prepare($status_fetch_sql);
            $status_fetch_stmt->bind_param("i", $id);
            $status_fetch_stmt->execute();
            $current_status = $status_fetch_stmt->get_result()->fetch_assoc()['status'];
            $status_fetch_stmt->close();

            $new_status = $isCritical ? $baseStatus . '_critical' : $baseStatus;

            if ($isCritical) {
                $criticalReason = generateCriticalReason($baseStatus, $available_quantity, $total_quantity, $borrowed_count, $maintenance_count);

                $equipmentDetails = [
                    'id' => $id,
                    'name' => $name,
                    'quantity' => $total_quantity,
                    'available_quantity' => $available_quantity,
                    'status' => $new_status,
                    'critical_reason' => $criticalReason
                ];
                
                error_log("[{$name}] Critical: Available={$available_quantity}, Total={$total_quantity}, Status={$new_status}, Reason={$criticalReason}");
                $criticalEquipment[] = $equipmentDetails;
            }

            if ($current_status !== $new_status) {
                $status_sql = "UPDATE equipment SET status = ? WHERE equipment_id = ?";
                $status_stmt = $conn->prepare($status_sql);
                $status_stmt->bind_param("si", $new_status, $id);
                if ($status_stmt->execute()) {
                    error_log("Updated equipment {$name} (ID: {$id}) status from '{$current_status}' to '{$new_status}'");
                } else {
                    error_log("Failed to update equipment {$name} (ID: {$id}) status: " . $status_stmt->error);
                }
            } else {
                error_log("Equipment {$name} (ID: {$id}) status '{$current_status}' unchanged - already correct");
            }
        }
    }
    
    $notificationSent = false;
    
    if (!empty($criticalEquipment)) {
        sendCriticalQuantityNotification($criticalEquipment, [], $conn);
        $notificationSent = true;
    }
    
    if ($notificationSent) {
        file_put_contents($lastNotificationFile, time());
    }
    
    if (file_exists($notificationLockFile)) {
        unlink($notificationLockFile);
    }
    
    return $criticalEquipment;
}

// email notification function 
function sendCriticalQuantityNotification($criticalEquipment, $maintenanceEquipment, $conn) {
    $emailHeader = "
        <div style='font-family: Arial, sans-serif; max-width: 600px; margin: auto;'>
            <div style='background: #c0392b; color: #fff; padding: 16px 24px; border-radius: 8px 8px 0 0; text-align: center;'>
                <strong>THIS IS AN AUTOMATICALLY GENERATED REPORT | DO NOT REPLY</strong>
            </div>
            <div style='background: #fff; border: 1px solid #eee; border-top: none; padding: 24px; border-radius: 0 0 8px 8px;'>";

    $emailBody = $emailHeader;
    $emailBodyAlt = "THIS IS AN AUTOMATICALLY GENERATED REPORT | DO NOT REPLY\n\n";

    if (!empty($criticalEquipment)) {
        $emailBody .= "
                <h2 style='color: #c0392b; margin-top: 0;'>Equipment Inventory Alert - Critical Status</h2>
                <p>The following equipment requires immediate attention:</p>
                <table style='width: 100%; border-collapse: collapse; margin-top: 16px;'>
                    <thead>
                        <tr style='background: #f8d7da; color: #721c24;'>
                            <th style='padding: 8px; border: 1px solid #f5c6cb;'>Name</th>
                            <th style='padding: 8px; border: 1px solid #f5c6cb;'>Total Quantity</th>
                            <th style='padding: 8px; border: 1px solid #f5c6cb;'>Available</th>
                            <th style='padding: 8px; border: 1px solid #f5c6cb;'>Critical Reason</th>
                        </tr>
                    </thead>
                    <tbody>";

        $emailBodyAlt .= "\nEQUIPMENT WITH CRITICAL STATUS:\n";
        foreach ($criticalEquipment as $equipment) {
            $emailBody .= "<tr>"
                . "<td style='padding: 8px; border: 1px solid #f5c6cb;'>" . htmlspecialchars($equipment['name']) . "</td>"
                . "<td style='padding: 8px; border: 1px solid #f5c6cb; text-align: right;'>" . htmlspecialchars($equipment['quantity']) . "</td>"
                . "<td style='padding: 8px; border: 1px solid #f5c6cb; text-align: right;'>" . htmlspecialchars($equipment['available_quantity']) . "</td>"
                . "<td style='padding: 8px; border: 1px solid #f5c6cb;'>" . htmlspecialchars($equipment['critical_reason']) . "</td>"
                . "</tr>\n";

            $emailBodyAlt .=
                "Name: " . $equipment['name'] .
                " | Total Quantity: " . $equipment['quantity'] .
                " | Available: " . $equipment['available_quantity'] .
                " | Critical Reason: " . $equipment['critical_reason'] . "\n";
        }
        $emailBody .= "</tbody></table>";
    }

    $emailBody .= "</div></div>";

    $adminQuery = "SELECT email, CONCAT(first_name, ' ', last_name) as full_name FROM users WHERE role = 'admin' AND status = 'active'";
    $adminResult = $conn->query($adminQuery);
    
    if (!$adminResult) {
        error_log("ERROR: Admin query failed - " . $conn->error);
        return;
    }
    
    $adminCount = $adminResult->num_rows;
    error_log("Found {$adminCount} admin users to notify");
    while ($admin = $adminResult->fetch_assoc()) {
        error_log("===== EMAIL NOTIFICATION ATTEMPT =====");
        error_log("Recipient: " . $admin['email']);
        error_log("Name: " . $admin['full_name']);
        error_log("Critical Equipment Count: " . count($criticalEquipment));
        error_log("Maintenance Equipment Count: " . count($maintenanceEquipment));
        
        try {
            $result = sendEmail($admin['email'], $admin['full_name'], 
                            "Equipment Inventory Alert - Critical Levels", 
                            $emailBody, $emailBodyAlt);
            
            if ($result) {
                error_log("Email successfully sent to admin: " . $admin['email']);
            } else {
                error_log("Failed to send email to admin: " . $admin['email'] . " - Check SMTP settings and connection");
            }
        } catch (Exception $e) {
            error_log("Critical error sending email: " . $e->getMessage());
            error_log("Stack trace: " . $e->getTraceAsString());
        }
        error_log("===================================");
    }
    
    error_log("=== Critical Equipment Notification Complete ===\n");
}
?>