<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);

require_once __DIR__ . '/../db_connection.php'; 
require_once __DIR__ . '/notifications.php';
require_once __DIR__ . '/../classes/Equipment/Equipment.php';

function checkEquipmentQuantityLevels($conn) {
    if (!$conn) {
        error_log("Database connection is null in checkEquipmentQuantityLevels");
        return [];
    }  
    $lastNotificationFile = __DIR__ . '/../logs/equipment_notification_timestamp.txt';
    $notificationLockFile = __DIR__ . '/../logs/notification.lock';
    
    // use a lock file to prevent concurrent notifications, if lock is older than 30secs it will consider it new
    if (file_exists($notificationLockFile)) {
        $lockTime = (int)file_get_contents($notificationLockFile);

        if (time() - $lockTime < 30) {
            return [];
        }
    }
    
    file_put_contents($notificationLockFile, time());
    
    // this checks last notification time
    if (file_exists($lastNotificationFile)) {
        $lastNotification = (int)file_get_contents($lastNotificationFile);
        if (time() - $lastNotification < 300) { 
            unlink($notificationLockFile); 
            return [];
        }
    }

    $sql = "SELECT equipment_id FROM equipment";
    $result = $conn->query($sql);
    $criticalEquipment = [];
    
    if ($result->num_rows > 0) {
        while ($row = $result->fetch_assoc()) {
            $equipment = new Equipment($conn);
            $equipment->load($row['equipment_id']);
            
            $id = $equipment->getId();
            $name = $equipment->getName();
            $quant = $equipment->getQuantity();
            $avbl_quant = $equipment->getAvailableQuantity();
            $status = $equipment->getStatus();            // Check if equipment is at critical level (50% or less available)
            $isCritical = $quant === 1 ? $avbl_quant === 0 : $avbl_quant <= ($quant / 2);

            // If critical, add to the list
            if ($isCritical) {
                $criticalReason = ["Low Quantity"];

                $equipmentDetails = [
                    'id' => $id,
                    'name' => $name,
                    'quantity' => $quant,
                    'available_quantity' => $avbl_quant,
                    'status' => $status,
                    'critical_reason' => implode(", ", $criticalReason)
                ];
                
                error_log("[{$name}] Critical: Available={$avbl_quant}, Total={$quant}, Status={$status}, Reason=" . implode(", ", $criticalReason));
                $criticalEquipment[] = $equipmentDetails;
                  // Update equipment status
                if ($isCritical) {
                    $status_sql = "UPDATE equipment SET status = ? WHERE equipment_id = ?";
                    $new_status = ($avbl_quant === 0) ? 'critical' : 'critical_available';
                    $status_stmt = $conn->prepare($status_sql);
                    $status_stmt->bind_param("si", $new_status, $id);
                    $status_stmt->execute();
                }
            }
        }
    }
    
    $notificationSent = false;
    
    if (!empty($criticalEquipment)) {
        sendCriticalQuantityNotification($criticalEquipment, [], $conn);
        $notificationSent = true;
    }
    
    if ($notificationSent) {
        $lastNotificationFile = __DIR__ . '/../logs/equipment_notification_timestamp.txt';
        file_put_contents($lastNotificationFile, time());
    }
    
    if (file_exists($notificationLockFile)) {
        unlink($notificationLockFile);
    }
    
    return $criticalEquipment;
}

//email for the threshold for the equipments with critical numbers
function sendCriticalQuantityNotification($criticalEquipment, $maintenanceEquipment, $conn) {
    $emailHeader = "
        <div style='font-family: Arial, sans-serif; max-width: 600px; margin: auto;'>
            <div style='background: #c0392b; color: #fff; padding: 16px 24px; border-radius: 8px 8px 0 0; text-align: center;'>
                <strong>THIS IS AN AUTOMATICALLY GENERATED REPORT | DO NOT REPLY</strong>
            </div>
            <div style='background: #fff; border: 1px solid #eee; border-top: none; padding: 24px; border-radius: 0 0 8px 8px;'>";

    $emailBody = $emailHeader;
    $emailBodyAlt = "THIS IS AN AUTOMATICALLY GENERATED REPORT | DO NOT REPLY\n\n";

    if (!empty($criticalEquipment)) {
        $emailBody .= "
                <h2 style='color: #c0392b; margin-top: 0;'>Equipment Inventory Alert - Critical Status</h2>
                <p>The following equipment requires immediate attention:</p>
                <table style='width: 100%; border-collapse: collapse; margin-top: 16px;'>
                    <thead>
                        <tr style='background: #f8d7da; color: #721c24;'>
                            <th style='padding: 8px; border: 1px solid #f5c6cb;'>Name</th>
                            <th style='padding: 8px; border: 1px solid #f5c6cb;'>Total Quantity</th>
                            <th style='padding: 8px; border: 1px solid #f5c6cb;'>Available</th>
                            <th style='padding: 8px; border: 1px solid #f5c6cb;'>Critical Reason</th>
                        </tr>
                    </thead>
                    <tbody>";

        $emailBodyAlt .= "\nEQUIPMENT WITH CRITICAL STATUS:\n";
        foreach ($criticalEquipment as $equipment) {
            $emailBody .= "<tr>"
                . "<td style='padding: 8px; border: 1px solid #f5c6cb;'>" . htmlspecialchars($equipment['name']) . "</td>"
                . "<td style='padding: 8px; border: 1px solid #f5c6cb; text-align: right;'>" . htmlspecialchars($equipment['quantity']) . "</td>"
                . "<td style='padding: 8px; border: 1px solid #f5c6cb; text-align: right;'>" . htmlspecialchars($equipment['available_quantity']) . "</td>"
                . "<td style='padding: 8px; border: 1px solid #f5c6cb;'>" . htmlspecialchars($equipment['critical_reason']) . "</td>"
                . "</tr>\n";

            $emailBodyAlt .=
                "Name: " . $equipment['name'] .
                " | Total Quantity: " . $equipment['quantity'] .
                " | Available: " . $equipment['available_quantity'] .
                " | Critical Reason: " . $equipment['critical_reason'] . "\n";
        }
        $emailBody .= "</tbody></table>";
    }

    $emailBody .= "</div></div>";

    $adminQuery = "SELECT email, CONCAT(first_name, ' ', last_name) as full_name FROM users WHERE role = 'admin' AND status = 'active'";
    $adminResult = $conn->query($adminQuery);
    
    if (!$adminResult) {
        error_log("ERROR: Admin query failed - " . $conn->error);
        return;
    }
    
    $adminCount = $adminResult->num_rows;
    error_log("Found {$adminCount} admin users to notify");
    while ($admin = $adminResult->fetch_assoc()) {
        error_log("===== EMAIL NOTIFICATION ATTEMPT =====");
        error_log("Recipient: " . $admin['email']);
        error_log("Name: " . $admin['full_name']);
        error_log("Critical Equipment Count: " . count($criticalEquipment));
        error_log("Maintenance Equipment Count: " . count($maintenanceEquipment));
        
        try {
            $result = sendEmail($admin['email'], $admin['full_name'], 
                            "Equipment Inventory Alert - Critical Levels", 
                            $emailBody, $emailBodyAlt);
            
            if ($result) {
                error_log("Email successfully sent to admin: " . $admin['email']);
            } else {
                error_log("Failed to send email to admin: " . $admin['email'] . " - Check SMTP settings and connection");
            }
        } catch (Exception $e) {
            error_log("Critical error sending email: " . $e->getMessage());
            error_log("Stack trace: " . $e->getTraceAsString());
        }
        error_log("===================================");
    }
    
    error_log("=== Critical Equipment Notification Complete ===\n");
}
?>