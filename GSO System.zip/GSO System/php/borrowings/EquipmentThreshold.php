<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);

require_once __DIR__ . '/../db_connection.php'; 
require_once __DIR__ . '/notifications.php';
require_once __DIR__ . '/../classes/Equipment/Equipment.php';

function checkEquipmentQuantityLevels($conn) {
    if (!$conn) {
        error_log("Database connection is null in checkEquipmentQuantityLevels");
        return [];
    }  
    $lastNotificationFile = __DIR__ . '/../logs/equipment_notification_timestamp.txt';
    $notificationLockFile = __DIR__ . '/../logs/notification.lock';
    
    // use a lock file to prevent concurrent notifications, if lock is older than 30secs it will consider it new
    if (file_exists($notificationLockFile)) {
        $lockTime = (int)file_get_contents($notificationLockFile);

        if (time() - $lockTime < 30) {
            return [];
        }
    }
    
    file_put_contents($notificationLockFile, time());
    
    // this checks last notification time
    if (file_exists($lastNotificationFile)) {
        $lastNotification = (int)file_get_contents($lastNotificationFile);
        if (time() - $lastNotification < 300) { 
            unlink($notificationLockFile); 
            return [];
        }
    }

    $sql = "SELECT equipment_id FROM equipment";
    $result = $conn->query($sql);
    
    $criticalEquipment = [];
    
    if ($result->num_rows > 0) {
        while ($row = $result->fetch_assoc()) {
            $equipment = new Equipment($conn);
            $equipment->load($row['equipment_id']);
            
            $id = $equipment->getId();
            $name = $equipment->getName();
            $quant = $equipment->getQuantity();            $avbl_quant = $equipment->getAvailableQuantity();            
            $isCritical = $quant === 1 ? $avbl_quant === 0 : $avbl_quant < ($quant / 2);
            
            if ($isCritical) {
                error_log("[{$name}] Critical: Available={$avbl_quant}, Total={$quant}");
                $criticalEquipment[] = [
                    'id' => $id,
                    'name' => $name,
                    'quantity' => $quant,
                    'available_quantity' => $avbl_quant
                ];
                
                $status_sql = "UPDATE equipment SET status = ? WHERE equipment_id = ?";
                $status = ($avbl_quant === 0) ? 'critical' : 'critical_available';
                $status_stmt = $conn->prepare($status_sql);
                $status_stmt->bind_param("si", $status, $id);
                $status_stmt->execute();
            }
        }
    }
    
    if (!empty($criticalEquipment)) {
        sendCriticalQuantityNotification($criticalEquipment, $conn);

        $lastNotificationFile = __DIR__ . '/../logs/equipment_notification_timestamp.txt';
        file_put_contents($lastNotificationFile, time());
    }
    
    if (file_exists($notificationLockFile)) {
        unlink($notificationLockFile);
    }
    
    return $criticalEquipment;
}

//email for the threshold for the equipments with critical numbers
function sendCriticalQuantityNotification($criticalEquipment, $conn) {
    $emailHeader = "
        <div style='font-family: Arial, sans-serif; max-width: 600px; margin: auto;'>
            <div style='background: #c0392b; color: #fff; padding: 16px 24px; border-radius: 8px 8px 0 0; text-align: center;'>
                <strong>THIS IS AN AUTOMATICALLY GENERATED REPORT | DO NOT REPLY</strong>
            </div>
            <div style='background: #fff; border: 1px solid #eee; border-top: none; padding: 24px; border-radius: 0 0 8px 8px;'>
                <h2 style='color: #c0392b; margin-top: 0;'>Equipment Inventory Alert - Critical Levels</h2>
                <p>List of equipment with <b>critical</b> available quantity:</p>
                <table style='width: 100%; border-collapse: collapse; margin-top: 16px;'>
                    <thead>
                        <tr style='background: #f8d7da; color: #721c24;'>
                            <th style='padding: 8px; border: 1px solid #f5c6cb;'>Name</th>
                            <th style='padding: 8px; border: 1px solid #f5c6cb;'>Total Quantity</th>
                            <th style='padding: 8px; border: 1px solid #f5c6cb;'>Available</th>
                            <th style='padding: 8px; border: 1px solid #f5c6cb;'>Status</th>
                        </tr>
                    </thead>
                    <tbody>";

    $emailHeaderAlt =
        "THIS IS AN AUTOMATICALLY GENERATED REPORT | DO NOT REPLY\n" .
        "List of equipment with critical level of available quantity:\n\n";

    $emailBody = $emailHeader;
    $emailBodyAlt = $emailHeaderAlt;
    foreach ($criticalEquipment as $equipment) {
        $emailBody .= "<tr>"
            . "<td style='padding: 8px; border: 1px solid #f5c6cb;'>" . htmlspecialchars($equipment['name']) . "</td>"
            . "<td style='padding: 8px; border: 1px solid #f5c6cb; text-align: right;'>" . htmlspecialchars($equipment['quantity']) . "</td>"
            . "<td style='padding: 8px; border: 1px solid #f5c6cb; text-align: right;'>" . htmlspecialchars($equipment['available_quantity']) . "</td>"
            . "<td style='padding: 8px; border: 1px solid #f5c6cb; color: #c0392b; font-weight: bold;'>Critical</td>"
            . "</tr>\n";

        $emailBodyAlt .=
            "Name: " . $equipment['name'] .
            " | Quantity: " . $equipment['quantity'] .
            " | Available Quantity: " . $equipment['available_quantity'] .
            " | Quantity Level = Critical\n";
    }
    $emailBody .= "</tbody></table></div></div>";

    $adminQuery = "SELECT email, CONCAT(first_name, ' ', last_name) as full_name FROM users WHERE role = 'admin' AND status = 'active'";
    $adminResult = $conn->query($adminQuery);
    
    if (!$adminResult) {
        error_log("ERROR: Admin query failed - " . $conn->error);
        return;
    }
    
    $adminCount = $adminResult->num_rows;
    error_log("Found {$adminCount} admin users to notify");
    
    while ($admin = $adminResult->fetch_assoc()) {
        error_log("Attempting to send email to: " . $admin['email']);
        try {
            $result = sendEmail($admin['email'], $admin['full_name'], 
                              "Equipment Inventory Alert - Critical Levels", 
                              $emailBody, $emailBodyAlt);
            error_log("Email send result: " . ($result ? "SUCCESS" : "FAILED"));
        } catch (Exception $e) {
            error_log("Email send error: " . $e->getMessage());
        }
    }    error_log("=== Critical Equipment Notification Complete ===\n");
}
?>