<?php
require_once '../db_connection.php';
require_once '../classes/borrowing/Borrowing.php';


function updateOverdueStatus($conn) {
    $activeBorrowings = Borrowing::getAllBorrowings($conn, [
        'status' => 'active',
        'approval_status' => 'approved'
    ]);
    
    $updatedCount = 0;
    $errors = [];
    
    foreach ($activeBorrowings as $borrowingData) {
        $borrowing = new Borrowing($conn);
        $borrowing->load($borrowingData['borrowing_id']);
        
        if ($borrowing->isOverdue()) {
        
            $sql = "UPDATE borrowings SET status = 'overdue', updated_at = NOW() WHERE borrowing_id = ?";
            $stmt = $conn->prepare($sql);
            
            if ($stmt) {
                $borrowing_id = $borrowing->getId();
                $stmt->bind_param("i", $borrowing_id);
                
                if ($stmt->execute()) {
                    $updatedCount++;
                } else {
                    $errors[] = "Error updating borrowing ID {$borrowing_id}: {$stmt->error}";
                }
            } else {
                $errors[] = "Error preparing statement: {$conn->error}";
            }
        }
    }
    
    if (empty($errors)) {
        return [
            'success' => true, 
            'message' => 'Overdue status updated successfully.',
            'count' => $updatedCount
        ];
    } else {
        return [
            'success' => false, 
            'message' => 'Errors occurred while updating overdue status: ' . implode('; ', $errors),
            'count' => $updatedCount
        ];
    }
}

if (basename($_SERVER['PHP_SELF']) == basename(__FILE__)) {
    session_start();
    $result = updateOverdueStatus($conn);
    
    if ($result['success']) {
        $_SESSION['success'] = $result['message'] . ' ' . $result['count'] . ' records updated.';
    } else {
        $_SESSION['error'] = $result['message'];
    }

    header("Location: borrowings.php");
    exit();
}
?>