<?php
session_start();
require_once '../db_connection.php';
require_once '../helpers.php';
require_once __DIR__ . '/../classes/Borrowing/BorrowingSentiment.php';

if (!isLoggedIn() || !isAdmin()) {
    header("Location: ../login.php");
    exit();
}

$sentimentAnalyzer = new BorrowingSentiment($conn);

$filter = isset($_GET['filter']) ? $_GET['filter'] : '';
$condition = isset($_GET['condition']) ? $_GET['condition'] : '';
$dateRange = isset($_GET['date_range']) ? $_GET['date_range'] : '';

$sentiment_summary = $sentimentAnalyzer->getSentimentSummary($dateRange);

$sentiments = $sentimentAnalyzer->getReturnNotesSentiment(null, $dateRange, $condition, $filter);

$monthly_trends = $sentimentAnalyzer->getMonthlySentimentTrends(12);

$monthly_labels = [];
$monthly_positive = [];
$monthly_neutral = [];
$monthly_negative = [];
$monthly_polarity = [];

if (isset($monthly_trends['success']) && $monthly_trends['success']) {
    foreach ($monthly_trends['monthly_data'] as $month => $data) {
        $date = new DateTime($month . '-01');
        $formatted_month = $date->format('M Y');
        
        $monthly_labels[] = $formatted_month;
        $monthly_positive[] = $data['positive'];
        $monthly_neutral[] = $data['neutral'];
        $monthly_negative[] = $data['negative'];
        $monthly_polarity[] = $data['avg_polarity'];
    }
}

$condition_labels = [];
$condition_positive = [];
$condition_neutral = [];
$condition_negative = [];

if (isset($sentiment_summary['condition_sentiment'])) {
    $condition_sentiment = $sentiment_summary['condition_sentiment'];
    $condition_labels = array_keys($condition_sentiment);
    
    foreach ($condition_sentiment as $condition => $values) {
        $condition_positive[] = isset($values['Positive']) ? $values['Positive'] : 0;
        $condition_neutral[] = isset($values['Neutral']) ? $values['Neutral'] : 0;
        $condition_negative[] = isset($values['Negative']) ? $values['Negative'] : 0;
    }
}

include '../../pages/borrowings/sentiment_analysis.html';
?>