<?php
    use PHPMailer\PHPMailer\PHPMailer;
    use PHPMailer\PHPMailer\Exception;
    use PHPMailer\PHPMailer\SMTP;

    require 'PHPMailer-master/src/Exception.php';
    require 'PHPMailer-master/src/PHPMailer.php';
    require 'PHPMailer-master/src/SMTP.php';

    function sendEmail($recipientMail, $recipientName, $subject, $body, $altbody) {
        $mail = new PHPMailer(true);
        $sendingEmail = "macuana_arnolddominic@plpasig.edu.ph";
        $smtpPass = "yfdn qeqp untd xoym";

        try {            // Set to 2 for debugging, 0 for production
            $mail->SMTPDebug = 0;
            
            // SMTP configuration
            $mail->isSMTP();
            $mail->Host       = 'smtp.gmail.com';
            $mail->SMTPAuth   = true;
            $mail->Username   = $sendingEmail;
            $mail->Password   = $smtpPass;
            $mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS;
            $mail->Port       = 587;
            
            // Additional recommended settings
            $mail->Timeout = 60; // Timeout in seconds
            $mail->CharSet = 'UTF-8';
            $mail->SMTPOptions = array(
                'ssl' => array(
                    'verify_peer' => false,
                    'verify_peer_name' => false,
                    'allow_self_signed' => true
                )
            );

            
            $mail->setFrom($sendingEmail, 'General Service Office');
            $mail->addAddress($recipientMail, $recipientName);

              $mail->isHTML(true);
            $mail->Subject = $subject;
            $mail->Body    = $body;
            $mail->AltBody = $altbody;
            
            if ($mail->send()) {
                error_log("Email sent successfully to: " . $recipientMail);
                return true;
            } else {
                error_log("Failed to send email to " . $recipientMail . ". Error: " . $mail->ErrorInfo);
                return false;
            }
        } catch (Exception $e) {
            error_log("Failed to send email to " . $recipientMail . ". Error: " . $e->getMessage());
            return false;
        }
    }   
    
    function logNotification($header, $body) {
        $timestamp = date('Y-m-d H:i:s');
        error_log("[$timestamp] NOTIFICATION - $header: $body");
    }

    function pushNotif($message, $type = 'info', $userId = null) {
        try {
            // Log the notification
            logNotification($type, $message);
            
            // If user ID is provided, get their email
            if ($userId) {
                global $conn;
                $sql = "SELECT email, CONCAT(first_name, ' ', last_name) as full_name FROM users WHERE user_id = ?";
                $stmt = $conn->prepare($sql);
                $stmt->bind_param("i", $userId);
                $stmt->execute();
                $result = $stmt->get_result();
                
                if ($user = $result->fetch_assoc()) {
                    $subject = "GSO Equipment Management System - " . ucfirst($type) . " Notification";
                    $body = "<div style='font-family: Arial, sans-serif;'><p>$message</p></div>";
                    $altBody = strip_tags($message);
                    
                    return sendEmail($user['email'], $user['full_name'], $subject, $body, $altBody);
                }
            }
            
            return true;
        } catch (Exception $e) {
            error_log("Error sending notification: " . $e->getMessage());
            return false;
        }
    }
?>