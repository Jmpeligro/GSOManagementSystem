<?php
session_start();

require_once '../db_connection.php';
require_once '../classes/borrowing/Borrowing.php';
require_once '../classes/User/User.php';
require_once '../classes/Equipment/Equipment.php';
require_once 'notifications.php';

// Ensure the user is an admin before proceeding.
if (!isset($_SESSION['user_id']) || !isset($_SESSION['role']) || $_SESSION['role'] !== 'admin') {
    $_SESSION['error'] = "You don't have permission to perform this action.";
    header("Location: borrowings.php");
    exit();
}

// Validate required parameters.
if (!isset($_GET['id']) || !isset($_GET['user_id'])) {
    $_SESSION['error'] = "Missing required parameters.";
    header("Location: borrowings.php");
    exit();
}

// Extract equipment and user IDs from the request.
$equipment_id = (int)$_GET['id'];
$user_id = (int)$_GET['user_id'];

// Fetch overdue borrowings for the specified equipment and user.
$overdueBorrowings = Borrowing::getAllBorrowings($conn, [
    'equipment_id' => $equipment_id,
    'user_id' => $user_id,
    'status' => 'overdue',
    'approval_status' => 'approved'
]);

// If no overdue borrowings are found, check for active borrowings.
if (empty($overdueBorrowings)) {
    $activeBorrowings = Borrowing::getAllBorrowings($conn, [
        'equipment_id' => $equipment_id,
        'user_id' => $user_id,
        'status' => 'active',
        'approval_status' => 'approved'
    ]);
    
    // If no active borrowings are found, return an error.
    if (empty($activeBorrowings)) {
        $_SESSION['error'] = "No active or overdue borrowing found for this equipment and user.";
        header("Location: borrowings.php");
        exit();
    }
    
    $borrowing_data = $activeBorrowings[0];
    $borrowing = new Borrowing($conn);
    $borrowing->load($borrowing_data['borrowing_id']);

    // If the borrowing is not overdue, update its status to overdue.
    if (!$borrowing->isOverdue()) {
        $_SESSION['error'] = "This borrowing is not yet overdue.";
        header("Location: borrowings.php");
        exit();
    }
    // Assign the borrowing ID to a variable before passing it to bind_param.
    $borrowingId = $borrowing->getId();
    $sql = "UPDATE borrowings SET status = 'overdue', updated_at = NOW() WHERE borrowing_id = ?";
    $update_stmt = $conn->prepare($sql);
    $update_stmt->bind_param("i", $borrowingId);
    $update_stmt->execute();
} else {
    $borrowing_data = $overdueBorrowings[0];
    $borrowing = new Borrowing($conn);
    $borrowing->load($borrowing_data['borrowing_id']);
}

// Load user details for sending the reminder.
$user = new User($conn);
$user->load($user_id);
$email = $user->getEmail();
$name = $user->getFullName();    

// Load equipment details for the reminder email.
$equipment = new Equipment($conn);
$equipment->load($equipment_id);
$equipmentName = $equipment->getName();

// Calculate the number of days overdue.
$due_date = new DateTime($borrowing->getDueDate());
$now = new DateTime();
$days_overdue = $now->diff($due_date)->days;

// Prepare the email content for the overdue reminder.
$emailBody = "
    <div style='font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto; padding: 20px; border: 1px solid #ddd; border-radius: 5px;'>
        <div style='background-color: #f8f9fa; padding: 15px; text-align: center; border-radius: 5px 5px 0 0;'>
            <h2 style='color: #dc3545; margin: 0;'>AUTOMATED EMAIL NOTIFICATION | DO NOT REPLY</h2>
        </div>
        <div style='padding: 20px; background-color: white;'>
            <p style='color: #dc3545; font-size: 18px; font-weight: bold;'>The equipment you borrowed is <span style='color: #000;'>{$days_overdue} day(s)</span> past its due date.</p>
            <p style='color: #666; margin: 15px 0;'>Please return it at your soonest convenience to avoid any penalties.</p>
            <div style='background-color: #f8f9fa; padding: 15px; margin: 20px 0; border-radius: 5px;'>
                <p style='margin: 5px 0;'><strong style='color: #333;'>Equipment:</strong> <span style='color: #666;'>{$equipmentName}</span></p>
                <p style='margin: 5px 0;'><strong style='color: #333;'>Due Date:</strong> <span style='color: #666;'>{$borrowing->getDueDate()}</span></p>
            </div>
            <p style='color: #666; font-style: italic; margin-top: 20px;'>If you have already returned this equipment, please disregard this message.</p>
        </div>
        <div style='background-color: #f8f9fa; padding: 15px; text-align: center; font-size: 12px; color: #666; border-radius: 0 0 5px 5px;'>
            This is an automated message from the GSO Equipment Management System
        </div>
    </div>
    ";

$emailBodyAlt = "
        THIS IS AN AUTOMATICALLY GENERATED EMAIL | DO NOT REPLY
        
        The equipment you borrowed is {$days_overdue} day(s) past its due date.
        Please return it at your soonest convenience to avoid any penalties.
        
        Equipment: {$equipmentName}
        Due Date: {$borrowing->getDueDate()}
        
        If you have already returned this equipment, please disregard this message.
    ";

// Update admin notes for the borrowing record.
$current_notes = $borrowing->getAdminNotes();
$new_notes = ($current_notes ? $current_notes . "\n" : "") . "Overdue reminder sent on " . date('Y-m-d H:i:s');

// Assign the borrowing ID and new notes to variables before passing them to bind_param.
$note_sql = "UPDATE borrowings SET admin_notes = ? WHERE borrowing_id = ?";
$note_stmt = $conn->prepare($note_sql);
$note_stmt->bind_param("si", $new_notes, $borrowingId);
$note_stmt->execute();

// Send the reminder email and log the action.
pushNotif("Email Sent", "An Email has been sent to remind " . $name . " of their overdue equipment at " . $email);
sendEmail($email, $name, "OVERDUE: Equipment Return Reminder", $emailBody, $emailBodyAlt);

// Set a success message and redirect back to the borrowings page.
$_SESSION['success'] = "Reminder email sent successfully to " . $name . ".";

header("Location: borrowings.php");
exit();
?>