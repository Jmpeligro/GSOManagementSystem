<?php
session_start();
require_once '../db_connection.php';
require_once '../classes/borrowing/Borrowing.php';
require_once '../classes/User/User.php';
require_once '../classes/Equipment/Equipment.php';
require_once 'notifications.php';

if (!isset($_SESSION['user_id']) || !isset($_SESSION['role']) || $_SESSION['role'] !== 'admin') {
    $_SESSION['error'] = "You don't have permission to perform this action.";
    header("Location: borrowings.php");
    exit();
}

if (!isset($_GET['id']) || !isset($_GET['user_id'])) {
    $_SESSION['error'] = "Missing required parameters.";
    header("Location: borrowings.php");
    exit();
}

$equipment_id = (int)$_GET['id'];
$user_id = (int)$_GET['user_id'];

$overdueBorrowings = Borrowing::getAllBorrowings($conn, [
    'equipment_id' => $equipment_id,
    'user_id' => $user_id,
    'status' => 'overdue',
    'approval_status' => 'approved'
]);

if (empty($overdueBorrowings)) {
    $activeBorrowings = Borrowing::getAllBorrowings($conn, [
        'equipment_id' => $equipment_id,
        'user_id' => $user_id,
        'status' => 'active',
        'approval_status' => 'approved'
    ]);
    
    if (empty($activeBorrowings)) {
        $_SESSION['error'] = "No active or overdue borrowing found for this equipment and user.";
        header("Location: borrowings.php");
        exit();
    }
    
    $borrowing_data = $activeBorrowings[0];
    
    $borrowing = new Borrowing($conn);
    $borrowing->load($borrowing_data['borrowing_id']);

    if (!$borrowing->isOverdue()) {
        $_SESSION['error'] = "This borrowing is not yet overdue.";
        header("Location: borrowings.php");
        exit();
    }
    
    $sql = "UPDATE borrowings SET status = 'overdue', updated_at = NOW() WHERE borrowing_id = ?";
    $update_stmt = $conn->prepare($sql);
    $update_stmt->bind_param("i", $borrowing->getId());
    $update_stmt->execute();
} else {
    $borrowing_data = $overdueBorrowings[0];
    $borrowing = new Borrowing($conn);
    $borrowing->load($borrowing_data['borrowing_id']);
}

$user = new User($conn);
$user->load($user_id);
$email = $user->getEmail();
$name = $user->getFullName();    

$equipment = new Equipment($conn);
$equipment->load($equipment_id);
$equipmentName = $equipment->getName();

$due_date = new DateTime($borrowing->getDueDate());
$now = new DateTime();
$days_overdue = $now->diff($due_date)->days;

$emailBody = "
        <B><U>THIS IS AN AUTOMATICALLY GENERATED EMAIL | DO NOT REPLY</U></B> <BR>
        <hr>
        <p>The equipment you borrowed is <strong>{$days_overdue} day(s)</strong> past its due date.</p>
        <p>Please return it at your soonest convenience to avoid any penalties.</p>
        <p><strong>Equipment:</strong> {$equipmentName}</p>
        <p><strong>Due Date:</strong> {$borrowing->getDueDate()}</p>
        <p>If you have already returned this equipment, please disregard this message.</p>
    ";

$emailBodyAlt = "
        THIS IS AN AUTOMATICALLY GENERATED EMAIL | DO NOT REPLY
        
        The equipment you borrowed is {$days_overdue} day(s) past its due date.
        Please return it at your soonest convenience to avoid any penalties.
        
        Equipment: {$equipmentName}
        Due Date: {$borrowing->getDueDate()}
        
        If you have already returned this equipment, please disregard this message.
    ";

$current_notes = $borrowing->getAdminNotes();
$new_notes = ($current_notes ? $current_notes . "\n" : "") . "Overdue reminder sent on " . date('Y-m-d H:i:s');

$note_sql = "UPDATE borrowings SET admin_notes = ? WHERE borrowing_id = ?";
$note_stmt = $conn->prepare($note_sql);
$note_stmt->bind_param("si", $new_notes, $borrowing->getId());
$note_stmt->execute();

pushNotif("Email Sent", "An Email has been sent to remind " . $name . " of their overdue equipment at " . $email);
sendEmail($email, $name, "OVERDUE: Equipment Return Reminder", $emailBody, $emailBodyAlt);

$_SESSION['success'] = "Reminder email sent successfully to " . $name . ".";

header("Location: borrowings.php");
exit();
?>