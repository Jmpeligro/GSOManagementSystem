<?php
// File: classes/Category.php
require_once 'CategoryActions.php';

class Category extends CategoryActions {
    // This class now inherits everything from the specialized classes
    // You can add more specific methods here if needed
}
?>