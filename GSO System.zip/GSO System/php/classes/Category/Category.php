<?php
require_once 'CategoryActions.php';

class Category extends CategoryActions {

}
?>