<?php

class CategoryBase {
    protected $conn;
    protected $category_id;
    protected $name;
    protected $description;
    protected $created_at;
    
    public function __construct($conn) {
        $this->conn = $conn;
    }
    
    public function setData($data) {
        $this->category_id = $data['category_id'] ?? null;
        $this->name = $data['name'] ?? null;
        $this->description = $data['description'] ?? null;
        $this->created_at = $data['created_at'] ?? null;
    }
    
    // Getter methods
    public function getId() {
        return $this->category_id;
    }
    
    public function getName() {
        return $this->name;
    }
    
    public function getDescription() {
        return $this->description;
    }
    
    public function getCreatedAt() {
        return $this->created_at;
    }
}
?>