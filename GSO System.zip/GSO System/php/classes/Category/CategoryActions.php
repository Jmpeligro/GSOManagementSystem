<?php
require_once 'CategoryData.php';

class CategoryActions extends CategoryData {
    public function create($name, $description = '') {
        if (empty($name)) {
            return ['success' => false, 'message' => 'Category name is required.'];
        }

        if ($this->nameExists($name)) {
            return ['success' => false, 'message' => 'A category with this name already exists.'];
        }
        
        $sql = "INSERT INTO categories (name, description, created_at) VALUES (?, ?, NOW())";
        $stmt = $this->conn->prepare($sql);
        if ($stmt === false) {
            return ['success' => false, 'message' => 'Error preparing statement: ' . $this->conn->error];
        }
        $stmt->bind_param("ss", $name, $description);
        
        if ($stmt->execute()) {
            $this->category_id = $stmt->insert_id;
            $this->name = $name;
            $this->description = $description;
            return ['success' => true, 'message' => 'Category added successfully.'];
        } else {
            return ['success' => false, 'message' => 'Error adding category: ' . $stmt->error];
        }
    }

    public function update($name, $description = '') {
        if (empty($name)) {
            return ['success' => false, 'message' => 'Category name is required.'];
        }
  
        if ($this->nameExists($name, $this->category_id)) {
            return ['success' => false, 'message' => 'Another category with this name already exists.'];
        }
        
        $sql = "UPDATE categories 
                SET name = ?, 
                    description = ?
                WHERE category_id = ?";
        $stmt = $this->conn->prepare($sql);
        if ($stmt === false) {
            return ['success' => false, 'message' => 'Error preparing statement: ' . $this->conn->error];
        }
        $stmt->bind_param("ssi", $name, $description, $this->category_id);
        
        if ($stmt->execute()) {
            $this->name = $name;
            $this->description = $description;
            return ['success' => true, 'message' => 'Category updated successfully.'];
        } else {
            return ['success' => false, 'message' => 'Error updating category: ' . $stmt->error];
        }
    }
    
    public function delete() {
        if ($this->hasEquipment()) {
            return ['success' => false, 'message' => 'Cannot delete category that contains equipment. Please reassign or delete the equipment first.'];
        }
        
        $sql = "DELETE FROM categories WHERE category_id = ?";
        $stmt = $this->conn->prepare($sql);
        if ($stmt === false) {
            return ['success' => false, 'message' => 'Error preparing statement: ' . $this->conn->error];
        }
        $stmt->bind_param("i", $this->category_id);
        
        if ($stmt->execute()) {
            return ['success' => true, 'message' => 'Category deleted successfully.'];
        } else {
            return ['success' => false, 'message' => 'Error deleting category: ' . $stmt->error];
        }
    }
}
?>