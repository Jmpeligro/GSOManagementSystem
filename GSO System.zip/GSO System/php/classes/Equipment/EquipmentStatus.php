<?php
namespace Equipment;

class EquipmentStatus {
    protected $conn;
    protected $base;
    
    public function __construct($conn, $base) {
        $this->conn = $conn;
        $this->base = $base;
    }
    

    public function updateStatus($new_status) {
        $allowed_statuses = ['available', 'maintenance', 'retired', 'denied'];
        
        if (empty($new_status) || !in_array($new_status, $allowed_statuses)) {
            return ['success' => false, 'message' => 'Invalid status selected.'];
        }
        
        $borrowChecker = new EquipmentBorrowing($this->conn, $this->base);
        
        if ($borrowChecker->isFullyBorrowed()) {
            return ['success' => false, 'message' => 'Cannot update status of equipment because all units are currently borrowed.'];
        }

        $effective_status = $new_status;
        $borrowed_count = $borrowChecker->getBorrowedCount();
        
        $sql = "UPDATE equipment 
                SET status = ?, 
                    updated_at = NOW() 
                WHERE equipment_id = ?";
                
        $stmt = $this->conn->prepare($sql);
        if ($stmt === false) {
            return ['success' => false, 'message' => 'Error preparing statement: ' . $this->conn->error];
        }
        
        $stmt->bind_param("si", $effective_status, $this->base->getId());
        
        if ($stmt->execute()) {
            $data = ['status' => $effective_status];
            $this->base->setData(array_merge(['equipment_id' => $this->base->getId()], $data));
            
            $message = 'Equipment status updated to ' . ucfirst($new_status);
            
            if ($borrowed_count > 0) {
                $message .= " (Note: $borrowed_count units are currently borrowed)";
            }
            
            return ['success' => true, 'message' => $message];
        } else {
            return ['success' => false, 'message' => 'Error updating status: ' . $stmt->error];
        }
    }

    public function updateQuantity($new_quantity) {
        if (!is_numeric($new_quantity) || $new_quantity < 0) {
            return ['success' => false, 'message' => 'Quantity cannot be negative.'];
        }
        
        $borrowChecker = new EquipmentBorrowing($this->conn, $this->base);
        $borrowed_count = $borrowChecker->getBorrowedCount();
        
        if ($new_quantity < $borrowed_count) {
            return ['success' => false, 'message' => "Cannot reduce quantity below currently borrowed amount ($borrowed_count)."];
        }
        
        $sql = "UPDATE equipment 
                SET quantity = ?, 
                    available_quantity = quantity - ?,
                    updated_at = NOW() 
                WHERE equipment_id = ?";
                
        $stmt = $this->conn->prepare($sql);
        if ($stmt === false) {
            return ['success' => false, 'message' => 'Error preparing statement: ' . $this->conn->error];
        }
        
        $stmt->bind_param("iii", $new_quantity, $borrowed_count, $this->base->getId());
        
        if ($stmt->execute()) {
            $data = [
                'quantity' => $new_quantity,
                'available_quantity' => $new_quantity - $borrowed_count
            ];
            $this->base->setData(array_merge(['equipment_id' => $this->base->getId()], $data));
            return ['success' => true, 'message' => 'Equipment quantity updated successfully.'];
        } else {
            return ['success' => false, 'message' => 'Error updating quantity: ' . $stmt->error];
        }
    }

   public static function getAll($conn, $filters = []) {
    $equipment = [];
    $where_clauses = ["1=1"]; 
    $params = [];
    $types = "";
    
    if (!empty($filters['status'])) {
        if ($filters['status'] == 'borrowed') {
            $where_clauses[] = "e.available_quantity = 0";
        } else if ($filters['status'] == 'denied') {
            $where_clauses[] = "e.status = 'denied'";
        } else if ($filters['status'] == 'critical') {
            // Consider equipment critical if available quantity is less than or equal to half of total quantity
            $where_clauses[] = "(CASE WHEN e.quantity = 1 THEN e.available_quantity = 0 ELSE e.available_quantity < (e.quantity / 2) END)";
        } else {
            $status = $filters['status'];
            $where_clauses[] = "e.status = ?";
            $params[] = $status;
            $types .= "s";
        }
    }
    
    if (!empty($filters['category']) && $filters['category'] > 0) {
        $where_clauses[] = "e.category_id = ?";
        $params[] = $filters['category'];
        $types .= "i";
    }

    if (!empty($filters['search'])) {
        $where_clauses[] = "(e.name LIKE ? OR e.equipment_code LIKE ? OR e.description LIKE ?)";
        $search_term = '%' . $filters['search'] . '%';
        $params[] = $search_term;
        $params[] = $search_term;
        $params[] = $search_term;
        $types .= "sss";
    }
    
    $sql = "SELECT 
            e.*, 
            c.name as category_name,            CASE 
                WHEN e.available_quantity = 0 THEN 'borrowed'
                WHEN e.available_quantity < e.quantity THEN 'partially_borrowed'
                ELSE e.status
            END as display_status,
            (SELECT COUNT(*) FROM borrowings WHERE equipment_id = e.equipment_id AND status = 'active') as borrowed_count
            FROM equipment e
            JOIN categories c ON e.category_id = c.category_id
            LEFT JOIN borrowings b ON e.equipment_id = b.equipment_id AND b.status = 'active'
            WHERE " . implode(" AND ", $where_clauses);
    
    $sql .= " GROUP BY e.equipment_id ORDER BY e.name ASC";
    
    if (!empty($filters['limit']) && is_numeric($filters['limit'])) {
        $sql .= " LIMIT ?";
        $params[] = (int)$filters['limit'];
        $types .= "i";
    }
    
    if (!empty($params)) {
        $stmt = $conn->prepare($sql);
        if ($stmt === false) {
            error_log('Error preparing statement in getAll: ' . $conn->error);
            return $equipment;
        }
        
        $stmt->bind_param($types, ...$params);
        $stmt->execute();
        $result = $stmt->get_result();
    } else {
        $result = $conn->query($sql);
    }
    
    while ($row = $result->fetch_assoc()) {
        if (!isset($row['available_quantity']) || $row['available_quantity'] === null) {
            $row['available_quantity'] = max(0, $row['quantity'] - ($row['borrowed_count'] ?? 0));
        }
        $equipment[] = $row;
    }
    
    return $equipment;
}
}