<?php
namespace Equipment;

class EquipmentManager {
    protected $conn;
    protected $base;
    protected $borrowing;
    
    public function __construct($conn, $base) {
        $this->conn = $conn;
        $this->base = $base;
        $this->borrowing = new EquipmentBorrowing($conn, $base);
    }

    public function delete() {
        $equipment_id = $this->base->getId();
        
        if (!$equipment_id) {
            return ['success' => false, 'message' => 'No equipment selected for deletion.'];
        }

        $this->conn->begin_transaction();
        
        try {
            $active_borrowings = $this->getActiveBorrowingsCount($equipment_id);
            if ($active_borrowings > 0) {
                $this->conn->rollback();
                return ['success' => false, 'message' => "Cannot delete equipment that has units currently borrowed ($active_borrowings units)."];
            }
            
            $maintenance_count = $this->getMaintenanceRecordsCount($equipment_id);
            if ($maintenance_count > 0) {
                $this->deleteMaintenanceRecords($equipment_id);
            }

            $this->deleteAllBorrowingRecords($equipment_id);
            
            $delete_sql = "DELETE FROM equipment WHERE equipment_id = ?";
            $stmt = $this->conn->prepare($delete_sql);
            if ($stmt === false) {
                $this->conn->rollback();
                return ['success' => false, 'message' => 'Error preparing delete statement: ' . $this->conn->error];
            }
            
            $stmt->bind_param("i", $equipment_id);
            $result = $stmt->execute();
            
            if (!$result) {
                $this->conn->rollback();
                return ['success' => false, 'message' => 'Error deleting equipment: ' . $stmt->error];
            }

            $this->conn->commit();
            return ['success' => true, 'message' => 'Equipment deleted successfully.'];
            
        } catch (\Exception $e) {
            $this->conn->rollback();
            return ['success' => false, 'message' => 'Error during deletion: ' . $e->getMessage()];
        }
    }
    

    private function getActiveBorrowingsCount($equipment_id) {
        $sql = "SELECT COUNT(*) as count FROM borrowings 
                WHERE equipment_id = ? AND status = 'active'";
        $stmt = $this->conn->prepare($sql);
        if ($stmt === false) {
            throw new \Exception('Error preparing statement: ' . $this->conn->error);
        }
        
        $stmt->bind_param("i", $equipment_id);
        $stmt->execute();
        $result = $stmt->get_result();
        return (int)$result->fetch_assoc()['count'];
    }
        private function getMaintenanceRecordsCount($equipment_id) {
        $sql = "SELECT COUNT(*) as count FROM maintenance WHERE equipment_id = ? AND status != 'completed'";
        $stmt = $this->conn->prepare($sql);
        if ($stmt === false) {
            throw new \Exception('Error preparing statement: ' . $this->conn->error);
        }
        
        $stmt->bind_param("i", $equipment_id);
        $stmt->execute();
        $result = $stmt->get_result();
        return (int)$result->fetch_assoc()['count'];
    }

    private function deleteMaintenanceRecords($equipment_id) {
        $sql = "DELETE FROM maintenance WHERE equipment_id = ?";
        $stmt = $this->conn->prepare($sql);
        if ($stmt === false) {
            throw new \Exception('Error preparing statement: ' . $this->conn->error);
        }
        
        $stmt->bind_param("i", $equipment_id);
        $result = $stmt->execute();
        
        if (!$result) {
            throw new \Exception('Error deleting maintenance records: ' . $stmt->error);
        }
        
        return true;
    }
    
    private function deleteAllBorrowingRecords($equipment_id) {
        $sql = "DELETE FROM borrowings WHERE equipment_id = ?";
        $stmt = $this->conn->prepare($sql);
        if ($stmt === false) {
            throw new \Exception('Error preparing statement: ' . $this->conn->error);
        }
        
        $stmt->bind_param("i", $equipment_id);
        $result = $stmt->execute();
        
        if (!$result) {
            throw new \Exception('Error deleting borrowing records: ' . $stmt->error);
        }
        
        return true;
    }

    private function deleteBorrowingHistory($equipment_id) {
        $sql = "DELETE FROM borrowings WHERE equipment_id = ? AND status != 'active'";
        $stmt = $this->conn->prepare($sql);
        if ($stmt === false) {
            throw new \Exception('Error preparing statement: ' . $this->conn->error);
        }
        
        $stmt->bind_param("i", $equipment_id);
        $result = $stmt->execute();
        
        if (!$result) {
            throw new \Exception('Error deleting borrowing history: ' . $stmt->error);
        }
        
        return true;
    }
    

    public function canDelete() {
        $equipment_id = $this->base->getId();
        $issues = [];
        
        $active_borrowings = $this->getActiveBorrowingsCount($equipment_id);
        if ($active_borrowings > 0) {
            $issues[] = "Equipment has $active_borrowings active borrowings";
        }
        
        return [
            'can_delete' => $active_borrowings === 0, 
            'issues' => $issues
        ];
    }
}