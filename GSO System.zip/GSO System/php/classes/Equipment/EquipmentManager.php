<?php
namespace Equipment;

class EquipmentManager {
    protected $conn;
    protected $base;
    protected $borrowing;
    
    public function __construct($conn, $base) {
        $this->conn = $conn;
        $this->base = $base;
        $this->borrowing = new EquipmentBorrowing($conn, $base);
    }
    
    /**
     * Delete equipment with proper cascade and checks
     * 
     * @return array Success status and message
     */
    public function delete() {
        $equipment_id = $this->base->getId();
        
        // First check if equipment exists
        if (!$equipment_id) {
            return ['success' => false, 'message' => 'No equipment selected for deletion.'];
        }
        
        // Begin transaction for consistent delete operation
        $this->conn->begin_transaction();
        
        try {
            // 1. Check for active borrowings
            $active_borrowings = $this->getActiveBorrowingsCount($equipment_id);
            if ($active_borrowings > 0) {
                $this->conn->rollback();
                return ['success' => false, 'message' => "Cannot delete equipment that has units currently borrowed ($active_borrowings units)."];
            }
            
            // 2. Check for maintenance records
            $maintenance_count = $this->getMaintenanceRecordsCount($equipment_id);
            if ($maintenance_count > 0) {
                // Delete all maintenance records
                $this->deleteMaintenanceRecords($equipment_id);
            }

            // 3. Delete ALL borrowing records (including history)
            $this->deleteAllBorrowingRecords($equipment_id);
            
            // 4. Delete the equipment itself
            $delete_sql = "DELETE FROM equipment WHERE equipment_id = ?";
            $stmt = $this->conn->prepare($delete_sql);
            if ($stmt === false) {
                $this->conn->rollback();
                return ['success' => false, 'message' => 'Error preparing delete statement: ' . $this->conn->error];
            }
            
            $stmt->bind_param("i", $equipment_id);
            $result = $stmt->execute();
            
            if (!$result) {
                $this->conn->rollback();
                return ['success' => false, 'message' => 'Error deleting equipment: ' . $stmt->error];
            }

            // All operations successful
            $this->conn->commit();
            return ['success' => true, 'message' => 'Equipment deleted successfully.'];
            
        } catch (\Exception $e) {
            $this->conn->rollback();
            return ['success' => false, 'message' => 'Error during deletion: ' . $e->getMessage()];
        }
    }
    
    /**
     * Get count of active borrowings for equipment
     */
    private function getActiveBorrowingsCount($equipment_id) {
        $sql = "SELECT COUNT(*) as count FROM borrowings 
                WHERE equipment_id = ? AND status = 'active'";
        $stmt = $this->conn->prepare($sql);
        if ($stmt === false) {
            throw new \Exception('Error preparing statement: ' . $this->conn->error);
        }
        
        $stmt->bind_param("i", $equipment_id);
        $stmt->execute();
        $result = $stmt->get_result();
        return (int)$result->fetch_assoc()['count'];
    }
    
    /**
     * Get count of maintenance records for equipment
     */
    private function getMaintenanceRecordsCount($equipment_id) {
        $sql = "SELECT COUNT(*) as count FROM maintenance WHERE equipment_id = ?";
        $stmt = $this->conn->prepare($sql);
        if ($stmt === false) {
            throw new \Exception('Error preparing statement: ' . $this->conn->error);
        }
        
        $stmt->bind_param("i", $equipment_id);
        $stmt->execute();
        $result = $stmt->get_result();
        return (int)$result->fetch_assoc()['count'];
    }
    
    /**
     * Delete maintenance records for equipment
     */
    private function deleteMaintenanceRecords($equipment_id) {
        $sql = "DELETE FROM maintenance WHERE equipment_id = ?";
        $stmt = $this->conn->prepare($sql);
        if ($stmt === false) {
            throw new \Exception('Error preparing statement: ' . $this->conn->error);
        }
        
        $stmt->bind_param("i", $equipment_id);
        $result = $stmt->execute();
        
        if (!$result) {
            throw new \Exception('Error deleting maintenance records: ' . $stmt->error);
        }
        
        return true;
    }
    
    /**
     * Delete all borrowing records, including active ones (use with caution)
     */
    private function deleteAllBorrowingRecords($equipment_id) {
        $sql = "DELETE FROM borrowings WHERE equipment_id = ?";
        $stmt = $this->conn->prepare($sql);
        if ($stmt === false) {
            throw new \Exception('Error preparing statement: ' . $this->conn->error);
        }
        
        $stmt->bind_param("i", $equipment_id);
        $result = $stmt->execute();
        
        if (!$result) {
            throw new \Exception('Error deleting borrowing records: ' . $stmt->error);
        }
        
        return true;
    }
    
    /**
     * Delete borrowing history (non-active records)
     */
    private function deleteBorrowingHistory($equipment_id) {
        $sql = "DELETE FROM borrowings WHERE equipment_id = ? AND status != 'active'";
        $stmt = $this->conn->prepare($sql);
        if ($stmt === false) {
            throw new \Exception('Error preparing statement: ' . $this->conn->error);
        }
        
        $stmt->bind_param("i", $equipment_id);
        $result = $stmt->execute();
        
        if (!$result) {
            throw new \Exception('Error deleting borrowing history: ' . $stmt->error);
        }
        
        return true;
    }
    
    /**
     * Check if equipment can be deleted
     * 
     * @return array Ready status and any blocking reasons
     */
    public function canDelete() {
        $equipment_id = $this->base->getId();
        $issues = [];
        
        // Check active borrowings
        $active_borrowings = $this->getActiveBorrowingsCount($equipment_id);
        if ($active_borrowings > 0) {
            $issues[] = "Equipment has $active_borrowings active borrowings";
        }
        
        // Maintenance records are no longer blocking (we'll delete them)
        
        return [
            'can_delete' => $active_borrowings === 0, // Only active borrowings block deletion
            'issues' => $issues
        ];
    }
}