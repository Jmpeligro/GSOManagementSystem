<?php
namespace Equipment;

class EquipmentData {
    protected $conn;
    protected $base;
    
    public function __construct($conn, $base) {
        $this->conn = $conn;
        $this->base = $base;
    }
    
    public function create($data) {
        if (empty($data['name'])) {
            return ['success' => false, 'message' => 'Equipment name is required.'];
        }

        if (empty($data['equipment_code'])) {
            return ['success' => false, 'message' => 'Equipment code is required.'];
        }

        if ($this->codeExists($data['equipment_code'])) {
            return ['success' => false, 'message' => 'A equipment with this code already exists.'];
        }

        $description = $data['description'] ?? '';
        $notes = $data['notes'] ?? '';
        $quantity = isset($data['quantity']) && is_numeric($data['quantity']) && $data['quantity'] > 0 ? $data['quantity'] : 1;
        
        $sql = "INSERT INTO equipment (
            name, 
            description, 
            equipment_code, 
            category_id, 
            condition_status, 
            status, 
            acquisition_date,
            quantity,
            available_quantity,
            notes,
            created_at,
            updated_at
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, NOW(), NOW())";
        
        $stmt = $this->conn->prepare($sql);
        
        if ($stmt === false) {
            return ['success' => false, 'message' => 'Error preparing statement: ' . $this->conn->error];
        }

        $formatted_date = $this->formatDate($data['acquisition_date']);
        $stmt->bind_param("ssssssiiss", 
            $data['name'], 
            $description, 
            $data['equipment_code'], 
            $data['category_id'], 
            $data['condition_status'], 
            $data['status'], 
            $formatted_date,
            $quantity,
            $quantity,
            $notes
        );
        
        if ($stmt->execute()) {
            $equipment_id = $stmt->insert_id;
            $this->base->load($equipment_id);
            return ['success' => true, 'message' => 'Equipment added successfully.'];
        } else {
            return ['success' => false, 'message' => 'Error adding equipment: ' . $stmt->error];
        }
    }


    public function update($data) {
    if (empty($data['name'])) {
        return ['success' => false, 'message' => 'Equipment name is required.'];
    }

    if (empty($data['equipment_code'])) {
        return ['success' => false, 'message' => 'Equipment code is required.'];
    }

    $equipment_id = $this->base->getId();
    if ($this->codeExists($data['equipment_code'], $equipment_id)) {
        return ['success' => false, 'message' => 'Another equipment with this code already exists.'];
    }
    
    $borrowStatusChecker = new EquipmentBorrowing($this->conn, $this->base);
    $borrowed_count = $borrowStatusChecker->getBorrowedCount();

    if (isset($data['status']) && $data['status'] != 'borrowed' && $borrowStatusChecker->isFullyBorrowed()) {
        return ['success' => false, 'message' => 'Cannot change status of equipment because all units are currently borrowed.'];
    }

    $description = $data['description'] ?? '';
    $notes = $data['notes'] ?? '';
    $quantity = isset($data['quantity']) && is_numeric($data['quantity']) && $data['quantity'] > 0 ? $data['quantity'] : 1;
    
    if ($quantity < $borrowed_count) {
        return ['success' => false, 'message' => "Cannot reduce quantity below currently borrowed amount ($borrowed_count)."];
    }
    
    $available_quantity = isset($data['available_quantity']) && is_numeric($data['available_quantity']) ? 
                          $data['available_quantity'] : ($quantity - $borrowed_count);
                          
    if ($available_quantity > $quantity) {
        return ['success' => false, 'message' => 'Available quantity cannot be greater than total quantity.'];
    }
    
    $min_available = $quantity - $borrowed_count;
    if ($available_quantity < $min_available) {
        $available_quantity = $min_available;
    }

    $effective_status = $data['status'];
   
    $acquisition_date = !empty($data['acquisition_date']) ? $this->formatDate($data['acquisition_date']) : $this->formatDate($this->base->getAcquisitionDate());
    
    $sql = "UPDATE equipment 
            SET name = ?, 
                description = ?, 
                equipment_code = ?, 
                category_id = ?, 
                condition_status = ?, 
                status = ?, 
                acquisition_date = ?,
                quantity = ?,
                available_quantity = ?,
                notes = ?,
                updated_at = NOW() 
            WHERE equipment_id = ?";
    
    $stmt = $this->conn->prepare($sql);
    
    if ($stmt === false) {
        return ['success' => false, 'message' => 'Error preparing statement: ' . $this->conn->error];
    }
    
    $equipment_id = $this->base->getId();
    $stmt->bind_param("sssssssiiis", 
        $data['name'], 
        $description, 
        $data['equipment_code'], 
        $data['category_id'], 
        $data['condition_status'], 
        $data['status'], 
        $acquisition_date, 
        $quantity,
        $available_quantity,
        $notes,
        $equipment_id
    );
    
    if ($stmt->execute()) {
        $this->base->load($equipment_id);
        $message = 'Equipment updated successfully.';

        if ($borrowed_count > 0) {
            $message .= " (Note: $borrowed_count of $quantity units are currently borrowed)";
        }
        
        return ['success' => true, 'message' => $message];
    } else {
        return ['success' => false, 'message' => 'Error updating equipment: ' . $stmt->error];
    }
}
    
    public function delete() {
        $equipment_id = $this->base->getId();
        
        // this checks first maintenance records
        $maintenance_sql = "SELECT COUNT(*) as count FROM maintenance WHERE equipment_id = ?";
        $maintenance_stmt = $this->conn->prepare($maintenance_sql);
        if ($maintenance_stmt === false) {
            return ['success' => false, 'message' => 'Error checking maintenance records: ' . $this->conn->error];
        }
        
        $maintenance_stmt->bind_param("i", $equipment_id);
        $maintenance_stmt->execute();
        $maintenance_result = $maintenance_stmt->get_result();
        
        if ($maintenance_result->fetch_assoc()['count'] > 0) {
            return ['success' => false, 'message' => 'Cannot delete equipment with maintenance records. Please delete maintenance records first.'];
        }
        
        // check the equipment if it's borrowed
        $borrowStatusChecker = new EquipmentBorrowing($this->conn, $this->base);
      
        if ($borrowStatusChecker->isBorrowed()) {
            $borrowed_count = $borrowStatusChecker->getBorrowedCount();
            return ['success' => false, 'message' => "Cannot delete equipment that has units currently borrowed ($borrowed_count units)."];
        }
        
        // delete the borrowing history record of the equipment
        $history_sql = "DELETE FROM borrowings WHERE equipment_id = ? AND status != 'active'";
        $history_stmt = $this->conn->prepare($history_sql);
        if ($history_stmt === false) {
            return ['success' => false, 'message' => 'Error preparing borrowing history deletion: ' . $this->conn->error];
        }
        
        $history_stmt->bind_param("i", $equipment_id);
        $history_stmt->execute();
        
        // then delete the equipment
        $sql = "DELETE FROM equipment WHERE equipment_id = ?";
        $stmt = $this->conn->prepare($sql);
        if ($stmt === false) {
            return ['success' => false, 'message' => 'Error preparing statement: ' . $this->conn->error];
        }
        
        $stmt->bind_param("i", $equipment_id);
        
        if ($stmt->execute()) {
            return ['success' => true, 'message' => 'Equipment deleted successfully.'];
        } else {
            return ['success' => false, 'message' => 'Error deleting equipment: ' . $stmt->error];
        }
    }
    
    public function codeExists($code, $exclude_id = null) {
        $sql = "SELECT COUNT(*) as count FROM equipment WHERE equipment_code = ?";
        $params = [$code];
        $types = "s";
        
        if ($exclude_id !== null) {
            $sql .= " AND equipment_id != ?";
            $params[] = $exclude_id;
            $types .= "i";
        }
        
        $stmt = $this->conn->prepare($sql);
        if ($stmt === false) {
            error_log('Error preparing statement in codeExists: ' . $this->conn->error);
            return true;
        }
        
        $stmt->bind_param($types, ...$params);
        $stmt->execute();
        $result = $stmt->get_result();
        return $result->fetch_assoc()['count'] > 0;
    }

    public function formatDate($date) {
    if (empty($date)) {
        return ''; 
    }

    if (preg_match('/^\d{4}-\d{2}-\d{2}$/', $date)) {
        return $date;
    }

    $timestamp = strtotime($date);
    if ($timestamp === false) {
        return ''; 
    }

    return date('Y-m-d', $timestamp);
    }
}