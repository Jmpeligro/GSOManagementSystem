<?php
require_once 'EquipmentBase.php';
require_once 'EquipmentData.php';
require_once 'EquipmentStatus.php';
require_once 'EquipmentBorrowing.php';
require_once 'EquipmentManager.php';

use Equipment\EquipmentBase;
use Equipment\EquipmentData;
use Equipment\EquipmentStatus;
use Equipment\EquipmentBorrowing;
use Equipment\EquipmentManager;

class Equipment {
    private $base;
    private $data;
    private $status;    
    private $borrowing;
    private $manager;
    
    public function __construct($conn) {
        $this->base = new EquipmentBase($conn);
        $this->data = new EquipmentData($conn, $this->base);
        $this->status = new EquipmentStatus($conn, $this->base);
        $this->borrowing = new EquipmentBorrowing($conn, $this->base);
        $this->manager = new EquipmentManager($conn, $this->base);
    }

    public function load($equipment_id) {
        return $this->base->load($equipment_id);
    }

    public function setData($data) {
        $this->base->setData($data);
    }

    public function create($data) {
        return $this->data->create($data);
    }

    public function update($data) {
        return $this->data->update($data);
    }
    
    public function delete() {
        return $this->manager->delete();
    }
    
    public function canDelete() {
        return $this->manager->canDelete();
    }
    
    public function updateStatus($new_status) {
        return $this->status->updateStatus($new_status);
    }
    
    public function updateQuantity($new_quantity) {
        return $this->status->updateQuantity($new_quantity);
    }

    public function isBorrowed() {
        return $this->borrowing->isBorrowed();
    }
    
    public function isFullyBorrowed() {
        return $this->borrowing->isFullyBorrowed();
    }
    
    public function isPartiallyBorrowed() {
        return $this->isBorrowed() && !$this->isFullyBorrowed();
    }
    
    public function getBorrowedCount() {
        return $this->borrowing->getBorrowedCount();
    }
    
    public function getAvailableCount() {
        return $this->borrowing->getAvailableCount();
    }
    
    public function getBorrowingHistory($limit = 10) {
        return $this->borrowing->getBorrowingHistory($limit);
    }
    
    public function getCurrentBorrower() {
        return $this->borrowing->getCurrentBorrower();
    }
    
    public function getCurrentBorrowers() {
        return $this->borrowing->getCurrentBorrowers();
    }

    public static function getAll($conn, $filters = []) {
        return EquipmentStatus::getAll($conn, $filters);
    }
    
    public function getId() {
        return $this->base->getId();
    }
    
    public function getName() {
        return $this->base->getName();
    }
    
    public function getDescription() {
        return $this->base->getDescription();
    }
    
    public function getEquipmentCode() {
        return $this->base->getEquipmentCode();
    }
    
    public function getCategoryId() {
        return $this->base->getCategoryId();
    }
    
    public function getConditionStatus() {
        return $this->base->getConditionStatus();
    }
    
    public function getStatus() {
        return $this->base->getStatus();
    }
    
    public function getAcquisitionDate() {
        return $this->base->getAcquisitionDate();
    }
    
    public function getNotes() {
        return $this->base->getNotes();
    }
    
    public function getQuantity() {
        return $this->base->getQuantity();
    }
    
    public function getAvailableQuantity() {
        // Fixed: Using base object's method instead of treating data as an array
        return $this->base->getAvailableQuantity();
    }
    
    public function getCreatedAt() {
        return $this->base->getCreatedAt();
    }
    
    public function getUpdatedAt() {
        return $this->base->getUpdatedAt();
    }
    
    public function getQuantityDisplay() {
        return $this->getAvailableQuantity() . ' / ' . $this->getQuantity();
    }

    public function setAvailableQuantity($available_quantity) {
        // This method needs to update the base object, not treat data as an array
        $current_data = [
            'equipment_id' => $this->base->getId(),
            'available_quantity' => (int)$available_quantity
        ];
        $this->base->setData($current_data);
    }
}