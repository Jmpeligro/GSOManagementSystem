<?php
// This file defines the `EquipmentBase` class, which serves as the foundational layer for managing equipment data.
// It provides methods to load, set, and retrieve equipment details, as well as format and display equipment-related information.
// The class interacts directly with the database to handle equipment records.

namespace Equipment;

class EquipmentBase {
    protected $conn;
    protected $equipment_id;
    protected $name;
    protected $description;
    protected $equipment_code;
    protected $category_id;
    protected $condition_status;
    protected $status;
    protected $acquisition_date;
    protected $notes;
    protected $quantity;
    protected $available_quantity;
    protected $created_at;
    protected $updated_at;
    
    public function __construct($conn) {
        $this->conn = $conn;
    }

    public function formatQuantityDisplay($available_quantity = null, $quantity = null) {
    $available = $available_quantity ?? $this->available_quantity;
    $total = $quantity ?? $this->quantity;
    
    return $available . '/' . $total;
}

    public function getStatusWithQuantity() {
        $status = $this->status;
        $quantityDisplay = $this->formatQuantityDisplay();
        
        return ucfirst($status) . ' (' . $quantityDisplay . ')';
    }

    public function load($equipment_id) {
        $sql = "SELECT * FROM equipment WHERE equipment_id = ?";
        $stmt = $this->conn->prepare($sql);
        $stmt->bind_param("i", $equipment_id);
        $stmt->execute();
        $result = $stmt->get_result();
        
        if ($result->num_rows === 0) {
            return false;
        }
        
        $equipment_data = $result->fetch_assoc();
        $this->setData($equipment_data);
        return true;
    }

    public function setData($data) {
        $this->equipment_id = $data['equipment_id'] ?? null;
        $this->name = $data['name'] ?? null;
        $this->description = $data['description'] ?? null;
        $this->equipment_code = $data['equipment_code'] ?? null;
        $this->category_id = $data['category_id'] ?? null;
        $this->condition_status = $data['condition_status'] ?? null;
        $this->status = $data['status'] ?? null;
        $this->acquisition_date = $data['acquisition_date'] ?? null;
        $this->notes = $data['notes'] ?? null;
        $this->quantity = $data['quantity'] ?? 1;
        $this->available_quantity = $data['available_quantity'] ?? $this->quantity;
        $this->created_at = $data['created_at'] ?? null;
        $this->updated_at = $data['updated_at'] ?? null;
    }

    public function getId() {
        return $this->equipment_id;
    }
    
    public function getName() {
        return $this->name;
    }
    
    public function getDescription() {
        return $this->description;
    }
    
    public function getEquipmentCode() {
        return $this->equipment_code;
    }
    
    public function getCategoryId() {
        return $this->category_id;
    }
    
    public function getConditionStatus() {
        return $this->condition_status;
    }
    
    public function getStatus() {
        return $this->status;
    }
    
    public function getAcquisitionDate() {
        return $this->acquisition_date;
    }
    
    public function getNotes() {
        return $this->notes;
    }
    
    public function getQuantity() {
        return $this->quantity;
    }
    
    public function getAvailableQuantity() {
        return $this->available_quantity;
    }
    
    public function getCreatedAt() {
        return $this->created_at;
    }
    
    public function getUpdatedAt() {
        return $this->updated_at;
    }
}