<?php
namespace Equipment;

class EquipmentMaintenance {
    protected $conn;
    protected $base;
    
    // Constructor to initialize the database connection and base equipment object
    public function __construct($conn, $base) {
        $this->conn = $conn;
        $this->base = $base;
    }

    // Retrieves the count of equipment units currently under maintenance
    public function getMaintenanceCount() {
        $sql = "SELECT SUM(maintenance_quantity) as count FROM maintenance 
                WHERE equipment_id = ? AND status != 'completed'";
        $stmt = $this->conn->prepare($sql);
        
        if ($stmt === false) {
            error_log('Error preparing statement in getMaintenanceCount: ' . $this->conn->error);
            return 0;
        }
        
        $equipment_id = $this->base->getId();
        $stmt->bind_param("i", $equipment_id);
        $stmt->execute();
        $result = $stmt->get_result();
        
        if ($row = $result->fetch_assoc()) {
            return (int)($row['count'] ?? 0);
        }
        
        return 0;
    }

    // Sends a specified quantity of equipment units to maintenance with issue details and notes
    public function sendToMaintenance($quantity, $issue_description, $notes = '') {
        // Start transaction
        $this->conn->begin_transaction();
        
        try {
            if (!is_numeric($quantity) || $quantity <= 0) {
                return ['success' => false, 'message' => 'Maintenance quantity must be greater than zero!'];
            }
            
            $equipment_id = $this->base->getId();
            $available_quantity = $this->base->getData('available_quantity');
            
            if ($quantity > $available_quantity) {
                return ['success' => false, 'message' => 'Cannot send more units to maintenance than are available!'];
            }
            
            // Create maintenance record
            $maintenance_date = date('Y-m-d');
            $status = 'pending';
            
            $insert_sql = "INSERT INTO maintenance 
                        (equipment_id, issue_description, maintenance_date, notes, status, maintenance_quantity, created_at, updated_at) 
                        VALUES (?, ?, ?, ?, ?, ?, NOW(), NOW())";
            $insert_stmt = $this->conn->prepare($insert_sql);
            
            if ($insert_stmt === false) {
                throw new \Exception('Error preparing maintenance insert statement: ' . $this->conn->error);
            }
            
            $insert_stmt->bind_param("issssi", $equipment_id, $issue_description, $maintenance_date, $notes, $status, $quantity);
            
            if (!$insert_stmt->execute()) {
                throw new \Exception('Error creating maintenance record: ' . $insert_stmt->error);
            }
            
            // Get current maintenance count
            $current_sql = "SELECT COALESCE(SUM(maintenance_quantity), 0) as count 
                        FROM maintenance 
                        WHERE equipment_id = ? 
                        AND status != 'completed'";
            $current_stmt = $this->conn->prepare($current_sql);
            
            if ($current_stmt === false) {
                throw new \Exception('Error preparing current maintenance count statement: ' . $this->conn->error);
            }
            
            $equipment_id = $this->base->getId();
            $current_stmt->bind_param("i", $equipment_id);
            $current_stmt->execute();
            $result = $current_stmt->get_result();
            
            $current_maintenance_count = 0;
            if ($row = $result->fetch_assoc()) {
                $current_maintenance_count = (int)($row['count'] ?? 0);
            }
            
            // Update equipment status and available quantity
            $borrowChecker = new EquipmentBorrowing($this->conn, $this->base);
            $borrowed_count = $borrowChecker->getBorrowedCount();
            
            // Calculate new maintenance count including the one we just inserted
            $new_maintenance_count = $current_maintenance_count + $quantity;
            $new_available_quantity = $this->base->getData('quantity') - $borrowed_count - $new_maintenance_count;
            
            // Determine new equipment status
            $new_status = $this->determineStatus($borrowed_count, $new_maintenance_count);
            
            // Update equipment table
            $update_sql = "UPDATE equipment 
                        SET status = ?, 
                            available_quantity = ?,
                            updated_at = NOW() 
                        WHERE equipment_id = ?";
            $update_stmt = $this->conn->prepare($update_sql);
            
            if ($update_stmt === false) {
                throw new \Exception('Error preparing equipment update statement: ' . $this->conn->error);
            }
            
            $update_stmt->bind_param("sii", $new_status, $new_available_quantity, $equipment_id);
            
            if (!$update_stmt->execute()) {
                throw new \Exception('Error updating equipment status: ' . $update_stmt->error);
            }

            $this->base->setData([
                'status' => $new_status,
                'available_quantity' => $new_available_quantity
            ]);
            
            $this->conn->commit();
            
            return ['success' => true, 'message' => 'Equipment sent to maintenance successfully!'];
            
        } catch (\Exception $e) {
            $this->conn->rollback();
            error_log('Error in sendToMaintenance: ' . $e->getMessage());
            return ['success' => false, 'message' => $e->getMessage()];
        }
    }   

    // Marks a maintenance record as completed, updating the equipment status and available quantity
    public function completeMaintenance($maintenance_id, $cost = 0, $notes = '', $resolved_by = '') {
        // Start transaction
        $this->conn->begin_transaction();
        
        try {
            $maintenance_sql = "SELECT equipment_id, maintenance_quantity, status FROM maintenance WHERE maintenance_id = ?";
            $maintenance_stmt = $this->conn->prepare($maintenance_sql);
            
            if ($maintenance_stmt === false) {
                throw new \Exception('Error preparing maintenance select statement: ' . $this->conn->error);
            }
            
            $maintenance_stmt->bind_param("i", $maintenance_id);
            $maintenance_stmt->execute();
            $maintenance_result = $maintenance_stmt->get_result();
            
            if ($maintenance_result->num_rows === 0) {
                throw new \Exception('Maintenance record not found!');
            }
            
            $maintenance_data = $maintenance_result->fetch_assoc();
            
            if ($maintenance_data['status'] === 'completed') {
                throw new \Exception('This maintenance record is already completed!');
            }
            
            $equipment_id = $maintenance_data['equipment_id'];
            $maintenance_quantity = $maintenance_data['maintenance_quantity'];

            if ($equipment_id != $this->base->getId()) {
                $equipment_sql = "SELECT * FROM equipment WHERE equipment_id = ?";
                $equipment_stmt = $this->conn->prepare($equipment_sql);
                $equipment_stmt->bind_param("i", $equipment_id);
                $equipment_stmt->execute();
                $equipment_result = $equipment_stmt->get_result();
                
                if ($equipment_result->num_rows === 0) {
                    throw new \Exception('Equipment not found!');
                }
                
                $equipment_data = $equipment_result->fetch_assoc();
                $this->base->setData($equipment_data);
            }
            $resolved_date = date('Y-m-d');
            $resolved_by = !empty($resolved_by) ? $resolved_by : $_SESSION['first_name'] . ' ' . $_SESSION['last_name'];
            $status = 'completed';
            
            $update_sql = "UPDATE maintenance 
                        SET status = ?, 
                            notes = CONCAT(IFNULL(notes, ''), '\n', ?),
                            resolved_date = ?,
                            resolved_by = ?,
                            cost = ?,
                            updated_at = NOW()
                        WHERE maintenance_id = ?";
            $update_stmt = $this->conn->prepare($update_sql);
            
            if ($update_stmt === false) {
                throw new \Exception('Error preparing maintenance update statement: ' . $this->conn->error);
            }
            
            $update_stmt->bind_param("sssdi", $status, $notes, $resolved_date, $resolved_by, $cost, $maintenance_id);
            
            if (!$update_stmt->execute()) {
                throw new \Exception('Error updating maintenance record: ' . $update_stmt->error);
            }
            
            $borrowChecker = new EquipmentBorrowing($this->conn, $this->base);
            $borrowed_count = $borrowChecker->getBorrowedCount();
            
            $maintenance_count_sql = "SELECT SUM(maintenance_quantity) as count FROM maintenance 
                                    WHERE equipment_id = ? AND status != 'completed' AND maintenance_id != ?";
            $maintenance_stmt = $this->conn->prepare($maintenance_count_sql);
            $maintenance_stmt->bind_param("ii", $equipment_id, $maintenance_id);
            $maintenance_stmt->execute();
            $maintenance_result = $maintenance_stmt->get_result();
            $maintenance_data = $maintenance_result->fetch_assoc();
            $new_maintenance_count = (int)($maintenance_data['count'] ?? 0);
            
            $new_available_quantity = $this->base->getData('quantity') - $borrowed_count - $new_maintenance_count;

            $new_status = $this->determineStatus($borrowed_count, $new_maintenance_count);
            
            $update_sql = "UPDATE equipment 
                        SET status = ?, 
                            available_quantity = ?, 
                            updated_at = NOW() 
                        WHERE equipment_id = ?";
            $update_stmt = $this->conn->prepare($update_sql);
            
            if ($update_stmt === false) {
                throw new \Exception('Error preparing equipment update statement: ' . $this->conn->error);
            }
            
            $update_stmt->bind_param("sii", $new_status, $new_available_quantity, $equipment_id);
            
            if (!$update_stmt->execute()) {
                throw new \Exception('Error updating equipment status: ' . $update_stmt->error);
            }

            $this->base->setData([
                'status' => $new_status,
                'available_quantity' => $new_available_quantity
            ]);
            
            $this->conn->commit();
            
            return ['success' => true, 'message' => 'Maintenance completed successfully!'];
            
        } catch (\Exception $e) {
            $this->conn->rollback();
            error_log('Error in completeMaintenance: ' . $e->getMessage());
            return ['success' => false, 'message' => $e->getMessage()];
        }
    }

    // Deletes a maintenance record and updates the equipment status and available quantity
    public function deleteMaintenance($maintenance_id) {
        $this->conn->begin_transaction();
        
        try {
            $maintenance_sql = "SELECT equipment_id, maintenance_quantity, status FROM maintenance WHERE maintenance_id = ?";
            $maintenance_stmt = $this->conn->prepare($maintenance_sql);
            
            if ($maintenance_stmt === false) {
                throw new \Exception('Error preparing maintenance select statement: ' . $this->conn->error);
            }
            
            $maintenance_stmt->bind_param("i", $maintenance_id);
            $maintenance_stmt->execute();
            $maintenance_result = $maintenance_stmt->get_result();
            
            if ($maintenance_result->num_rows === 0) {
                throw new \Exception('Maintenance record not found!');
            }
            
            $maintenance_data = $maintenance_result->fetch_assoc();
            $equipment_id = $maintenance_data['equipment_id'];
            $maintenance_quantity = $maintenance_data['maintenance_quantity'];
            $status = $maintenance_data['status'];
            
            if ($equipment_id != $this->base->getId()) {
                $equipment_sql = "SELECT * FROM equipment WHERE equipment_id = ?";
                $equipment_stmt = $this->conn->prepare($equipment_sql);
                $equipment_stmt->bind_param("i", $equipment_id);
                $equipment_stmt->execute();
                $equipment_result = $equipment_stmt->get_result();
                
                if ($equipment_result->num_rows === 0) {
                    throw new \Exception('Equipment not found!');
                }
                
                $equipment_data = $equipment_result->fetch_assoc();
                $this->base->setData($equipment_data);
            }

            $delete_sql = "DELETE FROM maintenance WHERE maintenance_id = ?";
            $delete_stmt = $this->conn->prepare($delete_sql);
            
            if ($delete_stmt === false) {
                throw new \Exception('Error preparing maintenance delete statement: ' . $this->conn->error);
            }
            
            $delete_stmt->bind_param("i", $maintenance_id);
            
            if (!$delete_stmt->execute()) {
                throw new \Exception('Error deleting maintenance record: ' . $delete_stmt->error);
            }
            
            if ($status !== 'completed') {
                $borrowChecker = new EquipmentBorrowing($this->conn, $this->base);
                $borrowed_count = $borrowChecker->getBorrowedCount();

                $maintenance_count_sql = "SELECT SUM(maintenance_quantity) as count FROM maintenance 
                                        WHERE equipment_id = ? AND status != 'completed'";
                $maintenance_stmt = $this->conn->prepare($maintenance_count_sql);
                $maintenance_stmt->bind_param("i", $equipment_id);
                $maintenance_stmt->execute();
                $maintenance_result = $maintenance_stmt->get_result();
                $maintenance_data = $maintenance_result->fetch_assoc();
                $new_maintenance_count = (int)($maintenance_data['count'] ?? 0);
                
                $new_available_quantity = $this->base->getData('quantity') - $borrowed_count - $new_maintenance_count;
                
                $new_status = $this->determineStatus($borrowed_count, $new_maintenance_count);
                
                $update_sql = "UPDATE equipment 
                            SET status = ?, 
                                available_quantity = ?, 
                                updated_at = NOW() 
                            WHERE equipment_id = ?";
                $update_stmt = $this->conn->prepare($update_sql);
                
                if ($update_stmt === false) {
                    throw new \Exception('Error preparing equipment update statement: ' . $this->conn->error);
                }
                
                $update_stmt->bind_param("sii", $new_status, $new_available_quantity, $equipment_id);
                
                if (!$update_stmt->execute()) {
                    throw new \Exception('Error updating equipment status: ' . $update_stmt->error);
                }
                $this->base->setData([
                    'status' => $new_status,
                    'available_quantity' => $new_available_quantity
                ]);
            }

            $this->conn->commit();
            
            return ['success' => true, 'message' => 'Maintenance record deleted successfully!'];
            
        } catch (\Exception $e) {
            $this->conn->rollback();
            error_log('Error in deleteMaintenance: ' . $e->getMessage());
            return ['success' => false, 'message' => $e->getMessage()];
        }
    }
    
    // Retrieves all maintenance records for a specific equipment, ordered by status and date
    public function getMaintenanceRecords($equipment_id = null) {
        if ($equipment_id === null) {
            $equipment_id = $this->base->getId();
        }
        
        $sql = "SELECT 
                m.*,
                e.name as equipment_name,
                e.equipment_code
                FROM maintenance m
                JOIN equipment e ON m.equipment_id = e.equipment_id
                WHERE m.equipment_id = ?
                ORDER BY 
                    CASE 
                        WHEN m.status = 'pending' THEN 1
                        WHEN m.status = 'in_progress' THEN 2
                        WHEN m.status = 'completed' THEN 3
                    END, 
                    m.maintenance_date DESC";
        
        $stmt = $this->conn->prepare($sql);
        
        if ($stmt === false) {
            error_log('Error preparing statement in getMaintenanceRecords: ' . $this->conn->error);
            return [];
        }
        
        $stmt->bind_param("i", $equipment_id);
        $stmt->execute();
        $result = $stmt->get_result();
        
        $records = [];
        while ($row = $result->fetch_assoc()) {
            $records[] = $row;
        }
        
        return $records;
    }

    // Determines the status of the equipment based on borrowed and maintenance counts
    private function determineStatus($borrowed_count, $maintenance_count) {
        $total_quantity = $this->base->getData('quantity');
        
        $borrowed_count = max(0, $borrowed_count);
        $maintenance_count = max(0, $maintenance_count);
        
        // Calculate available quantity
        $available = $total_quantity - $borrowed_count - $maintenance_count;
        
        if ($maintenance_count >= $total_quantity) {
            // All units are in maintenance
            return 'maintenance';
        }
        
        if ($borrowed_count >= $total_quantity) {
            // All units are borrowed
            return 'borrowed';
        }
        
        if ($available === $total_quantity) {
            // All units are available
            return 'available';
        }
        
        if ($available === 0) {
            // No units available - split between maintenance and borrowing
            if ($borrowed_count > 0 && $maintenance_count > 0) {
                return 'partially_both';
            } else if ($maintenance_count > 0) {
                return 'maintenance';
            } else {
                return 'borrowed';
            }
        }
        
        // Some units are still available
        if ($borrowed_count > 0 && $maintenance_count > 0) {
            return 'partially_both';
        } else if ($maintenance_count > 0) {
            return 'partially_maintenance';
        } else if ($borrowed_count > 0) {
            return 'partially_borrowed';
        }
        
        return 'available';
    }
    

    // Retrieves maintenance statistics for a specific equipment, including counts and costs
    public function getMaintenanceStats($equipment_id = null) {
        if ($equipment_id === null) {
            $equipment_id = $this->base->getId();
        }
        
        $sql = "SELECT 
                COUNT(*) as total_records,
                SUM(CASE WHEN status = 'pending' THEN 1 ELSE 0 END) as pending_count,
                SUM(CASE WHEN status = 'in_progress' THEN 1 ELSE 0 END) as in_progress_count,
                SUM(CASE WHEN status = 'completed' THEN 1 ELSE 0 END) as completed_count,
                SUM(CASE WHEN status != 'completed' THEN maintenance_quantity ELSE 0 END) as in_maintenance_quantity,
                AVG(CASE WHEN status = 'completed' THEN cost ELSE NULL END) as avg_cost,
                SUM(CASE WHEN status = 'completed' THEN cost ELSE 0 END) as total_cost
                FROM maintenance
                WHERE equipment_id = ?";
        
        $stmt = $this->conn->prepare($sql);
        
        if ($stmt === false) {
            error_log('Error preparing statement in getMaintenanceStats: ' . $this->conn->error);
            return [];
        }
        
        $stmt->bind_param("i", $equipment_id);
        $stmt->execute();
        $result = $stmt->get_result();
        
        return $result->fetch_assoc();
    }
}
?>