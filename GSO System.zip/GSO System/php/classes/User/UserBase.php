<?php

class UserBase {
    protected $conn;
    protected $user_id;
    protected $university_id;
    protected $first_name;
    protected $last_name;
    protected $email;
    protected $password;
    protected $role;
    protected $department;
    protected $phone;
    protected $program_year_section;
    protected $status;
    protected $status_changed_at;
    protected $created_at;
    protected $updated_at;
    
    public function __construct($conn) {
        $this->conn = $conn;
    }

    public function load($user_id) {
        $sql = "SELECT * FROM users WHERE user_id = ?";
        $stmt = $this->conn->prepare($sql);
        $stmt->bind_param("i", $user_id);
        $stmt->execute();
        $result = $stmt->get_result();
        
        if ($result->num_rows === 0) {
            return false;
        }
        
        $user_data = $result->fetch_assoc();
        $this->setData($user_data);
        return true;
    }

    public function setData($data) {
        $this->user_id = $data['user_id'] ?? null;
        $this->university_id = $data['university_id'] ?? null;
        $this->first_name = $data['first_name'] ?? null;
        $this->last_name = $data['last_name'] ?? null;
        $this->email = $data['email'] ?? null;
        $this->password = $data['password'] ?? null;
        $this->role = $data['role'] ?? null;
        $this->department = $data['department'] ?? null;
        $this->phone = $data['phone'] ?? null;
        $this->program_year_section = $data['program_year_section'] ?? null;
        $this->status = $data['status'] ?? 'active';
        $this->status_changed_at = $data['status_changed_at'] ?? null;
        $this->created_at = $data['created_at'] ?? null;
        $this->updated_at = $data['updated_at'] ?? null;
    }
    
    // Getters
    public function getUserId() {
        return $this->user_id;
    }
    
    public function getUniversityId() {
        return $this->university_id;
    }
    
    public function getFirstName() {
        return $this->first_name;
    }
    
    public function getLastName() {
        return $this->last_name;
    }
    
    public function getFullName() {
        return $this->first_name . ' ' . $this->last_name;
    }
    
    public function getEmail() {
        return $this->email;
    }
    
    public function getRole() {
        return $this->role;
    }
    
    public function getDepartment() {
        return $this->department;
    }
    
    public function getPhone() {
        return $this->phone;
    }
    
    public function getProgramYearSection() {
        return $this->program_year_section;
    }
    
    public function getStatus() {
        return $this->status;
    }
    
    public function getStatusChangedAt() {
        return $this->status_changed_at;
    }
    
    public function getCreatedAt() {
        return $this->created_at;
    }
    
    public function getUpdatedAt() {
        return $this->updated_at;
    }
}
?>