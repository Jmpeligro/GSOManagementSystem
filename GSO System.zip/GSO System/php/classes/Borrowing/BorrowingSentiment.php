<?php
require_once 'SentimentAnalysis.php';

class BorrowingSentiment {
    private $conn;
    private $sentimentAnalyzer;
    
    public function __construct($conn) {
        $this->conn = $conn;
        $this->sentimentAnalyzer = new SentimentAnalysis();
    }
    
    public function getReturnNotesSentiment($limit = null, $dateRange = '', $conditionFilter = '', $sentimentFilter = '') {
        $limitClause = $limit ? "LIMIT " . intval($limit) : "";
        $dateFilter = '';
        $conditionFilterClause = '';
        
        if (!empty($dateRange)) {
            $dateFilter = " AND b.return_date >= DATE_SUB(CURDATE(), INTERVAL " . intval($dateRange) . " DAY)";
        }
        
        if (!empty($conditionFilter)) {
            $conditionFilterClause = " AND b.condition_on_return = '" . $this->conn->real_escape_string($conditionFilter) . "'";
        }
        
        $sql = "SELECT b.borrowing_id, b.equipment_id, b.user_id, b.return_date, 
                    b.return_notes, b.condition_on_return,
                    e.name as equipment_name, 
                    u.first_name, u.last_name
                FROM borrowings b
                JOIN equipment e ON b.equipment_id = e.equipment_id
                JOIN users u ON b.user_id = u.user_id
                WHERE (b.status = 'returned' OR b.status = 'overdue')
                    AND b.return_notes IS NOT NULL 
                    AND b.return_notes != ''
                    AND b.condition_on_return IS NOT NULL
                    $dateFilter
                    $conditionFilterClause
                ORDER BY b.return_date DESC
                $limitClause";
        
        $result = $this->conn->query($sql);
        
        if (!$result) {
            return [
                'success' => false,
                'message' => 'Database query error: ' . $this->conn->error,
                'data' => []
            ];
        }
        
        $return_notes = [];
        
        while ($row = $result->fetch_assoc()) {
            $sentiment = $this->sentimentAnalyzer->analyze($row['return_notes']);
            
            // Apply sentiment filter if specified
            if (!empty($sentimentFilter) && strtolower($sentiment['sentiment']) !== strtolower($sentimentFilter)) {
                continue;
            }
            
            $return_notes[] = [
                'borrowing_id' => $row['borrowing_id'],
                'equipment_id' => $row['equipment_id'],
                'equipment_name' => $row['equipment_name'],
                'user_id' => $row['user_id'],
                'user_name' => $row['first_name'] . ' ' . $row['last_name'],
                'return_date' => $row['return_date'],
                'return_notes' => $row['return_notes'],
                'condition' => $row['condition_on_return'],
                'sentiment' => $sentiment['sentiment'],
                'polarity' => $sentiment['polarity'],
                'color' => $this->sentimentAnalyzer->getPolarityColor($sentiment['polarity'])
            ];
        }
        
        return [
            'success' => true,
            'count' => count($return_notes),
            'data' => $return_notes
        ];
    }
    
    public function getSentimentSummary($dateRange = '') {
        $dateFilter = '';
        if (!empty($dateRange)) {
            $dateFilter = " AND b.return_date >= DATE_SUB(CURDATE(), INTERVAL " . intval($dateRange) . " DAY)";
        }
        
        $sql = "SELECT b.condition_on_return, b.return_notes
                FROM borrowings b
                WHERE (b.status = 'returned' OR b.status = 'overdue')
                AND b.return_notes IS NOT NULL 
                AND b.return_notes != ''
                AND b.condition_on_return IS NOT NULL
                $dateFilter";
        
        $result = $this->conn->query($sql);
        
        if (!$result) {
            return [
                'success' => false,
                'message' => 'Database query error: ' . $this->conn->error
            ];
        }
        
        $sentiment_counts = [
            'Positive' => 0,
            'Neutral' => 0,
            'Negative' => 0
        ];
        
        $condition_sentiment = [
            'good' => ['Positive' => 0, 'Neutral' => 0, 'Negative' => 0],
            'fair' => ['Positive' => 0, 'Neutral' => 0, 'Negative' => 0],
            'damaged' => ['Positive' => 0, 'Neutral' => 0, 'Negative' => 0]
        ];
        
        $total_analyzed = 0;
        $total_polarity = 0;
        
        while ($row = $result->fetch_assoc()) {
            $sentiment = $this->sentimentAnalyzer->analyze($row['return_notes']);
            $sentiment_counts[$sentiment['sentiment']]++;
            
            // Add to condition-based sentiment counts
            $condition = strtolower($row['condition_on_return']);
            if (array_key_exists($condition, $condition_sentiment)) {
                $condition_sentiment[$condition][$sentiment['sentiment']]++;
            }
            
            $total_analyzed++;
            $total_polarity += $sentiment['polarity'];
        }
        
        $avg_polarity = $total_analyzed > 0 ? $total_polarity / $total_analyzed : 0;
        
        return [
            'success' => true,
            'total_notes' => $total_analyzed,
            'sentiment_counts' => $sentiment_counts,
            'condition_sentiment' => $condition_sentiment,
            'average_polarity' => $avg_polarity,
            'overall_sentiment' => $avg_polarity > 0.05 ? 'Positive' : ($avg_polarity < -0.05 ? 'Negative' : 'Neutral')
        ];
    }
    
    public function getMonthlySentimentTrends($months = 6) {
        $sql = "SELECT 
                  DATE_FORMAT(b.return_date, '%Y-%m') AS month,
                  COUNT(*) as total_returns,
                  b.return_notes
                FROM 
                  borrowings b
                WHERE 
                  b.status = 'returned' 
                  AND b.return_notes IS NOT NULL 
                  AND b.return_notes != ''
                  AND b.return_date >= DATE_SUB(CURDATE(), INTERVAL $months MONTH)
                GROUP BY 
                  DATE_FORMAT(b.return_date, '%Y-%m'), b.borrowing_id
                ORDER BY 
                  month ASC";
        
        $result = $this->conn->query($sql);
        
        if (!$result) {
            return [
                'success' => false,
                'message' => 'Database query error: ' . $this->conn->error
            ];
        }
        
        $monthly_data = [];
        
        while ($row = $result->fetch_assoc()) {
            $month = $row['month'];
            $sentiment = $this->sentimentAnalyzer->analyze($row['return_notes']);
            
            if (!isset($monthly_data[$month])) {
                $monthly_data[$month] = [
                    'total' => 0,
                    'positive' => 0,
                    'neutral' => 0,
                    'negative' => 0,
                    'avg_polarity' => 0,
                    'polarity_sum' => 0
                ];
            }
            
            $monthly_data[$month]['total']++;
            $monthly_data[$month][$sentiment['sentiment'] == 'Positive' ? 'positive' : ($sentiment['sentiment'] == 'Negative' ? 'negative' : 'neutral')]++;
            $monthly_data[$month]['polarity_sum'] += $sentiment['polarity'];
        }
        
        foreach ($monthly_data as $month => &$data) {
            $data['avg_polarity'] = $data['total'] > 0 ? $data['polarity_sum'] / $data['total'] : 0;
            unset($data['polarity_sum']);
        }
        
        return [
            'success' => true,
            'monthly_data' => $monthly_data
        ];
    }
}