<?php

class BorrowingBase {
    protected $conn;
    protected $borrowing_id;
    protected $equipment_id;
    protected $user_id;
    protected $borrow_date;
    protected $due_date;
    protected $return_date;
    protected $admin_issued_id;
    protected $admin_received_id;
    protected $status;
    protected $condition_on_return;
    protected $notes;
    protected $approval_status;
    protected $approved_by;
    protected $approval_date;
    protected $admin_notes;
    protected $return_notes;
    protected $returned_by;
    protected $created_at;
    protected $updated_at;
    
    public function __construct($conn) {
        $this->conn = $conn;
    }
    
    public function load($borrowing_id) {
        $sql = "SELECT * FROM borrowings WHERE borrowing_id = ?";
        $stmt = $this->conn->prepare($sql);
        $stmt->bind_param("i", $borrowing_id);
        $stmt->execute();
        $result = $stmt->get_result();
        
        if ($result->num_rows === 0) {
            return false;
        }
        
        $borrowing_data = $result->fetch_assoc();
        $this->setData($borrowing_data);
        return true;
    }
    
    public function setData($data) {
        $this->borrowing_id = $data['borrowing_id'] ?? null;
        $this->equipment_id = $data['equipment_id'] ?? null;
        $this->user_id = $data['user_id'] ?? null;
        $this->borrow_date = $data['borrow_date'] ?? null;
        $this->due_date = $data['due_date'] ?? null;
        $this->return_date = $data['return_date'] ?? null;
        $this->admin_issued_id = $data['admin_issued_id'] ?? null;
        $this->admin_received_id = $data['admin_received_id'] ?? null;
        $this->status = $data['status'] ?? null;
        $this->condition_on_return = $data['condition_on_return'] ?? null;
        $this->notes = $data['notes'] ?? null;
        $this->approval_status = $data['approval_status'] ?? null;
        $this->approved_by = $data['approved_by'] ?? null;
        $this->approval_date = $data['approval_date'] ?? null;
        $this->admin_notes = $data['admin_notes'] ?? null;
        $this->return_notes = $data['return_notes'] ?? null;
        $this->returned_by = $data['returned_by'] ?? null;
        $this->created_at = $data['created_at'] ?? null;
        $this->updated_at = $data['updated_at'] ?? null;
    }
    
    public function getId() {
        return $this->borrowing_id;
    }
    
    public function getEquipmentId() {
        return $this->equipment_id;
    }
    
    public function getUserId() {
        return $this->user_id;
    }
    
    public function getBorrowDate() {
        return $this->borrow_date;
    }
    
    public function getDueDate() {
        return $this->due_date;
    }
    
    public function getReturnDate() {
        return $this->return_date;
    }
    
    public function getAdminIssuedId() {
        return $this->admin_issued_id;
    }
    
    public function getAdminReceivedId() {
        return $this->admin_received_id;
    }
    
    public function getStatus() {
        return $this->status;
    }
    
    public function getConditionOnReturn() {
        return $this->condition_on_return;
    }
    
    public function getNotes() {
        return $this->notes;
    }
    
    public function getApprovalStatus() {
        return $this->approval_status;
    }
    
    public function getApprovedBy() {
        return $this->approved_by;
    }
    
    public function getApprovalDate() {
        return $this->approval_date;
    }
    
    public function getAdminNotes() {
        return $this->admin_notes;
    }
    
    public function getReturnNotes() {
        return $this->return_notes;
    }
    
    public function getReturnedBy() {
        return $this->returned_by;
    }
    
    public function getCreatedAt() {
        return $this->created_at;
    }
    
    public function getUpdatedAt() {
        return $this->updated_at;
    }
    
    public function isOverdue() {
        if ($this->status === 'active' && $this->due_date) {
            $due_datetime = new DateTime($this->due_date);
            $current_datetime = new DateTime();
            return $current_datetime > $due_datetime;
        }
        return false;
    }
        
    protected function checkEquipmentAvailability($equipment_id) {
        $sql = "SELECT available_quantity, status FROM equipment WHERE equipment_id = ?";
        $stmt = $this->conn->prepare($sql);
        $stmt->bind_param("i", $equipment_id);
        $stmt->execute();
        $result = $stmt->get_result();
        
        if ($result->num_rows === 0) {
            return false;
        }
        
        $equipment_data = $result->fetch_assoc();
          // Check if equipment is under maintenance or retired
        if ($equipment_data['status'] === 'maintenance' || $equipment_data['status'] === 'retired') {
            return false;
        }
        
        return $equipment_data['available_quantity'] > 0;
    }
}