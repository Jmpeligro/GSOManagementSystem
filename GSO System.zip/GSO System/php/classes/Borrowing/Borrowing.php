<?php
require_once 'BorrowingBase.php';
require_once 'BorrowingActions.php';
require_once 'BorrowingData.php';

class Borrowing extends BorrowingActions {

    public static function getAllBorrowings($conn, $filters = []) {

        return BorrowingData::getAll($conn, $filters);
    }

    public static function getPendingRequests($conn) {
        return BorrowingData::getPendingRequests($conn);
    }

    public static function getUserBorrowings($conn, $user_id) {
        return BorrowingData::getUserBorrowings($conn, $user_id);
    }
    
    public static function getOverdueBorrowings($conn) {
        return BorrowingData::getOverdueBorrowings($conn);
    }

    public static function getEquipmentBorrowingHistory($conn, $equipment_id, $limit = 10) {
        return BorrowingData::getEquipmentBorrowingHistory($conn, $equipment_id, $limit);
    }
}
?>