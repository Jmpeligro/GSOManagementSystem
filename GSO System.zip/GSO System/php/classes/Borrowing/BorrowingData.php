<?php

require_once 'BorrowingBase.php';

class BorrowingData extends BorrowingBase {
    public function getBorrowerDetails() {
        if (!$this->user_id) {
            return null;
        }
        
        $sql = "SELECT user_id, first_name, last_name, email, university_id, role, department 
                FROM users WHERE user_id = ?";
        $stmt = $this->conn->prepare($sql);
        $stmt->bind_param("i", $this->user_id);
        $stmt->execute();
        $result = $stmt->get_result();
        
        if ($result->num_rows === 0) {
            return null;
        }
        
        return $result->fetch_assoc();
    }
    
    public function getEquipmentDetails() {
        if (!$this->equipment_id) {
            return null;
        }
        
        $sql = "SELECT e.*, c.name as category_name 
                FROM equipment e
                JOIN categories c ON e.category_id = c.category_id
                WHERE e.equipment_id = ?";
        $stmt = $this->conn->prepare($sql);
        $stmt->bind_param("i", $this->equipment_id);
        $stmt->execute();
        $result = $stmt->get_result();
        
        if ($result->num_rows === 0) {
            return null;
        }
        
        return $result->fetch_assoc();
    }
    
    public static function getAll($conn, $filters = []) {
        $borrowings = [];
        $where_clauses = ["1=1"]; 
        $params = [];
        $types = "";
        
        // Handle status filter
        if (!empty($filters['status'])) {
            $where_clauses[] = "b.status = ?";
            $params[] = $filters['status'];
            $types .= "s";
        }
        
        // Handle approval status filter
        if (!empty($filters['approval_status'])) {
            $where_clauses[] = "b.approval_status = ?";
            $params[] = $filters['approval_status'];
            $types .= "s";
        }
        
        // Handle equipment filter
        if (!empty($filters['equipment_id']) && $filters['equipment_id'] > 0) {
            $where_clauses[] = "b.equipment_id = ?";
            $params[] = $filters['equipment_id'];
            $types .= "i";
        }
        
        // Handle user filter
        if (!empty($filters['user_id']) && $filters['user_id'] > 0) {
            $where_clauses[] = "b.user_id = ?";
            $params[] = $filters['user_id'];
            $types .= "i";
        }
        
        // Handle date range filter
        if (!empty($filters['date_from'])) {
            $where_clauses[] = "b.borrow_date >= ?";
            $params[] = $filters['date_from'];
            $types .= "s";
        }
        
        if (!empty($filters['date_to'])) {
            $where_clauses[] = "b.borrow_date <= ?";
            $params[] = $filters['date_to'] . ' 23:59:59';
            $types .= "s";
        }
        
        // Handle search query
        if (!empty($filters['search'])) {
            $where_clauses[] = "(e.name LIKE ? OR e.equipment_code LIKE ? OR 
                              u.first_name LIKE ? OR u.last_name LIKE ? OR u.email LIKE ?)";
            $search_term = '%' . $filters['search'] . '%';
            for ($i = 0; $i < 5; $i++) {
                $params[] = $search_term;
                $types .= "s";
            }
        }
        
        // Handle condition filter
        if (!empty($filters['condition'])) {
            $where_clauses[] = "b.condition_on_return = ?";
            $params[] = $filters['condition'];
            $types .= "s";
        }
        
        $sql = "SELECT 
                b.*,
                e.name as equipment_name, 
                e.equipment_code,
                u.first_name, 
                u.last_name, 
                u.email
                FROM borrowings b
                JOIN equipment e ON b.equipment_id = e.equipment_id
                JOIN users u ON b.user_id = u.user_id
                WHERE " . implode(" AND ", $where_clauses) . "
                ORDER BY b.borrow_date DESC";
        
        if (!empty($params)) {
            $stmt = $conn->prepare($sql);
            if ($stmt === false) {
                return $borrowings;
            }
            
            $stmt->bind_param($types, ...$params);
            $stmt->execute();
            $result = $stmt->get_result();
        } else {
            $result = $conn->query($sql);
        }
        
        while ($row = $result->fetch_assoc()) {
            $borrowings[] = $row;
        }
        
        return $borrowings;
    }
    
    public static function getPendingRequests($conn) {
        return self::getAll($conn, ['approval_status' => 'pending']);
    }
    
    public static function getUserBorrowings($conn, $user_id) {
        return self::getAll($conn, ['user_id' => $user_id]);
    }
    
    public static function getOverdueBorrowings($conn) {
        $overdue_borrowings = [];
        
        $sql = "SELECT 
                b.*,
                e.name as equipment_name, 
                e.equipment_code,
                u.first_name, 
                u.last_name, 
                u.email
                FROM borrowings b
                JOIN equipment e ON b.equipment_id = e.equipment_id
                JOIN users u ON b.user_id = u.user_id
                WHERE b.status = 'active' 
                AND b.due_date < NOW()
                ORDER BY b.due_date ASC";
        
        $result = $conn->query($sql);
        
        while ($row = $result->fetch_assoc()) {
            $overdue_borrowings[] = $row;
        }
        
        return $overdue_borrowings;
    }
    
    public static function getEquipmentBorrowingHistory($conn, $equipment_id, $limit = 10) {
        $history = [];
        
        $sql = "SELECT b.*, 
                u.first_name, u.last_name, u.email
                FROM borrowings b
                JOIN users u ON b.user_id = u.user_id
                WHERE b.equipment_id = ?
                ORDER BY b.borrow_date DESC
                LIMIT ?";
                
        $stmt = $conn->prepare($sql);
        if ($stmt === false) {
            return $history;
        }
        
        $limit_value = (int)$limit;
        $stmt->bind_param("ii", $equipment_id, $limit_value);
        $stmt->execute();
        $result = $stmt->get_result();
        
        while ($row = $result->fetch_assoc()) {
            $history[] = $row;
        }
        
        return $history;
    }
}

?>