<?php
class SentimentAnalysis {
    private $positiveWords = [
        'good', 'great', 'excellent', 'amazing', 'fantastic', 'wonderful', 'satisfied',
        'happy', 'perfect', 'love', 'awesome', 'impressive', 'exceptional', 'delighted',
        'exceeded', 'enjoy', 'pleased', 'superb', 'nice', 'brilliant', 'outstanding',
        'thank', 'thanks', 'clean', 'working', 'functional', 'fine', 'well'
    ];
    
    private $negativeWords = [
        'bad', 'poor', 'terrible', 'horrible', 'disappointed', 'awful', 'broken',
        'damaged', 'defective', 'slow', 'issue', 'problem', 'malfunction', 'fault',
        'complaint', 'failed', 'worse', 'worst', 'difficult', 'unhappy', 'frustrating',
        'dissatisfied', 'waste', 'error', 'mistake', 'never', 'hate', 'missing',
        'regret', 'sad', 'annoying', 'not working', 'doesn\'t work'
    ];

    private $intensifiers = [
        'very', 'extremely', 'absolutely', 'completely', 'totally', 'highly', 'really',
        'so', 'quite', 'entirely', 'especially'
    ];
    
    public function analyze($text) {
        if (empty($text)) {
            return [
                'polarity' => 0,
                'sentiment' => 'Neutral'
            ];
        }
        
        $text = strtolower($text);
        $words = preg_split('/\s+/', $text);
        
        $score = 0;
        $totalWords = count($words);
        
        if ($totalWords == 0) {
            return [
                'polarity' => 0,
                'sentiment' => 'Neutral'
            ];
        }
        
        $intensifyNext = false;
        
        foreach ($words as $index => $word) {
            $word = preg_replace('/[^\w\s]/', '', $word);
            
            if (in_array($word, $this->intensifiers)) {
                $intensifyNext = true;
                continue;
            }
            
            $wordScore = 0;
            
            if (in_array($word, $this->positiveWords)) {
                $wordScore = 1;
            } elseif (in_array($word, $this->negativeWords)) {
                $wordScore = -1;
            }
            
            if ($wordScore != 0) {
                for ($i = max(0, $index - 3); $i < $index; $i++) {
                    if (isset($words[$i])) {
                        $prevWord = preg_replace('/[^\w\s]/', '', strtolower($words[$i]));
                        if (in_array($prevWord, ['not', 'no', 'never', 'don\'t', 'doesn\'t', 'isn\'t', 'aren\'t', 'wasn\'t', 'weren\'t'])) {
                            $wordScore *= -1;
                            break;
                        }
                    }
                }
            }
            
            if ($intensifyNext && $wordScore != 0) {
                $wordScore *= 2;
                $intensifyNext = false;
            }
            
            $score += $wordScore;
        }

        $polarity = $totalWords > 0 ? $score / $totalWords : 0;
        
        if ($polarity > 0.1) {
            $sentiment = 'Positive';
        } elseif ($polarity < -0.1) {
            $sentiment = 'Negative';
        } else {
            $sentiment = 'Neutral';
        }
        
        return [
            'polarity' => $polarity,
            'sentiment' => $sentiment
        ];
    }
    
    public function getPolarityColor($polarity) {
        if ($polarity > 0.5) {
            return '#28a745'; // Strong positive - green
        } elseif ($polarity > 0) {
            return '#8bc34a'; // Mild positive - light green
        } elseif ($polarity < -0.5) {
            return '#dc3545'; // Strong negative - red
        } elseif ($polarity < 0) {
            return '#ff9800'; // Mild negative - orange
        } else {
            return '#6c757d'; // Neutral - gray
        }
    }
}
?>