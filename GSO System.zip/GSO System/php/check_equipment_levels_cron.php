<?php

ob_implicit_flush(true);
ob_end_flush();

set_time_limit(0);

function logMessage($message) {
    $date = date('Y-m-d H:i:s');
    echo "[$date] $message" . PHP_EOL;
    
    $logFile = __DIR__ . '/logs/equipment_levels_' . date('Y-m-d') . '.log';
    $dir = dirname($logFile);
    if (!is_dir($dir)) {
        mkdir($dir, 0755, true);
    }
    
    file_put_contents($logFile, "[$date] $message" . PHP_EOL, FILE_APPEND);
}

if (php_sapi_name() !== 'cli') {
    $validToken = '3quipm3nt-ch3ck-t0k3n'; // More secure token
    
    if (!isset($_GET['token']) || $_GET['token'] !== $validToken) {
        header('HTTP/1.0 403 Forbidden');
        echo "Access denied";
        exit;
    }
    
    header('Content-Type: text/plain');
}

require_once __DIR__ . '/db_connection.php';
require_once __DIR__ . '/borrowings/EquipmentThreshold.php';

logMessage("Starting equipment level check...");
$result = checkEquipmentQuantityLevels($conn);

if (!empty($result)) {
    logMessage("Found " . count($result) . " equipment items at critical levels.");
} else {
    logMessage("No equipment at critical levels found.");
}

logMessage("Equipment level check completed.");

logMessage("Starting equipment levels check");

try {
    $baseDir = __DIR__;
    require_once $baseDir . '/db_connection.php';
    require_once $baseDir . '/borrowings/EquipmentThreshold.php';
    
    logMessage("Running equipment quantity check");
    $criticalItems = checkEquipmentQuantityLevels($conn);
    
    $itemCount = count($criticalItems);
    logMessage("Check completed. Found $itemCount items with critical levels");
    
    if ($itemCount > 0) {
        logMessage("Critical items:");
        foreach ($criticalItems as $item) {
            logMessage("  - {$item['name']} (ID: {$item['id']}): {$item['available_quantity']}/{$item['quantity']}");
        }
    }
    
    $conn->close();
    
    logMessage("Equipment level check completed successfully");
} catch (Exception $e) {
    logMessage("ERROR: " . $e->getMessage());
    logMessage("Stack trace: " . $e->getTraceAsString());
    exit(1);
}

exit(0);