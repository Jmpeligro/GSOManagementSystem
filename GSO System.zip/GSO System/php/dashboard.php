<?php
session_start();
require_once 'db_connection.php';
require_once 'helpers.php';
require_once __DIR__ . '/classes/Borrowing/BorrowingSentiment.php';

if (!isLoggedIn()) {
    header("Location: login.php");
    exit();
}

$available_count = 0;
$borrowed_count = 0;
$maintenance_count = 0;
$categories_count = 0;
$critical_count = 0;
$result_critical_list = null;
$result_recent = null;
$sentiment_summary = [
    'sentiment_counts' => ['Positive' => 0, 'Neutral' => 0, 'Negative' => 0],
    'overall_sentiment' => 'Neutral',
    'average_polarity' => 0,
    'condition_sentiment' => []
];
$recent_sentiments = ['data' => []];
$monthly_labels = [];
$monthly_positive = [];
$monthly_neutral = [];
$monthly_negative = [];
$monthly_polarity = [];
$condition_labels = [];
$condition_positive = [];
$condition_neutral = [];
$condition_negative = [];

if (isAdmin()) {    $sql_maintenance = "SELECT COUNT(*) as count 
                        FROM maintenance m 
                        WHERE m.status != 'completed' AND m.status != 'cancelled';";
    $sql_borrowed = "SELECT COUNT(DISTINCT e.equipment_id) as count 
                    FROM equipment e 
                    INNER JOIN borrowings b ON e.equipment_id = b.equipment_id 
                    WHERE b.status = 'active'";
                    
    $sql_available = "SELECT COUNT(*) as count 
                     FROM equipment e 
                     WHERE e.status = 'available' 
                     AND NOT EXISTS (
                         SELECT 1 FROM maintenance m 
                         WHERE m.equipment_id = e.equipment_id 
                         AND m.status NOT IN ('completed', 'cancelled')
                     )";
                     
    $sql_categories = "SELECT COUNT(*) as count FROM categories";

    $sql_critical = "SELECT COUNT(DISTINCT e.equipment_id) as count 
                    FROM equipment e 
                    WHERE e.status != 'retired' AND (
                        (e.quantity = 1 AND e.available_quantity = 0)
                        OR 
                        (e.quantity > 1 AND e.available_quantity <= (e.quantity / 2))
                    )";

    $result_available = $conn->query($sql_available);
    $result_borrowed = $conn->query($sql_borrowed);
    $result_maintenance = $conn->query($sql_maintenance);
    $result_categories = $conn->query($sql_categories);
    $result_critical = $conn->query($sql_critical);

    $available_count = $result_available->fetch_assoc()['count'];
    $borrowed_count = $result_borrowed->fetch_assoc()['count'];
    $maintenance_count = $result_maintenance->fetch_assoc()['count'];
    $categories_count = $result_categories->fetch_assoc()['count'];
    $critical_count = $result_critical->fetch_assoc()['count'];

    $sql_critical_list = "SELECT e.*, 
                            CASE 
                                WHEN e.status = 'maintenance' THEN 'Under Maintenance/Critical'
                                WHEN e.status = 'partially_both' THEN 'Partially Both/Critical'
                                WHEN e.status = 'partially_maintenance' THEN 'Partially Maintenance/Critical'
                                WHEN e.available_quantity = 0 THEN 'Borrowed/Critical'
                                WHEN e.available_quantity > 0 AND e.available_quantity < e.quantity THEN 'Partially Borrowed/Critical'
                                ELSE 'Critical Stock'
                            END as critical_reason
                        FROM equipment e 
                        WHERE e.status != 'retired' AND (
                            (e.quantity = 1 AND e.available_quantity = 0)
                            OR 
                            (e.quantity > 1 AND e.available_quantity <= (e.quantity / 2))
                        )
                        ORDER BY e.available_quantity ASC
                        LIMIT 5";
    $result_critical_list = $conn->query($sql_critical_list);

    $sql_recent = "SELECT b.borrowing_id, e.name as equipment_name, 
                u.first_name, u.last_name, b.borrow_date, b.due_date, b.status
                FROM borrowings b
                JOIN equipment e ON b.equipment_id = e.equipment_id
                JOIN users u ON b.user_id = u.user_id
                ORDER BY b.created_at DESC
                LIMIT 5";
    $result_recent = $conn->query($sql_recent);

    $sentimentAnalyzer = new BorrowingSentiment($conn);

    $sentiment_summary = $sentimentAnalyzer->getSentimentSummary();

    $recent_sentiments = $sentimentAnalyzer->getReturnNotesSentiment(5);

    $monthly_trends = $sentimentAnalyzer->getMonthlySentimentTrends(6);

    if (isset($monthly_trends['success']) && $monthly_trends['success']) {
        foreach ($monthly_trends['monthly_data'] as $month => $data) {
            // Format month for display (e.g., "2023-05" -> "May 2023")
            $date = new DateTime($month . '-01');
            $formatted_month = $date->format('M Y');
            
            $monthly_labels[] = $formatted_month;
            $monthly_positive[] = $data['positive'];
            $monthly_neutral[] = $data['neutral'];
            $monthly_negative[] = $data['negative'];
            $monthly_polarity[] = $data['avg_polarity'];
        }
    }

    if (isset($sentiment_summary['condition_sentiment'])) {
        $condition_sentiment = $sentiment_summary['condition_sentiment'];
        $condition_labels = array_keys($condition_sentiment);
        
        foreach ($condition_sentiment as $condition => $values) {
            $condition_positive[] = isset($values['Positive']) ? $values['Positive'] : 0;
            $condition_neutral[] = isset($values['Neutral']) ? $values['Neutral'] : 0;
            $condition_negative[] = isset($values['Negative']) ? $values['Negative'] : 0;
        }
    }
} else {

    $user_id = $_SESSION['user_id'];
    
    $sql_available = "SELECT COUNT(*) as count FROM equipment WHERE status = 'available'";
    $sql_borrowed = "SELECT COUNT(*) as count FROM equipment WHERE status = 'borrowed'";
    $sql_maintenance = "SELECT COUNT(*) as count FROM equipment WHERE status = 'maintenance'";
    $sql_categories = "SELECT COUNT(*) as count FROM categories";

    $result_available = $conn->query($sql_available);
    $result_borrowed = $conn->query($sql_borrowed);
    $result_maintenance = $conn->query($sql_maintenance);
    $result_categories = $conn->query($sql_categories);

    $available_count = $result_available->fetch_assoc()['count'];
    $borrowed_count = $result_borrowed->fetch_assoc()['count'];
    $maintenance_count = $result_maintenance->fetch_assoc()['count'];
    $categories_count = $result_categories->fetch_assoc()['count'];
    
    $sql_recent = "SELECT b.borrowing_id, e.name as equipment_name, 
                u.first_name, u.last_name, b.borrow_date, b.due_date, b.status
                FROM borrowings b
                JOIN equipment e ON b.equipment_id = e.equipment_id
                JOIN users u ON b.user_id = u.user_id
                WHERE b.user_id = ?
                ORDER BY b.created_at DESC
                LIMIT 5";
    
    $stmt = $conn->prepare($sql_recent);
    $stmt->bind_param("i", $user_id);
    $stmt->execute();
    $result_recent = $stmt->get_result();
}

include '../pages/dashboard.html';
?>