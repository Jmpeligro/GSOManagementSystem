function openAddUserModal() {
    document.getElementById('addUserModal').style.display = 'block';
    document.body.style.overflow = 'hidden';
}

function closeAddUserModal() {
    document.getElementById('addUserModal').style.display = 'none';
    document.body.style.overflow = 'auto';
}

window.onclick = function(event) {
    const modal = document.getElementById('addUserModal');
    if (event.target === modal) {
        closeAddUserModal();
    }
}

document.addEventListener('DOMContentLoaded', function() {
    const addUserForm = document.querySelector('#addUserForm form');
    if (addUserForm) {
        addUserForm.addEventListener('submit', function(e) {
            e.preventDefault();
            fetch(this.action, {
                method: 'POST',
                body: new FormData(this)
            })
            .then(response => response.text())
            .then(data => {e
                if (data.includes('success')) {
                    closeAddUserModal();
                    location.reload();
                } else {
                    document.getElementById('addUserForm').innerHTML = data;
                }
            })
            .catch(error => {
                console.error('Error:', error);
            });
        });
    }
});
