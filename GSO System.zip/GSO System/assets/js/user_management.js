document.addEventListener('DOMContentLoaded', function() {
    // Function to validate PLP email domain
    function validatePLPEmail(email) {
        return /@plpasig\.edu\.ph$/i.test(email);
    }

    // Function to handle email validation
    function validateEmailField(inputField) {
        const email = inputField.value.trim();
        let errorElement = inputField.parentElement.querySelector('.email-error');
        
        if (!errorElement) {
            errorElement = document.createElement('div');
            errorElement.className = 'email-error text-danger small mt-1';
            inputField.parentElement.appendChild(errorElement);
        }

        if (email) {
            if (!validatePLPEmail(email)) {
                errorElement.textContent = 'Please use a PLP institutional email (@plpasig.edu.ph)';
                inputField.classList.add('is-invalid');
                return false;
            } else {
                errorElement.textContent = '';
                inputField.classList.remove('is-invalid');
                return true;
            }
        }
        return true;
    }

    // Add validation to email input
    const emailField = document.querySelector('input[type="email"]');
    if (emailField) {
        emailField.addEventListener('input', function() {
            validateEmailField(this);
        });
        
        emailField.addEventListener('blur', function() {
            validateEmailField(this);
        });
    }

    // Form validation
    const form = document.querySelector('.user-form');
    if (form) {
        form.addEventListener('submit', function(event) {
            const emailInput = form.querySelector('input[type="email"]');
            if (emailInput && !validateEmailField(emailInput)) {
                event.preventDefault();
                event.stopPropagation();
            }
        });
    }

    // Role selection functionality
    const roleSelect = document.getElementById('role');
    const programYearSectionContainer = document.getElementById('program_year_section_container');
    const programYearSectionInput = document.getElementById('program_year_section');
    
    if (roleSelect) {
        roleSelect.addEventListener('change', function() {
            if (this.value === 'student') {
                programYearSectionContainer.style.display = 'block';
                programYearSectionInput.required = true;
            } else {
                programYearSectionContainer.style.display = 'none';
                programYearSectionInput.required = false;
            }
        });
    }
});
