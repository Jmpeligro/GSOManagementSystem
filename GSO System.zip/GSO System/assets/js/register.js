document.addEventListener('DOMContentLoaded', function() {
    // Function to validate PLP email domain
    function validatePLPEmail(email) {
        return /@plpasig\.edu\.ph$/i.test(email);
    }

    // Function to handle email validation
    function validateEmailField(inputField) {
        const email = inputField.value.trim();
        let errorElement = inputField.parentElement.querySelector('.email-error');
        
        if (!errorElement) {
            errorElement = document.createElement('div');
            errorElement.className = 'email-error text-danger small mt-1';
            inputField.parentElement.appendChild(errorElement);
        }

        if (email) {
            if (!validatePLPEmail(email)) {
                errorElement.textContent = 'Please use your PLP institutional email (@plpasig.edu.ph)';
                inputField.classList.add('is-invalid');
                return false;
            } else {
                errorElement.textContent = '';
                inputField.classList.remove('is-invalid');
                return true;
            }
        }
        return true;
    }

    // Add validation to all email inputs
    const emailFields = document.querySelectorAll('input[type="email"]');
    emailFields.forEach(field => {
        field.addEventListener('input', function() {
            validateEmailField(this);
        });
        
        field.addEventListener('blur', function() {
            validateEmailField(this);
        });
    });

    // Form validation
    const forms = document.querySelectorAll('.needs-validation')
    Array.prototype.slice.call(forms).forEach(function(form) {
        form.addEventListener('submit', function(event) {
            let isValid = true;
            
            // Validate all email fields before submit
            const emailInputs = form.querySelectorAll('input[type="email"]');
            emailInputs.forEach(input => {
                if (!validateEmailField(input)) {
                    isValid = false;
                }
            });

            if (!form.checkValidity() || !isValid) {
                event.preventDefault();
                event.stopPropagation();
            }
            
            form.classList.add('was-validated');
        }, false);
    });

    // Additional functionality for role selection (preserve existing code)
    const roleSelect = document.getElementById('role');
    const programYearSectionContainer = document.getElementById('program_year_section_container');
    const programYearSectionInput = document.getElementById('program_year_section');
    
    if (roleSelect) {
        roleSelect.addEventListener('change', function() {
            if (this.value === 'student') {
                programYearSectionContainer.style.display = 'block';
                programYearSectionInput.required = true;
            } else {
                programYearSectionContainer.style.display = 'none';
                programYearSectionInput.required = false;
            }
        });
    }
});