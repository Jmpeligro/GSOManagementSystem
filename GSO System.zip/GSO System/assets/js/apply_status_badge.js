document.addEventListener("DOMContentLoaded", function() {
    const statusBadges = document.querySelectorAll('.status-badge');
    
    statusBadges.forEach(badge => {
        const status = badge.textContent.trim().toLowerCase();
        
        badge.classList.forEach(className => {
            if (className.startsWith('status-') && className !== 'status-badge') {
                badge.classList.remove(className);
            }
        });
        
        badge.classList.add(`status-${status}`);
    });
    
    function addStatusChangeAnimation() {
        const updatedStatus = document.querySelector('.status-updated');
        if (updatedStatus) {
            updatedStatus.classList.add('status-change-animation');
            setTimeout(() => {
                updatedStatus.classList.remove('status-change-animation');
                updatedStatus.classList.remove('status-updated');
            }, 1500);
        }
    }

});