function confirmDelete(id, name) {
  return confirm(
    'Are you sure you want to delete the maintenance record for "' +
      name +
      '"? This action cannot be undone.'
  );
}

function showAddMaintenanceForm() {
  document.getElementById("addMaintenanceModal").style.display = "block";
}

function closeAddMaintenanceForm() {
  document.getElementById("addMaintenanceModal").style.display = "none";
}

function showUpdateForm(id) {
  document.getElementById("updateForm" + id).style.display = "block";
}

function closeUpdateForm(id) {
  document.getElementById("updateForm" + id).style.display = "none";
}

function validateCost(input) {
  input.value = input.value.replace(/[^0-9.]/g, "");

  const parts = input.value.split(".");
  if (parts.length > 2) {
    input.value = parts[0] + "." + parts.slice(1).join("");
  }
}

function updateMaxQuantity(equipmentId) {
  const select = document.getElementById("equipment_id");
  const option = select.selectedOptions[0];
  const quantityInput = document.getElementById("quantity");
  const maxQuantitySpan = document.getElementById("max-quantity");

  if (equipmentId && option) {
    const availableQuantity = option.getAttribute("data-available");
    maxQuantitySpan.textContent = availableQuantity;
    quantityInput.max = availableQuantity;

    if (parseInt(quantityInput.value) > parseInt(availableQuantity)) {
      quantityInput.value = availableQuantity;
    }
  } else {
    maxQuantitySpan.textContent = "-";
    quantityInput.value = "1";
    quantityInput.max = "";
  }
}

// Enhanced JavaScript for filtering functionality
let allRows = [];
let uniqueEquipment = new Set();

// Initialize filters when page loads
document.addEventListener("DOMContentLoaded", function () {
  initializeFilters();
});

function initializeFilters() {
  const rows = document.querySelectorAll(".maintenance-row");
  allRows = Array.from(rows);

  // Collect unique equipment for dropdown
  allRows.forEach((row) => {
    const equipmentText = row.cells[0].textContent.trim();
    uniqueEquipment.add(equipmentText);
  });

  // Populate equipment filter dropdown
  const equipmentFilter = document.getElementById("equipmentFilter");
  uniqueEquipment.forEach((equipment) => {
    const option = document.createElement("option");
    option.value = equipment.toLowerCase();
    option.textContent = equipment;
    equipmentFilter.appendChild(option);
  });

  updateResultsInfo();
}
function applyFilters() {
  const searchTerm = document
    .getElementById("searchFilter")
    .value.toLowerCase();
  const equipmentFilter = document
    .getElementById("equipmentFilter")
    .value.toLowerCase();
  const statusFilter = document
    .getElementById("statusFilter")
    .value.toLowerCase();

  let visibleCount = 0;

  allRows.forEach((row) => {
    let show = true;

    // Search filter
    if (searchTerm) {
      const equipment = row.dataset.equipment;
      const equipmentCode = row.dataset.equipmentCode;
      const issue = row.dataset.issue;

      if (
        !equipment.includes(searchTerm) &&
        !equipmentCode.includes(searchTerm) &&
        !issue.includes(searchTerm)
      ) {
        show = false;
      }
    }

    // Equipment filter
    if (equipmentFilter && show) {
      const rowEquipment = row.cells[0].textContent.toLowerCase();
      if (!rowEquipment.includes(equipmentFilter)) {
        show = false;
      }
    }

    // Status filter
    if (statusFilter && show) {
      if (row.dataset.status !== statusFilter) {
        show = false;
      }
    }

    // Show/hide row
    row.style.display = show ? "" : "none";
    if (show) visibleCount++;
  });

  updateResultsInfo(visibleCount);

  // Show/hide no results message
  const noResultsMsg = document.getElementById("noResultsMessage");
  const table = document.getElementById("maintenanceTable");

  if (visibleCount === 0 && allRows.length > 0) {
    noResultsMsg.style.display = "block";
    table.style.display = "none";
  } else {
    noResultsMsg.style.display = "none";
    table.style.display = "table";
  }
}
function clearFilters() {
  // Clear all filter inputs
  document.getElementById("searchFilter").value = "";
  document.getElementById("equipmentFilter").value = "";
  document.getElementById("statusFilter").value = "";

  // Show all rows
  allRows.forEach((row) => {
    row.style.display = "";
  });

  updateResultsInfo();

  // Hide no results message and show table
  document.getElementById("noResultsMessage").style.display = "none";
  document.getElementById("maintenanceTable").style.display = "table";
}

function updateResultsInfo(visibleCount = null) {
  const totalCount = allRows.length;
  const visible = visibleCount !== null ? visibleCount : totalCount;

  document.getElementById("totalCount").textContent = totalCount;
  document.getElementById("visibleCount").textContent = visible;

  const resultsInfo = document.getElementById("resultsInfo");
  if (visible < totalCount) {
    resultsInfo.style.display = "block";
  } else {
    resultsInfo.style.display = "none";
  }
}

function toggleFilters() {
  const filterSection = document.getElementById("filterSection");
  const toggleIcon = document.getElementById("filterToggleIcon");

  filterSection.classList.toggle("collapsed");

  if (filterSection.classList.contains("collapsed")) {
    toggleIcon.className = "fas fa-chevron-right";
  } else {
    toggleIcon.className = "fas fa-chevron-down";
  }
}

// Add keyboard shortcuts
document.addEventListener("keydown", function (e) {
  // Ctrl/Cmd + F to focus search
  if ((e.ctrlKey || e.metaKey) && e.key === "f") {
    e.preventDefault();
    document.getElementById("searchFilter").focus();
  }

  // Escape to clear filters
  if (e.key === "Escape") {
    clearFilters();
  }
});
