<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}
include_once $_SERVER['DOCUMENT_ROOT'] . '/GSO System/php/db_connection.php';

$page_title = ucwords(str_replace('_', ' ', pathinfo(basename($_SERVER['PHP_SELF']), PATHINFO_FILENAME)));

$initials = 'G';
if(isset($_SESSION['first_name'], $_SESSION['last_name'])) {
    $initials = strtoupper(substr($_SESSION['first_name'], 0, 1) . substr($_SESSION['last_name'], 0, 1));
}

if (!function_exists('isAdmin')) {
    function isAdmin() {
        return isset($_SESSION['role']) && $_SESSION['role'] === 'admin';
    }
}

if (!function_exists('isBorrower')) {
    function isBorrower() {
        $is_borrower = isset($_SESSION['role']) && $_SESSION['role'] === 'borrower';
        error_log('isBorrower check - Role: ' . ($_SESSION['role'] ?? 'not set') . ', Is Borrower: ' . ($is_borrower ? 'true' : 'false'));
        return $is_borrower;
    }
}

$menu_items = [];

if (isAdmin()) {
    $menu_items[] = ['url' => '/GSO System/php/dashboard.php', 'icon' => 'grid', 'label' => 'Dashboard'];
} else {
    $menu_items[] = ['url' => '/GSO System/php/dashboard_borrower.php', 'icon' => 'grid', 'label' => 'Dashboard'];
}

$menu_items = array_merge($menu_items, [    ['url' => '/GSO System/php/equipment/equipment.php', 'icon' => 'tool', 'label' => 'Equipment'],
    ['url' => '/GSO System/php/borrowings/borrowings.php', 'icon' => 'book', 'label' => 'Borrowings'],
    ['url' => '/GSO System/php/categories/categories.php', 'icon' => 'list', 'label' => 'Categories', 'admin_only' => true],
    ['url' => '/GSO System/php/users/users.php', 'icon' => 'users', 'label' => 'Users', 'admin_only' => true],
    ['url' => '/GSO System/php/reports.php', 'icon' => 'file-text', 'label' => 'Reports', 'admin_only' => true]
]);

if (!function_exists('getIcon')) {  
    function getIcon($name) {
        return '<i data-feather="' . $name . '"></i>';
    }
}
?>

    
<aside class="sidebar">
    <div class="sidebar-header">
        <div class="logo">
            <a href="/GSO System/php/index.php">PLP GSO Management</a>
        </div>
        <button class="sidebar-toggle" id="sidebarToggle" aria-label="Toggle Sidebar">
            <?php echo getIcon('menu'); ?>
        </button>
    </div>
    
    <div class="sidebar-content">
        <nav class="sidebar-menu">            
            <?php foreach($menu_items as $item): ?>
                <?php
                $show_item = true;
                if (isset($item['admin_only']) && $item['admin_only'] && !isAdmin()) {
                    $show_item = false;
                    error_log('Hide admin item: ' . $item['label']);
                }
                if (isset($item['borrower_only']) && $item['borrower_only'] && !isBorrower()) {
                    $show_item = false;
                    error_log('Hide borrower item: ' . $item['label']);
                }
                if ($show_item):
                    error_log('Showing menu item: ' . $item['label']);
                ?>
                    <a href="<?php echo $item['url']; ?>" class="sidebar-link">
                        <?php echo getIcon($item['icon']); ?>
                        <span><?php echo $item['label']; ?></span>
                    </a>
                <?php endif; ?>
            <?php endforeach; ?>
        </nav>
    </div>
    
    <div class="sidebar-footer">
        <div class="user-profile" id="userProfile">
            <div class="user-avatar"><?php echo $initials; ?></div>
            <div class="user-info">
                <span class="user-name">
                    <?php echo isset($_SESSION['first_name'], $_SESSION['last_name']) ? 
                        $_SESSION['first_name'] . ' ' . $_SESSION['last_name'] : 'Guest'; ?>
                </span>
                <?php echo getIcon('chevron-down'); ?>
            </div>
        </div>
        <div class="user-menu-dropdown" id="userMenuDropdown">
            <a href="/GSO System/php/logout.php"><?php echo getIcon('log-out'); ?> Logout</a>
        </div>
    </div>
</aside>

<div class="content-wrapper">
    <div class="top-bar">
        <button class="sidebar-toggle" id="mobileToggle" aria-label="Toggle Mobile Menu">
            <?php echo getIcon('menu'); ?>
        </button>
        <h1 class="page-title"><?php echo $page_title; ?></h1>
    </div>

<script src="https://cdn.jsdelivr.net/npm/feather-icons/dist/feather.min.js"></script>
<script>
    document.addEventListener('DOMContentLoaded', function() {
        if (typeof feather !== 'undefined') {
            feather.replace();
        } else {
            console.error('Feather icons library not loaded');
        }
    });
</script>
<script src="../assets/js/sidebar.js"></script>