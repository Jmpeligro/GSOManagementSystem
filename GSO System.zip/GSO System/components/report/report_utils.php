<?php

function formatDate($date) {
    if (empty($date) || $date == '0000-00-00') {
        return 'N/A';
    }
    return date('M d, Y', strtotime($date));
}

function getCategoryName($conn, $category_id) {
    $sql = "SELECT name FROM categories WHERE category_id = " . $conn->real_escape_string($category_id);
    $result = $conn->query($sql);
    if ($result && $result->num_rows > 0) {
        $row = $result->fetch_assoc();
        return $row['name'];
    }
    return 'Unknown';
}

function getUserName($conn, $user_id) {
    $sql = "SELECT CONCAT(first_name, ' ', last_name) as name FROM users WHERE user_id = " . $conn->real_escape_string($user_id);
    $result = $conn->query($sql);
    if ($result && $result->num_rows > 0) {
        $row = $result->fetch_assoc();
        return $row['name'];
    }
    return 'Unknown';
}

function handleSqlError($conn, $context) {
    error_log("SQL Error in $context: " . $conn->error);
    return "An error occurred while generating the report. Please try again later.";
}

function calculateColumnWidths($headers, $data, $page_width) {
    $total_width = $page_width - 20; 
    $column_count = count($headers);
    $widths = array();

    for ($i = 0; $i < $column_count; $i++) {
        $widths[$i] = strlen($headers[$i]) * 2.5; 
    }
    
    foreach ($data as $row) {
        for ($i = 0; $i < $column_count; $i++) {
            if (isset($row[$i])) {
                $content_width = strlen($row[$i]) * 1.8; 
                if ($content_width > $widths[$i]) {
                    $widths[$i] = min($content_width, $total_width / 3); 
                }
            }
        }
    }
    
    $total_calculated = array_sum($widths);
    if ($total_calculated > $total_width) {
        $scale_factor = $total_width / $total_calculated;
        for ($i = 0; $i < $column_count; $i++) {
            $widths[$i] *= $scale_factor;
        }
    }
    
    return $widths;
}

function truncateText($text, $max_length = 50) {
    if (strlen($text) <= $max_length) {
        return $text;
    }
    return substr($text, 0, $max_length - 3) . '...';
}

function addSignatureFields($pdf) {
    $pdf->Ln(50);
    
    $pdf->SetFont('Arial', '', 10);
    
    $pageWidth = $pdf->GetPageWidth();
    $marginLeft = 15;
    $sectionWidth = ($pageWidth - (2 * $marginLeft)) / 2; 
    

    $pdf->SetX($marginLeft);
    $pdf->Cell($sectionWidth, 5, 'Requested by:', 0, 0, 'L');
    
    $pdf->SetX($marginLeft + $sectionWidth);
    $pdf->Cell($sectionWidth, 5, 'Inspected by:', 0, 1, 'L');

    $pdf->Ln(10);
    $pdf->SetX($marginLeft);
    $pdf->Line($marginLeft, $pdf->GetY(), $marginLeft + ($sectionWidth - 20), $pdf->GetY());
    $pdf->SetX($marginLeft + $sectionWidth);
    $pdf->Line($marginLeft + $sectionWidth, $pdf->GetY(), $marginLeft + (2 * $sectionWidth - 20), $pdf->GetY());
    
    $pdf->Ln(5);
    $pdf->SetX($marginLeft);
    $pdf->Cell($sectionWidth, 5, 'Signature over printed name', 0, 0, 'L');
    $pdf->SetX($marginLeft + $sectionWidth);
    $pdf->Cell($sectionWidth, 5, 'RICHARD L. SEÑASE', 0, 1, 'L');
    $pdf->SetX($marginLeft + $sectionWidth);
    $pdf->Cell($sectionWidth, 5, 'Property Custodian', 0, 1, 'L');
    
    $pdf->Ln(10);
    
    $pdf->SetX($marginLeft);
    $pdf->Cell($sectionWidth, 5, 'Endorsed by:', 0, 0, 'L');
    
    $pdf->SetX($marginLeft + $sectionWidth);
    $pdf->Cell($sectionWidth, 5, 'Approved:', 0, 1, 'L');
    
    $pdf->Ln(10);
    $pdf->SetX($marginLeft);
    $pdf->Line($marginLeft, $pdf->GetY(), $marginLeft + ($sectionWidth - 20), $pdf->GetY());
    $pdf->SetX($marginLeft + $sectionWidth);
    $pdf->Line($marginLeft + $sectionWidth, $pdf->GetY(), $marginLeft + (2 * $sectionWidth - 20), $pdf->GetY());
    
    $pdf->Ln(5);
    $pdf->SetX($marginLeft);
    $pdf->Cell($sectionWidth, 5, 'Signature over printed name', 0, 0, 'L');
    $pdf->SetX($marginLeft + $sectionWidth);
    $pdf->Cell($sectionWidth, 5, 'OSCAR B. CORNEJO JR.', 0, 1, 'L');
    
    $pdf->SetX($marginLeft);
    $pdf->Cell($sectionWidth, 5, 'Property Accountable Person', 0, 0, 'L');
    $pdf->SetX($marginLeft + $sectionWidth);
    $pdf->Cell($sectionWidth, 5, 'PLP GSO Director', 0, 1, 'L');
    
}