<?php
session_start();
require_once '../../php/db_connection.php';
require_once '../fpdf/fpdf.php';
require_once 'report_utils.php';

if (!isLoggedIn() || !isAdmin()) {
    header("Location: ../../php/index.php");
    exit();
}

class PDF extends FPDF {
    function Header() {
        $this->Image('../../assets/images/logo.png', 10, 6, 30);
        $this->SetFont('Arial', 'B', 15);
        $this->Cell(80);
        $this->Cell(30, 10, 'PLP GSO Management System Report', 0, 0, 'C');
        $this->Ln(20);
    }
    
    function Footer() {
        $this->SetY(-15);
        $this->SetFont('Arial', 'I', 8);
        $this->Cell(0, 10, 'Page ' . $this->PageNo() . '/{nb}', 0, 0, 'C');
        $this->Cell(-30, 10, 'Generated on: ' . date('Y-m-d H:i:s'), 0, 0, 'R');
    }
      function TableHeader($header, $widths = array()) {
        $this->SetFont('Arial', 'B', 10);
        $this->SetFillColor(200, 220, 255);
        
        $page_width = $this->GetPageWidth() - 20; 
        
        if (empty($widths)) {
            $proportions = array(
                'Equipment ID' => 0.2,
                'Equipment Name' => 0.4,
                'Times Borrowed' => 0.2,
                'Category' => 0.3,
                'Department' => 0.3,
                'Number of Borrowings' => 0.3
            );
            
            $widths = array();
            foreach($header as $col) {
                $widths[] = $page_width * ($proportions[$col] ?? (1/count($header)));
            }
        }
        
        foreach($header as $i => $col) {
            $this->Cell($widths[$i], 7, $col, 1, 0, 'C', true);
        }
        $this->Ln();
        
        return $widths;
    }
      function TableRow($data, $widths) {
        $this->SetFont('Arial', '', 9);
        
        $maxHeight = 6;
        $x = $this->GetX();
        $y = $this->GetY();
        
        foreach($data as $i => $col) {
            $lines = $this->getNumLines($col, $widths[$i] - 2); 
            $cellHeight = $lines * 6;
            $maxHeight = max($maxHeight, $cellHeight);
        }
        
        foreach($data as $i => $col) {
            if ($i > 0) {
                $x += $widths[$i-1];
            }
            $this->SetXY($x, $y);
            
            $align = 'L';
            if (is_numeric($col)) {
                $align = 'R';
            } elseif (in_array($col, ['active', 'returned', 'overdue', 'pending', 'approved', 'rejected']) || 
                      preg_match('/^\d{4}-\d{2}-\d{2}$/', $col)) {
                $align = 'C';
            }
            
            $this->MultiCell($widths[$i], 6, $col, 1, $align);
            $this->SetXY($x + $widths[$i], $y);
        }
        
        $this->Ln($maxHeight);
    }
        function getNumLines($text, $width) {
        if (empty($text)) return 1;
        $this->SetFont('Arial', '', 9);
        $text_width = $this->GetStringWidth($text);
        return max(1, ceil($text_width / $width));
    }
}

$pdf = new PDF();
$pdf->AliasNbPages();
$pdf->AddPage();
$pdf->SetFont('Arial', '', 12);

try {
    generateUsageReport($pdf, $conn);
} catch (Exception $e) {
    error_log("Error generating usage report: " . $e->getMessage());
    $pdf->Cell(0, 10, 'An error occurred while generating the report: ' . $e->getMessage(), 0, 1, 'C');
    $pdf->Output('usage_report_error.pdf', 'D');
    exit();
}

function generateUsageReport($pdf, $conn) {
    $pdf->SetFont('Arial', 'B', 14);
    $pdf->Cell(0, 10, 'Equipment Usage Report', 0, 1, 'C');
    $pdf->Ln(5);
    
    $period = isset($_POST['usage-period']) ? $_POST['usage-period'] : '';
    $date_from = '';
    $date_to = '';
    
    if ($period == 'custom') {
        $date_from = isset($_POST['usage-date-from']) ? $_POST['usage-date-from'] : '';
        $date_to = isset($_POST['usage-date-to']) ? $_POST['usage-date-to'] : '';
    } else {
        $today = date('Y-m-d');
        
        switch ($period) {
            case 'last-30':
                $date_from = date('Y-m-d', strtotime('-30 days'));
                $date_to = $today;
                break;
            case 'last-90':
                $date_from = date('Y-m-d', strtotime('-90 days'));
                $date_to = $today;
                break;
            case 'this-month':
                $date_from = date('Y-m-01');
                $date_to = date('Y-m-t');
                break;
            case 'last-month':
                $date_from = date('Y-m-01', strtotime('-1 month'));
                $date_to = date('Y-m-t', strtotime('-1 month'));
                $break;
            case 'this-year':
                $date_from = date('Y-01-01');
                $date_to = date('Y-12-31');
                break;
            default:
                break;
        }
    }
   
    $pdf->SetFont('Arial', 'B', 12);
    $pdf->Cell(0, 10, 'Most Borrowed Equipment', 0, 1, 'L');
    
    $sql_popular = "SELECT e.equipment_id, e.name, COUNT(b.borrowing_id) as borrow_count 
                    FROM equipment e 
                    LEFT JOIN borrowings b ON e.equipment_id = b.equipment_id 
                    WHERE 1=1";
    
    if (!empty($date_from)) {
        $sql_popular .= " AND b.borrow_date >= '" . $conn->real_escape_string($date_from) . "'";
    }
    
    if (!empty($date_to)) {
        $sql_popular .= " AND b.borrow_date <= '" . $conn->real_escape_string($date_to) . "'";
    }
    
    $sql_popular .= " GROUP BY e.equipment_id 
                    ORDER BY borrow_count DESC 
                    LIMIT 10";
    
    $result_popular = $conn->query($sql_popular);
    if (!$result_popular) {
        throw new Exception("SQL Error: " . $conn->error);
    }
    
    if ($result_popular->num_rows > 0) {
        $pdf->SetFont('Arial', 'I', 10);
        $filterText = 'Period: ';
        
        switch ($period) {
            case 'last-30':
                $filterText .= 'Last 30 Days';
                break;
            case 'last-90':
                $filterText .= 'Last 90 Days';
                break;
            case 'this-month':
                $filterText .= 'This Month';
                break;
            case 'last-month':
                $filterText .= 'Last Month';
                break;
            case 'this-year':
                $filterText .= 'This Year';
                break;
            case 'custom':
                $filterText .= 'From ' . formatDate($date_from) . ' To ' . formatDate($date_to);
                break;
            default:
                $filterText .= 'All Time';
                break;
        }
        
        $pdf->Cell(0, 5, $filterText, 0, 1, 'L');
        $pdf->Ln(5);
 
        $header = array('Equipment ID', 'Equipment Name', 'Times Borrowed');
        $widths = array(40, 100, 50); 
        $widths = $pdf->TableHeader($header, $widths);
 
        while ($row = $result_popular->fetch_assoc()) {
            $data = array(
                $row['equipment_id'],
                $row['name'],
                $row['borrow_count']
            );
            $pdf->TableRow($data, $widths);
        }
    } else {
        $pdf->SetFont('Arial', '', 10);
        $pdf->Cell(0, 10, 'No data available for the selected period.', 0, 1, 'C');
    }
    $pdf->Ln(10);

    $pdf->SetFont('Arial', 'B', 12);
    $pdf->Cell(0, 10, 'Usage by Category', 0, 1, 'L');

    $sql_categories = "SELECT c.name as category_name, COUNT(b.borrowing_id) as borrow_count 
                      FROM categories c 
                      LEFT JOIN equipment e ON c.category_id = e.category_id 
                      LEFT JOIN borrowings b ON e.equipment_id = b.equipment_id 
                      WHERE 1=1";

    if (!empty($date_from)) {
        $sql_categories .= " AND b.borrow_date >= '" . $conn->real_escape_string($date_from) . "'";
    }
    
    if (!empty($date_to)) {
        $sql_categories .= " AND b.borrow_date <= '" . $conn->real_escape_string($date_to) . "'";
    }
    
    $sql_categories .= " GROUP BY c.category_id 
                        ORDER BY borrow_count DESC";

    $result_categories = $conn->query($sql_categories);
    if (!$result_categories) {
        throw new Exception("SQL Error (categories): " . $conn->error);
    } else if ($result_categories->num_rows > 0) {
        $header = array('Category', 'Times Equipment Borrowed');
        $widths = array(120, 70); 
        $widths = $pdf->TableHeader($header, $widths);
        
        while ($row = $result_categories->fetch_assoc()) {
            $data = array(
                $row['category_name'],
                $row['borrow_count']
            );
            $pdf->TableRow($data, $widths);
        }
    } else {
        $pdf->SetFont('Arial', '', 10);
        $pdf->Cell(0, 10, 'No category statistics available for the selected period.', 0, 1, 'C');
    }

    $pdf->Ln(10);
    $pdf->SetFont('Arial', 'B', 12);
    $pdf->Cell(0, 10, 'Usage by Department', 0, 1, 'L');

    $sql_departments = "SELECT u.department, COUNT(b.borrowing_id) as borrow_count 
                      FROM users u 
                      JOIN borrowings b ON u.user_id = b.user_id 
                      WHERE 1=1";

    if (!empty($date_from)) {
        $sql_departments .= " AND b.borrow_date >= '" . $conn->real_escape_string($date_from) . "'";
    }
    
    if (!empty($date_to)) {
        $sql_departments .= " AND b.borrow_date <= '" . $conn->real_escape_string($date_to) . "'";
    }
    
    $sql_departments .= " GROUP BY u.department 
                        ORDER BY borrow_count DESC";

    $result_departments = $conn->query($sql_departments);
    if (!$result_departments) {
        throw new Exception("SQL Error (departments): " . $conn->error);
    } else if ($result_departments->num_rows > 0) {
        $header = array('Department', 'Number of Borrowings');
        $widths = array(120, 70); 
        $widths = $pdf->TableHeader($header, $widths);
        
        while ($row = $result_departments->fetch_assoc()) {
            $data = array(
                $row['department'] ?: 'Unknown',
                $row['borrow_count']
            );
            $pdf->TableRow($data, $widths);
        }
    } else {
        $pdf->SetFont('Arial', '', 10);
        $pdf->Cell(0, 10, 'No department statistics available for the selected period.', 0, 1, 'C');
    }

    // Add signature fields
    addSignatureFields($pdf);

    // Output the PDF
    $pdf->Output('usage_report.pdf', 'D');
    exit();
}