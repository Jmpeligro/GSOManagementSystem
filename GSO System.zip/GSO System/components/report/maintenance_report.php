<?php
session_start();
require_once '../../php/db_connection.php';
require_once '../fpdf/fpdf.php';
require_once 'report_utils.php';

if (!isLoggedIn() || !isAdmin()) {
    header("Location: ../../php/index.php");
    exit();
}

// PDF class definition
class PDF extends FPDF {
    function Header() {
        $this->Image('../../assets/images/logo.png', 10, 6, 30);
        $this->SetFont('Arial', 'B', 15);
        $this->Cell(80);
        $this->Cell(30, 10, 'PLP GSO Management System Report', 0, 0, 'C');
        $this->Ln(20);
    }
    
    function Footer() {
        $this->SetY(-15);
        $this->SetFont('Arial', 'I', 8);
        $this->Cell(0, 10, 'Page ' . $this->PageNo() . '/{nb}', 0, 0, 'C');
        $this->Cell(-30, 10, 'Generated on: ' . date('Y-m-d H:i:s'), 0, 0, 'R');
    }
    
    // Modified TableHeader to handle variable column widths
    function TableHeader($header, $widths = array()) {
        $this->SetFont('Arial', 'B', 10);
        $this->SetFillColor(200, 220, 255);
        
        // If no specific widths are provided, calculate them evenly
        if (empty($widths)) {
            $width = $this->GetPageWidth() - 20;
            $widths = array_fill(0, count($header), $width / count($header));
        }
        
        foreach($header as $i => $col) {
            $this->Cell($widths[$i], 7, $col, 1, 0, 'C', true);
        }
        $this->Ln();
        
        return $widths; // Return the widths for use in TableRow
    }
    
    // Modified TableRow to handle variable column widths and prevent text overlap
    function TableRow($data, $widths) {
        $this->SetFont('Arial', '', 9);
        
        $x_start = $this->GetX();
        $y_start = $this->GetY();
        $max_height = 6; // Default row height
        
        // First pass to calculate the maximum height needed
        foreach($data as $i => $col) {
            $current_x = $this->GetX();
            $current_y = $this->GetY();
            
            // Calculate how many lines this cell would take
            $this->MultiCell($widths[$i], 6, $col, 0);
            $height_needed = $this->GetY() - $current_y;
            $max_height = max($max_height, $height_needed);
            
            // Reset position for next calculation
            $this->SetXY($current_x + $widths[$i], $current_y);
        }
        
        // Reset position to start of row
        $this->SetXY($x_start, $y_start);
        
        // Second pass to actually print the cells with the calculated height
        foreach($data as $i => $col) {
            $current_x = $this->GetX();
            $this->MultiCell($widths[$i], 6, $col, 1);
            $this->SetXY($current_x + $widths[$i], $y_start);
        }
        
        // Move to next row
        $this->SetY($y_start + $max_height);
    }
}

$pdf = new PDF();
$pdf->AliasNbPages();
$pdf->AddPage();
$pdf->SetFont('Arial', '', 12);

try {
    generateMaintenanceReport($pdf, $conn);
} catch (Exception $e) {
    error_log("Error generating maintenance report: " . $e->getMessage());
    $pdf->Cell(0, 10, 'An error occurred while generating the report: ' . $e->getMessage(), 0, 1, 'C');
    $pdf->Output('maintenance_report_error.pdf', 'D');
    exit();
}

function generateMaintenanceReport($pdf, $conn) {
    $pdf->SetFont('Arial', 'B', 14);
    $pdf->Cell(0, 10, 'Maintenance Report', 0, 1, 'C');
    $pdf->Ln(5);

    $status = $_POST['status'] ?? '';
    $date_from = $_POST['date_from'] ?? '';
    $date_to = $_POST['date_to'] ?? '';
    
    // Always show cost in this fixed version
    $show_cost = true;
    $sum_cost = isset($_POST['sum_cost']) && $_POST['sum_cost'] == 'on';

    $sql = "SELECT m.maintenance_id, e.name as equipment_name, m.issue_description, 
            m.maintenance_date, m.resolved_date, m.status, m.cost, m.resolved_by, m.notes 
            FROM maintenance m 
            JOIN equipment e ON m.equipment_id = e.equipment_id 
            WHERE 1=1";
    
    if (!empty($status)) {
        $sql .= " AND m.status = '" . $conn->real_escape_string($status) . "'";
    }
    
    if (!empty($date_from)) {
        $sql .= " AND m.maintenance_date >= '" . $conn->real_escape_string($date_from) . "'";
    }
    
    if (!empty($date_to)) {
        $sql .= " AND m.maintenance_date <= '" . $conn->real_escape_string($date_to) . "'";
    }
    
    $sql .= " ORDER BY m.maintenance_id DESC";

    $result = $conn->query($sql);
    if (!$result) {
        throw new Exception("SQL Error: " . $conn->error);
    }

    if ($result->num_rows > 0) {
        $pdf->SetFont('Arial', 'I', 10);
        $filterText = 'Filters: ';
        $filterText .= !empty($status) ? 'Status: ' . ucfirst($status) : 'All Statuses';
        $filterText .= !empty($date_from) ? ', From: ' . formatDate($date_from) : '';
        $filterText .= !empty($date_to) ? ', To: ' . formatDate($date_to) : '';
        
        $pdf->Cell(0, 5, $filterText, 0, 1, 'L');
        $pdf->Ln(5);
        
        // Define headers with cost column
        $header = array('ID', 'Equipment', 'Issue Description', 'Start Date', 'End Date', 'Status', 'Cost', 'Resolved By');
        
        // Define column widths for better formatting
        $widths = array(15, 40, 60, 25, 25, 20, 20, 30);
        $widths = $pdf->TableHeader($header, $widths);
        
        $total_cost = 0;
        while ($row = $result->fetch_assoc()) {
            $cost = !empty($row['cost']) ? number_format($row['cost'], 2) : '0.00';
            $total_cost += floatval($row['cost'] ?? 0);
            
            $data = array(
                $row['maintenance_id'],
                $row['equipment_name'],
                $row['issue_description'],
                formatDate($row['maintenance_date']),
                formatDate($row['resolved_date']),
                ucfirst($row['status']),
                '$' . $cost,
                $row['resolved_by'] ?? 'N/A'
            );
            
            $pdf->TableRow($data, $widths);
        }
        
        $pdf->Ln(10);
        $pdf->SetFont('Arial', 'B', 11);
        $pdf->Cell(0, 10, 'Summary', 0, 1, 'L');

        $sql_summary = "SELECT status, COUNT(*) as count FROM maintenance";
        $where_clauses = [];
        
        if (!empty($status)) {
            $where_clauses[] = "status = '" . $conn->real_escape_string($status) . "'";
        }
        
        if (!empty($date_from)) {
            $where_clauses[] = "maintenance_date >= '" . $conn->real_escape_string($date_from) . "'";
        }
        
        if (!empty($date_to)) {
            $where_clauses[] = "maintenance_date <= '" . $conn->real_escape_string($date_to) . "'";
        }
        
        if (!empty($where_clauses)) {
            $sql_summary .= " WHERE " . implode(" AND ", $where_clauses);
        }
        
        $sql_summary .= " GROUP BY status";
        
        $result_summary = $conn->query($sql_summary);
        if (!$result_summary) {
            throw new Exception("SQL Error (summary): " . $conn->error);
        }
        
        $pdf->SetFont('Arial', '', 10);
        while ($row = $result_summary->fetch_assoc()) {
            $pdf->Cell(0, 6, ucfirst($row['status']) . ': ' . $row['count'] . ' maintenance records', 0, 1, 'L');
        }

        // Always show total cost in summary
        $pdf->Ln(5);
        $pdf->Cell(0, 6, 'Total Maintenance Cost: $' . number_format($total_cost, 2), 0, 1, 'L');
        
        // Add cost breakdown by status
        $pdf->Ln(5);
        $pdf->SetFont('Arial', 'B', 11);
        $pdf->Cell(0, 10, 'Cost Breakdown by Status', 0, 1, 'L');
        
        $sql_cost_by_status = "SELECT status, SUM(cost) as total_cost FROM maintenance";
        if (!empty($where_clauses)) {
            $sql_cost_by_status .= " WHERE " . implode(" AND ", $where_clauses);
        }
        $sql_cost_by_status .= " GROUP BY status";
        
        $result_cost_by_status = $conn->query($sql_cost_by_status);
        if (!$result_cost_by_status) {
            throw new Exception("SQL Error (cost breakdown): " . $conn->error);
        }
        
        $pdf->SetFont('Arial', '', 10);
        while ($row = $result_cost_by_status->fetch_assoc()) {
            $pdf->Cell(0, 6, ucfirst($row['status']) . ': $' . number_format($row['total_cost'] ?? 0, 2), 0, 1, 'L');
        }
    } else {
        $pdf->Cell(0, 10, 'No maintenance records found matching the criteria.', 0, 1, 'C');
    }
    
    $pdf->Output('maintenance_report.pdf', 'D');
    exit();
}