<?php
require_once 'CategoryBase.php';

class CategoryData extends CategoryBase {
    public function load($category_id) {
        $sql = "SELECT * FROM categories WHERE category_id = ?";
        $stmt = $this->conn->prepare($sql);
        if ($stmt === false) {
            return false;
        }
        $stmt->bind_param("i", $category_id);
        $stmt->execute();
        $result = $stmt->get_result();
        
        if ($result->num_rows === 0) {
            return false;
        }
        
        $category_data = $result->fetch_assoc();
        $this->setData($category_data);
        return true;
    }
    
    protected function nameExists($name, $exclude_id = null) {
        $sql = "SELECT COUNT(*) as count FROM categories WHERE name = ?";
        $params = [$name];
        $types = "s";
        
        if ($exclude_id !== null) {
            $sql .= " AND category_id != ?";
            $params[] = $exclude_id;
            $types .= "i";
        }
        
        $stmt = $this->conn->prepare($sql);
        if ($stmt === false) {
            return false; 
        }
        $stmt->bind_param($types, ...$params);
        $stmt->execute();
        $result = $stmt->get_result();
        return $result->fetch_assoc()['count'] > 0;
    }
    
    protected function hasEquipment() {
        $sql = "SELECT COUNT(*) as count FROM equipment WHERE category_id = ?";
        $stmt = $this->conn->prepare($sql);
        if ($stmt === false) {
            return false; 
        }
        $stmt->bind_param("i", $this->category_id);
        $stmt->execute();
        $result = $stmt->get_result();
        return $result->fetch_assoc()['count'] > 0;
    }

    public function getEquipment() {
        $equipment = [];
        $sql = "SELECT * FROM equipment WHERE category_id = ? ORDER BY name ASC";
        $stmt = $this->conn->prepare($sql);
        if ($stmt === false) {
            return $equipment; 
        }
        $stmt->bind_param("i", $this->category_id);
        $stmt->execute();
        $result = $stmt->get_result();
        
        while ($row = $result->fetch_assoc()) {
            $equipment[] = $row;
        }
        
        return $equipment;
    }
    
    public static function getAll($conn, $search_query = '') {
        $categories = [];
        $sql = "SELECT c.*, COUNT(e.equipment_id) as equipment_count 
                FROM categories c
                LEFT JOIN equipment e ON c.category_id = e.category_id
                WHERE 1=1";
                
        if (!empty($search_query)) {
            $search_query = $conn->real_escape_string($search_query);
            $sql .= " AND (c.name LIKE '%$search_query%' OR c.description LIKE '%$search_query%')";
        }
        
        $sql .= " GROUP BY c.category_id ORDER BY c.name ASC";
        $result = $conn->query($sql);
        
        if ($result === false) {
            return $categories; 
        }
        
        while ($row = $result->fetch_assoc()) {
            $categories[] = $row;
        }
        
        return $categories;
    }
}
?>