<?php
require_once 'BorrowingBase.php';

class BorrowingActions extends BorrowingBase {

    public function create($data) {
    if (empty($data['equipment_id'])) {
        return ['success' => false, 'message' => 'Equipment ID is required.'];
    }
    
    if (empty($data['user_id'])) {
        return ['success' => false, 'message' => 'User ID is required.'];
    }
    
    if (empty($data['borrow_date'])) {
        return ['success' => false, 'message' => 'Borrow date is required.'];
    }
    
    if (empty($data['due_date'])) {
        return ['success' => false, 'message' => 'Due date is required.'];
    }

    $borrow_datetime = new DateTime($data['borrow_date']);
    $due_datetime = new DateTime($data['due_date']);
    if ($borrow_datetime > $due_datetime) {
        return [
            'success' => false, 
            'message' => 'Due date must be after the borrow date.'
        ];
    }
    
    $equipment_available = $this->checkEquipmentAvailability($data['equipment_id']);
    if (!$equipment_available) {
        return [
            'success' => false, 
            'message' => 'Selected equipment is not available for borrowing.'
        ];
    }

    $status = $data['status'] ?? 'pending';
    $notes = $data['notes'] ?? '';
    $approval_status = $data['approval_status'] ?? 'pending';
    $admin_notes = $data['admin_notes'] ?? '';
    
    $sql = "INSERT INTO borrowings (
        equipment_id, user_id, borrow_date, due_date, status,
        notes, approval_status, admin_notes, created_at, updated_at
    ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, NOW(), NOW())";
    
    $stmt = $this->conn->prepare($sql);
    
    if ($stmt === false) {
        return [
            'success' => false, 
            'message' => 'Error preparing statement: ' . $this->conn->error
        ];
    }
    
    $stmt->bind_param(
        "iissssss",
        $data['equipment_id'],
        $data['user_id'],
        $data['borrow_date'],
        $data['due_date'],
        $status,
        $notes,
        $approval_status,
        $admin_notes
    );
    
    if ($stmt->execute()) {
        $this->borrowing_id = $stmt->insert_id;
        $this->setData($data);
        return ['success' => true, 'message' => 'Borrowing request created successfully.'];
    } else {
        return [
            'success' => false, 
            'message' => 'Error creating borrowing request: ' . $stmt->error
        ];
    }
}
    
    public function approve($admin_id, $admin_notes = '') {
    
    if (!$this->borrowing_id) {
        return ['success' => false, 'message' => 'No borrowing loaded.'];
    }
    
    if ($this->approval_status !== 'pending') {
        return [
            'success' => false, 
            'message' => 'This borrowing request has already been processed.'
        ];
    }

    $equipment_available = $this->checkEquipmentAvailability($this->equipment_id);
    if (!$equipment_available) {
        return [
            'success' => false, 
            'message' => 'Equipment is no longer available for borrowing.'
        ];
    }
    
    $this->conn->begin_transaction();
    
    try {
        $sql = "UPDATE borrowings 
                SET approval_status = 'approved',
                    status = 'active',
                    approved_by = ?,
                    approval_date = NOW(),
                    admin_notes = ?,
                    updated_at = NOW()
                WHERE borrowing_id = ?";
        
        $stmt = $this->conn->prepare($sql);
        if ($stmt === false) {
            throw new Exception("Error preparing approval statement: " . $this->conn->error);
        }
        
        $stmt->bind_param("isi", $admin_id, $admin_notes, $this->borrowing_id);
        if (!$stmt->execute()) {
            throw new Exception("Error approving borrowing: " . $stmt->error);
        }

        $update_equipment_sql = "UPDATE equipment 
                                 SET available_quantity = available_quantity - 1,
                                     updated_at = NOW() 
                                 WHERE equipment_id = ?";
        
        $update_equipment_stmt = $this->conn->prepare($update_equipment_sql);
        if ($update_equipment_stmt === false) {
            throw new Exception("Error preparing equipment update: " . $this->conn->error);
        }
        
        $update_equipment_stmt->bind_param("i", $this->equipment_id);
        if (!$update_equipment_stmt->execute()) {
            throw new Exception(
                "Error updating equipment status: " . $update_equipment_stmt->error
            );
        }
        
        $check_sql = "SELECT quantity, available_quantity FROM equipment WHERE equipment_id = ?";
        $check_stmt = $this->conn->prepare($check_sql);
        $check_stmt->bind_param("i", $this->equipment_id);
        $check_stmt->execute();
        $result = $check_stmt->get_result();
        $equipment_data = $result->fetch_assoc();
        
        if ($equipment_data['available_quantity'] == 0) {
            $status_sql = "UPDATE equipment SET status = 'borrowed' WHERE equipment_id = ?";
            $status_stmt = $this->conn->prepare($status_sql);
            $status_stmt->bind_param("i", $this->equipment_id);
            $status_stmt->execute();
        }
        
        // Add threshold check after successful update
        require_once __DIR__ . '/../../borrowings/EquipmentThreshold.php';
        checkEquipmentQuantityLevels($this->conn);

        $this->conn->commit();

        $this->approval_status = 'approved';
        $this->status = 'active';
        $this->approved_by = $admin_id;
        $this->approval_date = date('Y-m-d H:i:s');
        $this->admin_notes = $admin_notes;
        
        return ['success' => true, 'message' => 'Borrowing request approved successfully.'];
    } catch (Exception $e) {
        $this->conn->rollback();
        return ['success' => false, 'message' => $e->getMessage()];
    }
}
    
    public function deny($admin_id, $denial_reason = '') {
        if (!$this->borrowing_id) {
            return ['success' => false, 'message' => 'No borrowing loaded.'];
        }
        
        if ($this->approval_status !== 'pending') {
            return [
                'success' => false, 
                'message' => 'This borrowing request has already been processed.'
            ];
        }
        
        $sql = "UPDATE borrowings 
                SET approval_status = 'denied',
                    admin_notes = ?,
                    approved_by = ?,
                    approval_date = NOW(),
                    updated_at = NOW()
                WHERE borrowing_id = ?";
        
        $stmt = $this->conn->prepare($sql);
        if ($stmt === false) {
            return [
                'success' => false, 
                'message' => 'Error preparing statement: ' . $this->conn->error
            ];
        }
        
        $stmt->bind_param("sii", $denial_reason, $admin_id, $this->borrowing_id);
        
        if ($stmt->execute()) {
            $this->approval_status = 'denied';
            $this->approved_by = $admin_id;
            $this->approval_date = date('Y-m-d H:i:s');
            $this->admin_notes = $denial_reason;
            
            return ['success' => true, 'message' => 'Borrowing request denied successfully.'];
        } else {
            return [
                'success' => false, 
                'message' => 'Error denying borrowing request: ' . $stmt->error
            ];
        }
    }
    
    public function returnEquipment($user_id, $condition = 'good', $return_notes = '') {
    if (!$this->borrowing_id) {
        return ['success' => false, 'message' => 'No borrowing loaded.'];
    }
    
    if ($this->status !== 'active' || $this->approval_status !== 'approved') {
        return [
            'success' => false, 
            'message' => 'This equipment is not currently borrowed or was not approved.'
        ];
    }
    
    $this->conn->begin_transaction();
    
    try {
        $sql = "UPDATE borrowings 
                SET status = 'returned',
                    return_date = NOW(),
                    condition_on_return = ?,
                    return_notes = ?,
                    returned_by = ?,
                    updated_at = NOW()
                WHERE borrowing_id = ?";
        
        $stmt = $this->conn->prepare($sql);
        if ($stmt === false) {
            throw new Exception("Error preparing return statement: " . $this->conn->error);
        }
        
        $stmt->bind_param("ssii", $condition, $return_notes, $user_id, $this->borrowing_id);
        if (!$stmt->execute()) {
            throw new Exception("Error returning equipment: " . $stmt->error);
        }

        $update_equipment_sql = "UPDATE equipment 
                                 SET available_quantity = available_quantity + 1,
                                     updated_at = NOW() 
                                 WHERE equipment_id = ?";
        
        $update_equipment_stmt = $this->conn->prepare($update_equipment_sql);
        if ($update_equipment_stmt === false) {
            throw new Exception("Error preparing equipment update: " . $this->conn->error);
        }
        
        $update_equipment_stmt->bind_param("i", $this->equipment_id);
        if (!$update_equipment_stmt->execute()) {
            throw new Exception(
                "Error updating equipment status: " . $update_equipment_stmt->error
            );
        }

        // Update status to 'available' if any units are now available
        $status_sql = "UPDATE equipment SET status = 'available' WHERE equipment_id = ? AND available_quantity > 0";
        $status_stmt = $this->conn->prepare($status_sql);
        $status_stmt->bind_param("i", $this->equipment_id);
        $status_stmt->execute();
        
        $this->conn->commit();

        $this->status = 'returned';
        $this->return_date = date('Y-m-d H:i:s');
        $this->condition_on_return = $condition;
        $this->return_notes = $return_notes;
        $this->returned_by = $user_id;
        
        return ['success' => true, 'message' => 'Equipment returned successfully.'];
    } catch (Exception $e) {
        $this->conn->rollback();
        return ['success' => false, 'message' => $e->getMessage()];
    }
}
    
    public function cancel() {
        if (!$this->borrowing_id) {
            return ['success' => false, 'message' => 'No borrowing loaded.'];
        }
        
        if ($this->approval_status !== 'pending' || $this->status === 'active') {
            return [
                'success' => false, 
                'message' => 'Only pending borrowing requests can be cancelled.'
            ];
        }
        
        $sql = "DELETE FROM borrowings WHERE borrowing_id = ?";
        $stmt = $this->conn->prepare($sql);
        
        if ($stmt === false) {
            return [
                'success' => false, 
                'message' => 'Error preparing statement: ' . $this->conn->error
            ];
        }
        
        $stmt->bind_param("i", $this->borrowing_id);
        
        if ($stmt->execute()) {
            return ['success' => true, 'message' => 'Borrowing request cancelled successfully.'];
        } else {
            return [
                'success' => false, 
                'message' => 'Error cancelling borrowing request: ' . $stmt->error
            ];
        }
    }
    public function markAsOverdue() {
        if (!$this->borrowing_id) {
            return ['success' => false, 'message' => 'No borrowing loaded.'];
        }
        
        if ($this->status !== 'active' || $this->approval_status !== 'approved') {
            return [
                'success' => false, 
                'message' => 'This borrowing cannot be marked as overdue. It must be active and approved.'
            ];
        }
 
        if (!$this->isOverdue()) {
            return [
                'success' => false, 
                'message' => 'This borrowing is not yet overdue.'
            ];
        }
        
        $sql = "UPDATE borrowings 
                SET status = 'overdue', 
                    updated_at = NOW() 
                WHERE borrowing_id = ?";
        
        $stmt = $this->conn->prepare($sql);
        if ($stmt === false) {
            return [
                'success' => false, 
                'message' => 'Error preparing statement: ' . $this->conn->error
            ];
        }
        
        $stmt->bind_param("i", $this->borrowing_id);
        
        if ($stmt->execute()) {
            $this->status = 'overdue';
            
            return ['success' => true, 'message' => 'Borrowing marked as overdue successfully.'];
        } else {
            return [
                'success' => false, 
                'message' => 'Error marking borrowing as overdue: ' . $stmt->error
            ];
        }
    }

    public static function updateAllOverdueStatus($conn) {
        $activeBorrowings = Borrowing::getAll($conn, [
            'status' => 'active',
            'approval_status' => 'approved'
        ]);
        
        $updatedCount = 0;
        $errors = [];
        
        foreach ($activeBorrowings as $borrowingData) {
            $borrowing = new BorrowingActions($conn);
            if ($borrowing->load($borrowingData['borrowing_id'])) {
                if ($borrowing->isOverdue()) {
                    $result = $borrowing->markAsOverdue();
                    if ($result['success']) {
                        $updatedCount++;
                    } else {
                        $errors[] = "Error with borrowing ID {$borrowingData['borrowing_id']}: {$result['message']}";
                    }
                }
            }
        }
        
        if (empty($errors)) {
            return [
                'success' => true, 
                'message' => 'Overdue status updated successfully.',
                'count' => $updatedCount
            ];
        } else {
            return [
                'success' => false, 
                'message' => 'Errors occurred while updating overdue status: ' . implode('; ', $errors),
                'count' => $updatedCount
            ];
        }
    }
}
?>