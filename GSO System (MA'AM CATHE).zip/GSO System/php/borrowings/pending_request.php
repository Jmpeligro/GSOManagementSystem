<?php
session_start();
require_once '../db_connection.php';
require_once '../helpers.php'; 
require_once '../classes/borrowing/Borrowing.php';
require_once 'notifications.php';
require_once '../classes/User/UserBase.php';
require_once 'EquipmentThreshold.php';

if (!isLoggedIn() || !isAdmin()) {
    header("Location: php/login.php");
    exit();
}


if (isset($_POST['approve_request'])) {
    $borrowing_id = (int)$_POST['borrowing_id'];
    $borrowing = new Borrowing($conn);

      if ($borrowing->load($borrowing_id)) {
        $borrowerInfo = new UserBase($conn);
        $borrowerInfo->load($borrowing->getUserId());
        $recipientEmail = $borrowerInfo->getEmail();
        $name = $borrowerInfo->getFullName();

        $result = $borrowing->approve($_SESSION['user_id'], 'Approved by administrator');
        
        if ($result['success']) {
            checkEquipmentQuantityLevels($conn);

            $_SESSION['success'] = "Borrowing request approved successfully.";            
            $emailBody = "
                <b><u>THIS IS AN AUTOMATICALLY GENERATED EMAIL | DO NOT REPLY</u></b><br>
                <hr>
                <p>The equipment you requested to borrow has been approved.</p>
                <p><strong>Borrow Date:</strong> " . date('F d, Y h:i A', strtotime($borrowing->getBorrowDate())) . "</p>
                <p><strong>Due Date:</strong> " . date('F d, Y h:i A', strtotime($borrowing->getDueDate())) . "</p>
                <p>Please visit the General Service Office at your soonest convenience to collect/claim your requested equipment.</p>
            ";
            $emailBodyAlt = "THIS IS AN AUTOMATICALLY GENERATED EMAIL | DO NOT REPLY\n\n" .
                "The equipment you requested to borrow has been approved.\n\n" .
                "Borrow Date: " . date('F d, Y h:i A', strtotime($borrowing->getBorrowDate())) . "\n" .
                "Due Date: " . date('F d, Y h:i A', strtotime($borrowing->getDueDate())) . "\n\n" .
                "Please visit the General Service Office at your soonest convenience to collect/claim your requested equipment.";
            
            pushNotif("Email Sent", "An Email has been sent to notify " . $name . " of their request status at " . $recipientEmail);
            sendEmail($recipientEmail, $name, "Borrow Request: Approved", $emailBody, $emailBodyAlt);
        } else {
            $_SESSION['error'] = "Error approving request: " . $result['message'];
        }
    } else {
        $_SESSION['error'] = "Borrowing record not found.";
    }
    
    header("Location: pending_request.php");
    exit();
}

if (isset($_POST['deny_request'])) {
    $borrowing_id = (int)$_POST['borrowing_id'];
    $denial_reason = sanitize($_POST['denial_reason']);
  
    $borrowing = new Borrowing($conn);    
    if ($borrowing->load($borrowing_id)) {
        // Get borrower's details
        $borrowerInfo = new UserBase($conn);
        $borrowerInfo->load($borrowing->getUserId());
        $recipientEmail = $borrowerInfo->getEmail();
        $name = $borrowerInfo->getFullName();

        $result = $borrowing->deny($_SESSION['user_id'], $denial_reason);
        
        if ($result['success']) {
            $_SESSION['success'] = "Borrowing request denied.";
            
            $emailBody = "
                <b><u>THIS IS AN AUTOMATICALLY GENERATED EMAIL | DO NOT REPLY</u></b><br>
                <hr>
                <p>The equipment you requested to borrow has been denied.</p>
                <p><strong>Reason:</strong> " . htmlspecialchars($denial_reason) . "</p>
            ";
            $emailBodyAlt = "THIS IS AN AUTOMATICALLY GENERATED EMAIL | DO NOT REPLY\n\n" .
                "The equipment you requested to borrow has been denied.\n" .
                "Reason: " . $denial_reason;
            
            pushNotif("Email Sent", "An Email has been sent to notify " . $name . " of their request status at " . $recipientEmail);
            sendEmail($recipientEmail, $name, "Borrow Request: Denied", $emailBody, $emailBodyAlt);
        } else {
            $_SESSION['error'] = "Error denying request: " . $result['message'];
        }
    } else {
        $_SESSION['error'] = "Borrowing record not found.";
    }
    
    header("Location: pending_request.php");
    exit();
}

$pending_requests = Borrowing::getPendingRequests($conn);
include '../../pages/borrowings/pending_request.html';
?>