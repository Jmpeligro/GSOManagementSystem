<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);

require_once 'notifications.php';
require_once '../classes/Equipment/Equipment.php';

function checkEquipmentQuantityLevels($conn) {
    $sql = "SELECT equipment_id FROM equipment";
    $result = $conn->query($sql);
    
    $criticalEquipment = [];
    
    if ($result->num_rows > 0) {
        while ($row = $result->fetch_assoc()) {
            $equipment = new Equipment($conn);
            $equipment->load($row['equipment_id']);
            
            $id = $equipment->getId();
            $name = $equipment->getName();            $quant = $equipment->getQuantity();
            $avbl_quant = $equipment->getAvailableQuantity();
            
            if ($avbl_quant <= 3 || $quant <= 3) {
                $criticalEquipment[] = [
                    'id' => $id,
                    'name' => $name,
                    'quantity' => $quant,
                    'available_quantity' => $avbl_quant
                ];
            }
        }
    }
      if (!empty($criticalEquipment)) {
        sendCriticalQuantityNotification($criticalEquipment, $conn);
    }
    
    return $criticalEquipment;
}

function sendCriticalQuantityNotification($criticalEquipment, $conn) {
    $emailHeader = "
        <B><U>THIS IS AN AUTOMATICALLY GENERATED REPORT | DO NOT REPLY</U></B> <BR>
        <hr>
        <p>List of equipment with critical level of available quantity:</p><br>
    ";

    $emailHeaderAlt = "
        THIS IS AN AUTOMATICALLY GENERATED REPORT | DO NOT REPLY \n
        List of equipment with critical level of available quantity:\n
        
    ";

    $emailBody = $emailHeader;
    $emailBodyAlt = $emailHeaderAlt;    foreach ($criticalEquipment as $equipment) {
        $emailBody .= "Equipment ID: " . $equipment['id'] . " Name: " . $equipment['name'] . 
                      " | Quantity: " . $equipment['quantity'] . 
                      " | Available Quantity: " . $equipment['available_quantity'] . 
                      " | Quantity Level = Critical" . "<br>\n";
                      
        $emailBodyAlt .= "Equipment ID: " . $equipment['id'] . " Name: " . $equipment['name'] . 
                        " | Quantity: " . $equipment['quantity'] . 
                        " | Available Quantity: " . $equipment['available_quantity'] . 
                        " | Quantity Level = Critical\n";
    }
      // Get all admin users' emails
    $adminQuery = "SELECT email, CONCAT(first_name, ' ', last_name) as full_name FROM users WHERE role = 'admin' AND status = 'active'";
    $adminResult = $conn->query($adminQuery);
    
    // Send email to each admin user    
    while ($admin = $adminResult->fetch_assoc()) {
        sendEmail($admin['email'], $admin['full_name'], "Equipment Inventory Alert - Critical Levels", $emailBody, $emailBodyAlt);
    }

    pushNotif("Equipment Alert", "Some equipment items have reached critical inventory levels");
}

if (basename($_SERVER['PHP_SELF']) == basename(__FILE__)) {
    require_once '../db_connection.php';
    checkEquipmentQuantityLevels($conn);
    
    echo "<script>window.close();</script>";
}
?>