<?php
?>
<footer class="footer">
    <div class="container">
        <p>&copy; <?php echo date('Y'); ?> PLP General Service Office Management System</p>
    </div>
</footer>