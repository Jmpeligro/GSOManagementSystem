<?php
session_start();
require_once '../php/db_connection.php';
require_once 'fpdf/fpdf.php'; 
require_once 'reports/report_utils.php';

if (!isLoggedIn() || !isAdmin()) {
    header("Location: index.php");
    exit();
}

$report_type = $_POST['report_type'] ?? '';

if (empty($report_type)) {
    $_SESSION['error'] = "Report type is required";
    header("Location: ../../php/reports.php");
    exit();
}

class PDF extends FPDF {
    function Header() {
        $this->Image('../assets/images/logo.png', 10, 6, 30);
        $this->SetFont('Arial', 'B', 15);
        $this->Cell(80);
        $this->Cell(30, 10, 'PLP GSO Management System Report', 0, 0, 'C');
        $this->Ln(20);
    }

    function Footer() {
        $this->SetY(-15);
        $this->SetFont('Arial', 'I', 8);
        $this->Cell(0, 10, 'Page ' . $this->PageNo() . '/{nb}', 0, 0, 'C');
        $this->Cell(-30, 10, 'Generated on: ' . date('Y-m-d H:i:s'), 0, 0, 'R');
    }

    function TableHeader($header) {
        $this->SetFont('Arial', 'B', 10);
        $this->SetFillColor(200, 220, 255);
        $width = $this->GetPageWidth() - 20;
        $col_width = $width / count($header);
        
        foreach($header as $col) {
            $this->Cell($col_width, 7, $col, 1, 0, 'C', true);
        }
        $this->Ln();
    }

    function TableRow($data, $header_count) {
        $this->SetFont('Arial', '', 9);
        $width = $this->GetPageWidth() - 20;
        $col_width = $width / $header_count;
        
        foreach($data as $col) {
            $this->Cell($col_width, 6, $col, 1);
        }
        $this->Ln();
    }
}

$pdf = new PDF();
$pdf->AliasNbPages();
$pdf->AddPage();
$pdf->SetFont('Arial', '', 12);

switch ($report_type) {
    case 'equipment':
        require_once 'reports/equipment_report.php';
        generateEquipmentReport($pdf, $conn);
        break;
    case 'borrowings':
        require_once 'reports/borrowings_report.php';
        generateBorrowingsReport($pdf, $conn);
        break;
    case 'maintenance':
        require_once 'reports/maintenance_report.php';
        generateMaintenanceReport($pdf, $conn);
        break;
    case 'usage':
        require_once 'reports/usage_report.php';
        generateUsageReport($pdf, $conn);
        break;
    default:
        $_SESSION['error'] = "Invalid report type";
        header("Location: ../php/reports.php");
        exit();
}