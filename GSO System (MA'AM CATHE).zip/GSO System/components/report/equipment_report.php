<?php
session_start();
require_once '../../php/db_connection.php';
require_once '../fpdf/fpdf.php';
require_once 'report_utils.php';

if (!isLoggedIn() || !isAdmin()) {
    header("Location: ../../php/index.php");
    exit();
}

class PDF extends FPDF {
    function Header() {
        $this->Image('../../assets/images/logo.png', 10, 6, 30);
        $this->SetFont('Arial', 'B', 15);
        $this->Cell(80);
        $this->Cell(30, 10, 'PLP GSO Management System Report', 0, 0, 'C');
        $this->Ln(20);
    }
    
    function Footer() {
        $this->SetY(-15);
        $this->SetFont('Arial', 'I', 8);
        $this->Cell(0, 10, 'Page ' . $this->PageNo() . '/{nb}', 0, 0, 'C');
        $this->Cell(-30, 10, 'Generated on: ' . date('Y-m-d H:i:s'), 0, 0, 'R');
    }
    
    function TableHeader($header) {
        $this->SetFont('Arial', 'B', 10);
        $this->SetFillColor(200, 220, 255);
        
        $total_width = $this->GetPageWidth() - 20; 
        $col_count = count($header);
 
        $widths = array();
        $standard_width = $total_width / ($col_count + 1); 
        
        foreach($header as $i => $col) {
            switch($i) {
                case 0: // ID
                    $widths[] = $standard_width * 0.5;
                    break;
                case 1: // Name
                    $widths[] = $standard_width * 1.5;
                    break;
                case 2: // Category
                    $widths[] = $standard_width * 1.2;
                    break;
                default:
                    $widths[] = $standard_width;
            }
        }
        
        foreach($header as $i => $col) {
            $this->Cell($widths[$i], 7, $col, 1, 0, 'C', true);
        }
        $this->Ln();
        
        return $widths;
    }
    
    function TableRow($data, $widths) {
        $this->SetFont('Arial', '', 9);

        $max_height = 6; 
        $x_start = $this->GetX();
        $y_start = $this->GetY();
        
        foreach($data as $i => $cell) {
            $this->SetXY($x_start, $y_start);
            for($j = 0; $j < $i; $j++) {
                $this->SetX($this->GetX() + $widths[$j]);
            }
            
            $lines = $this->getNumLines($cell, $widths[$i]);
            $cell_height = $lines * 6;
            $max_height = max($max_height, $cell_height);
        }

        $this->SetXY($x_start, $y_start);
        foreach($data as $i => $cell) {
            $align = is_numeric($cell) ? 'R' : 'L';
            $this->MultiCell($widths[$i], 6, $cell, 1, $align, false);
            $this->SetXY($x_start + array_sum(array_slice($widths, 0, $i + 1)), $y_start);
        }
        
        $this->Ln($max_height);
    }

    function getNumLines($text, $width) {
        $this->SetFont('Arial', '', 9);
        $text_width = $this->GetStringWidth($text);
        return max(1, ceil($text_width / ($width - 2)));
    }
}

$pdf = new PDF();
$pdf->AliasNbPages();
$pdf->AddPage();
$pdf->SetFont('Arial', '', 12);

generateEquipmentReport($pdf, $conn);

function generateEquipmentReport($pdf, $conn) {
    $pdf->SetFont('Arial', 'B', 14);
    $pdf->Cell(0, 10, 'Equipment Inventory Report', 0, 1, 'C');
    $pdf->Ln(5);
    
    $status = $_POST['status'] ?? '';
    $category = $_POST['category_id'] ?? '';
    
    $sql = "SELECT e.equipment_id, e.name, c.name as category, e.status, e.acquisition_date, e.condition_status 
            FROM equipment e 
            LEFT JOIN categories c ON e.category_id = c.category_id 
            WHERE 1=1";
    
    if (!empty($status)) {
        $sql .= " AND (e.status = 'available' OR e.status = 'borrowed')";
    }
    
    if (!empty($category)) {
        $sql .= " AND e.category_id = " . $conn->real_escape_string($category);
    }
    
    $sql .= " ORDER BY e.equipment_id";
    
    $result = $conn->query($sql);
    if (!$result) {
        error_log("SQL Error in generateEquipmentReport: " . $conn->error);
        $pdf->Cell(0, 10, 'An error occurred while generating the report. Please try again later.', 0, 1, 'C');
        $pdf->Output('equipment_report.pdf', 'D');
        exit();
    }

    if ($result->num_rows > 0) {
        $pdf->SetFont('Arial', 'I', 10);
        $pdf->Cell(0, 5, 'Filters: ' . 
            (!empty($status) ? 'Status: ' . ucfirst($status) : 'All Statuses') . ', ' . 
            (!empty($category) ? 'Category: ' . getCategoryName($conn, $category) : 'All Categories'),
            0, 1, 'L');
        $pdf->Ln(5);

        $header = array('ID', 'Name', 'Category', 'Status', 'Acquisition Date', 'Condition');
        $widths = $pdf->TableHeader($header);

        while ($row = $result->fetch_assoc()) {
            $data = array(
                $row['equipment_id'],
                $row['name'],
                $row['category'],
                ucfirst($row['status']),
                formatDate($row['acquisition_date']),
                ucfirst($row['condition_status'])
            );
            $pdf->TableRow($data, $widths);
        }

        $pdf->Ln(10);
        $pdf->SetFont('Arial', 'B', 11);
        $pdf->Cell(0, 10, 'Summary', 0, 1, 'L');

        $sql_summary = "SELECT status, COUNT(*) as count FROM equipment";
        if (!empty($status)) {
            $sql_summary .= " WHERE status = '" . $conn->real_escape_string($status) . "'";
        } elseif (!empty($category)) {
            $sql_summary .= " WHERE category_id = " . $conn->real_escape_string($category);
        }
        $sql_summary .= " GROUP BY status";
        
        $result_summary = $conn->query($sql_summary);
        
        $pdf->SetFont('Arial', '', 10);
        while ($row = $result_summary->fetch_assoc()) {
            $pdf->Cell(0, 6, ucfirst($row['status']) . ': ' . $row['count'] . ' items', 0, 1, 'L');
        }

        $sql_value = "SELECT COALESCE(SUM(m.cost), 0) as total 
                      FROM equipment e 
                      LEFT JOIN maintenance m ON e.equipment_id = m.equipment_id";

        if (!empty($status)) {
            $sql_value .= " WHERE e.status = '" . $conn->real_escape_string($status) . "'";
        } elseif (!empty($category)) {
            $sql_value .= " WHERE e.category_id = " . $conn->real_escape_string($category);
        }

        try {
            $result_value = $conn->query($sql_value);
            if (!$result_value) {
                throw new Exception($conn->error);
            }
            
            $row_value = $result_value->fetch_assoc();
            $pdf->Ln(5);
            $pdf->Cell(0, 6, 'Total Maintenance Cost: $' . number_format($row_value['total'] ?? 0, 2), 0, 1, 'L');
        } catch (Exception $e) {
            error_log("Error in equipment report: " . $e->getMessage());
            $pdf->Ln(5);
            $pdf->Cell(0, 6, 'Error calculating total value', 0, 1, 'L');
        }
    } else {
        $pdf->Cell(0, 10, 'No equipment records found matching the criteria.', 0, 1, 'C');
    }
    
    $pdf->Output('equipment_report.pdf', 'D');
    exit();
}