<?php
session_start();
require_once '../../php/db_connection.php';
require_once '../fpdf/fpdf.php';
require_once 'report_utils.php';

if (!isLoggedIn() || !isAdmin()) {
    header("Location: ../../php/index.php");
    exit();
}

class PDF extends FPDF {
    function Header() { 
        $this->Image('../../assets/images/logo.png', 15, 10, 25);
        $this->SetFont('Arial', 'B', 16);
        $this->Cell(0, 20, 'PLP GSO Management System Report', 0, 1, 'C');
        $this->SetFont('Arial', 'B', 14);
        $this->Cell(0, 10, 'Maintenance Report', 0, 1, 'C');
        $this->Ln(5);
    }
    
    function Footer() {
        $this->SetY(-15);
        $this->SetFont('Arial', 'I', 8);
        $this->Cell(0, 10, 'Page ' . $this->PageNo() . '/{nb}', 0, 0, 'C');
        $this->Cell(-30, 10, 'Generated on: ' . date('Y-m-d H:i:s'), 0, 0, 'R');
    }
    
    function ImprovedTableHeader($header, $widths = array()) {
        $this->SetFont('Arial', 'B', 10);
        $this->SetFillColor(220, 230, 240); 
        
        if (empty($widths)) {
            $total_width = $this->GetPageWidth() - 30; 
            $standard_width = $total_width / count($header);
            $widths = array_fill(0, count($header), $standard_width);
        }
        
        foreach($header as $i => $col) {
            $this->Cell($widths[$i], 8, $col, 1, 0, 'C', true);
        }
        $this->Ln();
        
        return $widths;
    }
    
    function ImprovedTableRow($data, $widths) {
        $this->SetFont('Arial', '', 9);
        
        $max_height = 7; 
        foreach($data as $i => $cell) {
            $lines = $this->NbLines($widths[$i], $cell);
            $current_height = $lines * 6;
            $max_height = max($max_height, $current_height);
        }
        
        $x_start = $this->GetX();
        $y_start = $this->GetY();

        $current_x = $x_start;
        foreach($widths as $w) {
            $this->Rect($current_x, $y_start, $w, $max_height);
            $current_x += $w;
        }

        $current_x = $x_start;
        foreach($data as $i => $cell) {
            $align = (is_numeric(str_replace(['₱', ',', '.'], '', $cell))) ? 'R' : 'L';
            
            $this->SetXY($current_x, $y_start);
            
            $this->SetX($current_x + 1);
            $this->MultiCell($widths[$i] - 2, 5, $cell, 0, $align);
            
            $current_x += $widths[$i];
        }
        
        $this->SetY($y_start + $max_height);
    }
    
    function SectionTitle($title) {
        $this->SetFont('Arial', 'B', 12);
        $this->Ln(5);
        $this->Cell(0, 10, $title, 0, 1, 'L');
        $this->SetFont('Arial', '', 10);
    }
    
    function NbLines($w, $txt) {
        $cw = &$this->CurrentFont['cw'];
        if($w == 0) {
            $w = $this->w - $this->rMargin - $this->x;
        }
        
        $wmax = ($w - 2 * $this->cMargin) * 1000 / $this->FontSize;
        $s = str_replace("\r", '', $txt);
        $nb = strlen($s);
        if($nb > 0 && $s[$nb-1] == "\n") {
            $nb--;
        }
        
        $sep = -1;
        $i = 0;
        $j = 0;
        $l = 0;
        $nl = 1;
        
        while($i < $nb) {
            $c = $s[$i];
            if($c == "\n") {
                $i++;
                $sep = -1;
                $j = $i;
                $l = 0;
                $nl++;
                continue;
            }
            
            if($c == ' ') {
                $sep = $i;
            }
            
            $l += $cw[$c];
            if($l > $wmax) {
                if($sep == -1) {
                    if($i == $j) {
                        $i++;
                    }
                } else {
                    $i = $sep + 1;
                }
                $sep = -1;
                $j = $i;
                $l = 0;
                $nl++;
            } else {
                $i++;
            }
        }
        
        return $nl;
    }

    function SummaryBlock($label, $value) {
        $this->SetFont('Arial', '', 10);
        $this->Cell(120, 8, $label, 0, 0, 'L');
        $this->SetFont('Arial', 'B', 10);
        $this->Cell(70, 8, $value, 0, 1, 'L');
    }
    
    function FormatCurrency($amount) {
        return '₱' . number_format($amount, 2);
    }
}

$pdf = new PDF();
$pdf->AliasNbPages();
$pdf->AddPage();
$pdf->SetFont('Arial', '', 12);

try {
    generateMaintenanceReport($pdf, $conn);
} catch (Exception $e) {
    error_log("Error generating maintenance report: " . $e->getMessage());
    $pdf->SetFont('Arial', 'B', 12);
    $pdf->Cell(0, 10, 'An error occurred while generating the report:', 0, 1, 'C');
    $pdf->SetFont('Arial', '', 10);
    $pdf->Cell(0, 10, $e->getMessage(), 0, 1, 'C');
    $pdf->Output('maintenance_report_error.pdf', 'D');
    exit();
}

function generateMaintenanceReport($pdf, $conn) {
    $status = $_POST['status'] ?? '';
    $date_from = $_POST['date_from'] ?? '';
    $date_to = $_POST['date_to'] ?? '';

    $show_cost = true;
    $sum_cost = isset($_POST['sum_cost']) && $_POST['sum_cost'] == 'on';

    $pdf->SetFont('Arial', 'I', 10);
    $filterText = 'Filters: ';
    $filterText .= !empty($status) ? 'Status: ' . ucfirst($status) : 'All Statuses';
    $filterText .= !empty($date_from) ? ', From: ' . formatDate($date_from) : '';
    $filterText .= !empty($date_to) ? ', To: ' . formatDate($date_to) : '';
    
    $pdf->Cell(0, 6, $filterText, 0, 1, 'L');
    $pdf->Ln(3);
    
    $sql = "SELECT m.maintenance_id, e.name as equipment_name, m.issue_description, 
            m.maintenance_date, m.resolved_date, m.status, m.cost, m.resolved_by, m.notes 
            FROM maintenance m 
            JOIN equipment e ON m.equipment_id = e.equipment_id 
            WHERE 1=1";
    
    $where_clauses = [];
    
    if (!empty($status)) {
        $where_clauses[] = "m.status = '" . $conn->real_escape_string($status) . "'";
    }
    
    if (!empty($date_from)) {
        $where_clauses[] = "m.maintenance_date >= '" . $conn->real_escape_string($date_from) . "'";
    }   
    
    if (!empty($date_to)) {
        $where_clauses[] = "m.maintenance_date <= '" . $conn->real_escape_string($date_to) . "'";
    }
    
    if (!empty($where_clauses)) {
        $sql .= " AND " . implode(" AND ", $where_clauses);
    }
    
    $sql .= " ORDER BY m.maintenance_date DESC, m.maintenance_id DESC";

    $result = $conn->query($sql);
    if (!$result) {
        throw new Exception("SQL Error: " . $conn->error);
    }

    if ($result->num_rows > 0) {
        $header = array('Equipment', 'Issue Description', 'Cost');
        
        $widths = array(80, 95, 25);
        $widths = $pdf->ImprovedTableHeader($header, $widths);
        
        $total_cost = 0;
        $status_counts = array();
        $status_costs = array();
        
        while ($row = $result->fetch_assoc()) {
            $status_value = $row['status'];
            
            if (!isset($status_counts[$status_value])) {
                $status_counts[$status_value] = 0;
            }
            $status_counts[$status_value]++;
            
            if (!isset($status_costs[$status_value])) {
                $status_costs[$status_value] = 0;
            }
            $status_costs[$status_value] += floatval($row['cost'] ?? 0);
            
            $cost = !empty($row['cost']) ? floatval($row['cost']) : 0;
            $total_cost += $cost;

            $data = array(
                $row['equipment_name'],
                $row['issue_description'],
                $pdf->FormatCurrency($cost)
            );
            
            $pdf->ImprovedTableRow($data, $widths);
        }
        
        $pdf->SectionTitle('Summary');

        foreach ($status_counts as $status => $count) {
            $pdf->SummaryBlock(ucfirst($status) . ':', $count . ' maintenance records');
        }
        
        $pdf->Ln(5);
        $pdf->SummaryBlock('Total Maintenance Records:', array_sum($status_counts));
        $pdf->SummaryBlock('Total Maintenance Cost:', $pdf->FormatCurrency($total_cost));
        
        $pdf->SectionTitle('Cost Breakdown by Status');
        
        foreach ($status_costs as $status => $cost) {
            $pdf->SummaryBlock(ucfirst($status) . ':', $pdf->FormatCurrency($cost));
        }

        $pdf->Ln(10);
        $pdf->SetFont('Arial', 'I', 8);
        $pdf->Cell(0, 5, 'This report includes only the maintenance records that match the specified filters.', 0, 1, 'L');
        $pdf->Cell(0, 5, 'For more detailed information about specific maintenance records, please consult the maintenance log.', 0, 1, 'L');
    } else {
        $pdf->SetFont('Arial', 'B', 12);
        $pdf->Cell(0, 20, 'No maintenance records found matching the criteria.', 0, 1, 'C');
        $pdf->SetFont('Arial', '', 10);
        $pdf->Cell(0, 10, 'Try adjusting your filter settings and generate the report again.', 0, 1, 'C');
    }
    
    $pdf->Output('maintenance_report.pdf', 'D');
    exit();
}